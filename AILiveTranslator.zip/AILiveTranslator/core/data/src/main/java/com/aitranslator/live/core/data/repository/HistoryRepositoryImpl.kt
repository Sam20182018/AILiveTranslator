package com.aitranslator.live.core.data.repository

import com.aitranslator.live.core.common.DispatcherProvider
import com.aitranslator.live.core.common.Logger
import com.aitranslator.live.core.data.db.HistoryDao
import com.aitranslator.live.core.data.db.toDomain
import com.aitranslator.live.core.data.db.toEntity
import com.aitranslator.live.core.domain.model.HistoryEntry
import com.aitranslator.live.core.domain.repository.HistoryRepository
import com.aitranslator.live.core.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Writing is gated on the user's privacy switches: nothing is stored when history is off,
 * and an audio path is only kept when audio saving is explicitly enabled.
 */
@Singleton
class HistoryRepositoryImpl @Inject constructor(
    private val historyDao: HistoryDao,
    private val settingsRepository: SettingsRepository,
    private val dispatchers: DispatcherProvider,
) : HistoryRepository {

    override fun observeHistory(query: String): Flow<List<HistoryEntry>> {
        val source = if (query.isBlank()) {
            historyDao.observeAll()
        } else {
            historyDao.search(query.trim())
        }
        return source.map { entities -> entities.map { it.toDomain() } }
    }

    override suspend fun add(entry: HistoryEntry): Long = withContext(dispatchers.io) {
        val settings = settingsRepository.current()
        if (!settings.saveHistory) return@withContext -1L

        val sanitized = if (settings.saveAudio) entry else entry.copy(audioFilePath = null)
        historyDao.insert(sanitized.toEntity())
    }

    override suspend fun delete(id: Long) = withContext(dispatchers.io) {
        historyDao.findById(id)?.audioFilePath?.let(::deleteFileQuietly)
        historyDao.deleteById(id)
    }

    override suspend fun deleteAll() = withContext(dispatchers.io) {
        historyDao.allAudioPaths().forEach(::deleteFileQuietly)
        historyDao.deleteAll()
    }

    override suspend fun purgeAudio() = withContext(dispatchers.io) {
        historyDao.allAudioPaths().forEach(::deleteFileQuietly)
        historyDao.clearAudioPaths()
    }

    private fun deleteFileQuietly(path: String) {
        runCatching { File(path).takeIf { it.exists() }?.delete() }
            .onFailure { Logger.w(TAG, "could not delete audio file") }
    }

    private companion object {
        const val TAG = "HistoryRepository"
    }
}
