package com.aitranslator.live.core.data.cache

import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.TranslationResult
import javax.inject.Inject
import javax.inject.Singleton

/**
 * In-memory LRU of recent translations.
 *
 * Live and conversation modes re-send the same short phrases constantly ("yes", "okay",
 * "thank you", repeated recogniser output), and each repeat would otherwise be a paid API
 * call with added latency. The cache is intentionally *not* persisted: translations of a
 * previous session are not worth the storage or the privacy exposure.
 */
@Singleton
class TranslationCache @Inject constructor() {

    private val entries = object : LinkedHashMap<String, TranslationResult>(
        INITIAL_CAPACITY,
        LOAD_FACTOR,
        true,
    ) {
        override fun removeEldestEntry(
            eldest: MutableMap.MutableEntry<String, TranslationResult>?,
        ): Boolean = size > MAX_ENTRIES
    }

    @Synchronized
    fun get(text: String, source: Language, target: Language): TranslationResult? =
        entries[keyOf(text, source, target)]

    @Synchronized
    fun put(text: String, source: Language, target: Language, result: TranslationResult) {
        if (text.length > MAX_CACHEABLE_LENGTH) return
        entries[keyOf(text, source, target)] = result
    }

    @Synchronized
    fun clear() = entries.clear()

    @Synchronized
    fun size(): Int = entries.size

    /**
     * Normalising the text means "Hello!" and "  hello " share a cache slot, which is what
     * makes the cache actually hit on speech transcripts.
     */
    private fun keyOf(text: String, source: Language, target: Language): String =
        "${source.code}|${target.code}|${text.trim().lowercase()}"

    private companion object {
        const val MAX_ENTRIES = 200
        const val INITIAL_CAPACITY = 32
        const val LOAD_FACTOR = 0.75f
        const val MAX_CACHEABLE_LENGTH = 400
    }
}
