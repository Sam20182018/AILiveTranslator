package com.aitranslator.live.core.data.repository

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import com.aitranslator.live.core.data.datastore.PreferenceKeys
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.AppSettings
import com.aitranslator.live.core.domain.model.ConversationTurnMode
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.LatencyProfile
import com.aitranslator.live.core.domain.model.ThemeMode
import com.aitranslator.live.core.domain.model.VoiceGender
import com.aitranslator.live.core.domain.model.VoiceProfile
import com.aitranslator.live.core.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SettingsRepositoryImpl @Inject constructor(
    private val dataStore: DataStore<Preferences>,
) : SettingsRepository {

    override val settings: Flow<AppSettings> = dataStore.data.map { it.toAppSettings() }

    override suspend fun current(): AppSettings = settings.first()

    override suspend fun setActiveProvider(provider: AiProvider) = edit {
        it[PreferenceKeys.ACTIVE_PROVIDER] = provider.id
    }

    override suspend fun setModelOverride(provider: AiProvider, model: String?) = edit {
        val key = PreferenceKeys.modelOverride(provider)
        if (model.isNullOrBlank()) it.remove(key) else it[key] = model.trim()
    }

    override suspend fun setSourceLanguage(language: Language) = edit {
        it[PreferenceKeys.SOURCE_LANGUAGE] = language.code
    }

    override suspend fun setTargetLanguage(language: Language) = edit {
        it[PreferenceKeys.TARGET_LANGUAGE] = language.code
    }

    override suspend fun swapLanguages() = edit { preferences ->
        val source = Language.fromCode(preferences[PreferenceKeys.SOURCE_LANGUAGE])
            ?: Language.DEFAULT_SOURCE
        val target = Language.fromCode(preferences[PreferenceKeys.TARGET_LANGUAGE])
            ?: Language.DEFAULT_TARGET
        preferences[PreferenceKeys.SOURCE_LANGUAGE] = target.code
        preferences[PreferenceKeys.TARGET_LANGUAGE] = source.code
    }

    override suspend fun setConversationLanguages(personA: Language, personB: Language) = edit {
        it[PreferenceKeys.CONVERSATION_LANGUAGE_A] = personA.code
        it[PreferenceKeys.CONVERSATION_LANGUAGE_B] = personB.code
    }

    override suspend fun setConversationTurnMode(mode: ConversationTurnMode) = edit {
        it[PreferenceKeys.CONVERSATION_TURN_MODE] = mode.id
    }

    override suspend fun setVoice(voiceId: String) = edit {
        it[PreferenceKeys.SELECTED_VOICE_ID] = voiceId
    }

    override suspend fun setPreferredVoiceGender(gender: VoiceGender) = edit {
        it[PreferenceKeys.PREFERRED_VOICE_GENDER] = gender.id
    }

    override suspend fun setVoiceTranslationEnabled(enabled: Boolean) = edit {
        it[PreferenceKeys.VOICE_TRANSLATION_ENABLED] = enabled
    }

    override suspend fun setAutoPlayTranslation(enabled: Boolean) = edit {
        it[PreferenceKeys.AUTO_PLAY_TRANSLATION] = enabled
    }

    override suspend fun setSpeechSpeed(speed: Float) = edit {
        it[PreferenceKeys.SPEECH_SPEED] = speed.coerceIn(MIN_SPEED, MAX_SPEED)
    }

    override suspend fun setSpeechVolume(volume: Float) = edit {
        it[PreferenceKeys.SPEECH_VOLUME] = volume.coerceIn(0f, 1f)
    }

    override suspend fun setShowOriginalText(show: Boolean) = edit {
        it[PreferenceKeys.SHOW_ORIGINAL_TEXT] = show
    }

    override suspend fun setShowTranslation(show: Boolean) = edit {
        it[PreferenceKeys.SHOW_TRANSLATION] = show
    }

    override suspend fun setSaveHistory(enabled: Boolean) = edit {
        it[PreferenceKeys.SAVE_HISTORY] = enabled
    }

    override suspend fun setSaveAudio(enabled: Boolean) = edit {
        it[PreferenceKeys.SAVE_AUDIO] = enabled
    }

    override suspend fun setLatencyProfile(profile: LatencyProfile) = edit {
        it[PreferenceKeys.LATENCY_PROFILE] = profile.id
    }

    override suspend fun setThemeMode(mode: ThemeMode) = edit {
        it[PreferenceKeys.THEME_MODE] = mode.id
    }

    override suspend fun setTranslationCacheEnabled(enabled: Boolean) = edit {
        it[PreferenceKeys.TRANSLATION_CACHE_ENABLED] = enabled
    }

    private suspend fun edit(
        block: suspend (androidx.datastore.preferences.core.MutablePreferences) -> Unit,
    ) {
        dataStore.edit(block)
    }

    private fun Preferences.toAppSettings(): AppSettings {
        val overrides = AiProvider.concreteProviders.mapNotNull { provider ->
            this[PreferenceKeys.modelOverride(provider)]
                ?.takeIf { it.isNotBlank() }
                ?.let { provider to it }
        }.toMap()

        return AppSettings(
            activeProvider = AiProvider.fromId(this[PreferenceKeys.ACTIVE_PROVIDER]),
            modelOverrides = overrides,
            sourceLanguage = Language.fromCode(this[PreferenceKeys.SOURCE_LANGUAGE])
                ?: Language.DEFAULT_SOURCE,
            targetLanguage = Language.fromCode(this[PreferenceKeys.TARGET_LANGUAGE])
                ?: Language.DEFAULT_TARGET,
            conversationLanguageA = Language.fromCode(this[PreferenceKeys.CONVERSATION_LANGUAGE_A])
                ?: Language.PERSIAN,
            conversationLanguageB = Language.fromCode(this[PreferenceKeys.CONVERSATION_LANGUAGE_B])
                ?: Language.GERMAN,
            conversationTurnMode = ConversationTurnMode.fromId(
                this[PreferenceKeys.CONVERSATION_TURN_MODE],
            ),
            selectedVoiceId = this[PreferenceKeys.SELECTED_VOICE_ID]
                ?: VoiceProfile.DEVICE_DEFAULT.id,
            preferredVoiceGender = VoiceGender.fromId(this[PreferenceKeys.PREFERRED_VOICE_GENDER]),
            voiceTranslationEnabled = this[PreferenceKeys.VOICE_TRANSLATION_ENABLED] ?: true,
            autoPlayTranslation = this[PreferenceKeys.AUTO_PLAY_TRANSLATION] ?: true,
            speechSpeed = this[PreferenceKeys.SPEECH_SPEED] ?: 1.0f,
            speechVolume = this[PreferenceKeys.SPEECH_VOLUME] ?: 1.0f,
            showOriginalText = this[PreferenceKeys.SHOW_ORIGINAL_TEXT] ?: true,
            showTranslation = this[PreferenceKeys.SHOW_TRANSLATION] ?: true,
            saveHistory = this[PreferenceKeys.SAVE_HISTORY] ?: true,
            // Privacy default: audio is never kept unless the user opts in.
            saveAudio = this[PreferenceKeys.SAVE_AUDIO] ?: false,
            latencyProfile = LatencyProfile.fromId(this[PreferenceKeys.LATENCY_PROFILE]),
            themeMode = ThemeMode.fromId(this[PreferenceKeys.THEME_MODE]),
            translationCacheEnabled = this[PreferenceKeys.TRANSLATION_CACHE_ENABLED] ?: true,
        )
    }

    private companion object {
        const val MIN_SPEED = 0.5f
        const val MAX_SPEED = 2.0f
    }
}
