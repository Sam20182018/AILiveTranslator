package com.aitranslator.live.core.data.repository

import android.content.Context
import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.common.DispatcherProvider
import com.aitranslator.live.core.common.Logger
import com.aitranslator.live.core.domain.audio.AudioPlayer
import com.aitranslator.live.core.domain.model.AiModelConfig
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.TtsEngine
import com.aitranslator.live.core.domain.model.VoiceProfile
import com.aitranslator.live.core.domain.provider.AIProviderRegistry
import com.aitranslator.live.core.domain.repository.ApiKeyRepository
import com.aitranslator.live.core.domain.repository.SettingsRepository
import com.aitranslator.live.core.domain.repository.SpeechRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Routes speech work to whichever service can actually do it.
 *
 * This is where the app is honest about vendor gaps: Claude has no audio endpoints, and
 * Gemini has no text-to-speech in this integration, so choosing them as the *translation*
 * provider must not break the microphone. Speech recognition falls back OpenAI → Gemini and
 * synthesis falls back OpenAI → device TTS, and the fallback is logged rather than hidden.
 */
@Singleton
class SpeechRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val registry: AIProviderRegistry,
    private val apiKeyRepository: ApiKeyRepository,
    private val settingsRepository: SettingsRepository,
    private val audioPlayer: AudioPlayer,
    private val dispatchers: DispatcherProvider,
) : SpeechRepository {

    override suspend fun transcribe(
        wavAudio: ByteArray,
        language: Language,
    ): AppResult<String> = withContext(dispatchers.io) {
        if (wavAudio.isEmpty()) {
            return@withContext AppResult.Failure(AppError.EmptyInput("no audio captured"))
        }

        val settings = settingsRepository.current()
        val candidates = buildList {
            if (settings.activeProvider.isConcrete) add(settings.activeProvider)
            addAll(STT_PREFERENCE_ORDER)
        }.distinct()

        for (provider in candidates) {
            val implementation = registry.speechRecognitionProvider(provider) ?: continue
            val key = apiKeyRepository.getKey(provider)
            if (key.isNullOrBlank()) continue

            val model = AiModelConfig.defaultFor(provider).transcriptionModel
            if (model.isBlank()) continue

            Logger.d(TAG, "transcribing with ${provider.id}")
            return@withContext implementation.transcribe(wavAudio, language, key, model)
        }

        AppResult.Failure(
            AppError.NotConfigured(
                "speech-to-text",
                "no provider with speech recognition has a key (OpenAI or Gemini required)",
            ),
        )
    }

    override suspend fun speak(
        text: String,
        language: Language,
        persistAudio: Boolean,
    ): AppResult<String?> = withContext(dispatchers.io) {
        if (text.isBlank()) return@withContext AppResult.Success(null)

        val settings = settingsRepository.current()
        val voice = selectedVoice()

        val engineOrder = buildList {
            add(voice.engine)
            addAll(TtsEngine.entries.filter { it != voice.engine })
        }

        var lastError: AppError = AppError.CapabilityUnavailable("tts", "no engine available")

        for (engine in engineOrder) {
            val provider = registry.textToSpeechProvider(engine) ?: continue
            val effectiveVoice = if (engine == voice.engine) voice else VoiceProfile.DEVICE_DEFAULT

            val synthesis = provider.synthesize(
                text = text,
                language = language,
                voice = effectiveVoice,
                speed = settings.speechSpeed,
                volume = settings.speechVolume,
            )

            when (synthesis) {
                is AppResult.Failure -> {
                    Logger.d(TAG, "TTS engine ${engine.id} failed, trying next")
                    lastError = synthesis.error
                }

                is AppResult.Success -> {
                    val audio = synthesis.data.audio
                    if (audio == null) {
                        // Device engine already spoke it.
                        return@withContext AppResult.Success(null)
                    }

                    val savedPath = if (persistAudio) {
                        saveAudio(audio.bytes, audio.fileExtension)
                    } else {
                        null
                    }

                    val played = audioPlayer.play(audio, settings.speechVolume)
                    return@withContext when (played) {
                        is AppResult.Failure -> played
                        is AppResult.Success -> AppResult.Success(savedPath)
                    }
                }
            }
        }

        AppResult.Failure(lastError)
    }

    override suspend fun stopSpeaking() {
        audioPlayer.stop()
        TtsEngine.entries.forEach { engine ->
            registry.textToSpeechProvider(engine)?.stop()
        }
    }

    override suspend fun voiceCatalogue(): List<VoiceProfile> = withContext(dispatchers.io) {
        val cloud = registry.textToSpeechProvider(TtsEngine.OPENAI)?.availableVoices().orEmpty()
        val device = registry.textToSpeechProvider(TtsEngine.ANDROID)?.availableVoices().orEmpty()
        // Cloud voices first: they are the ones the spec guarantees (5 male + 5 female).
        (cloud + device).distinctBy { it.id }
    }

    override suspend fun selectedVoice(): VoiceProfile {
        val selectedId = settingsRepository.current().selectedVoiceId
        VoiceProfile.OPENAI_VOICES.firstOrNull { it.id == selectedId }?.let { return it }
        if (selectedId == VoiceProfile.DEVICE_DEFAULT.id) return VoiceProfile.DEVICE_DEFAULT

        return voiceCatalogue().firstOrNull { it.id == selectedId }
            ?: VoiceProfile.DEVICE_DEFAULT
    }

    override suspend fun previewVoice(
        voice: VoiceProfile,
        language: Language,
    ): AppResult<Unit> = withContext(dispatchers.io) {
        val settings = settingsRepository.current()
        val provider = registry.textToSpeechProvider(voice.engine)
            ?: return@withContext AppResult.Failure(
                AppError.CapabilityUnavailable(voice.engine.id, "engine not available"),
            )

        val sample = previewSentence(language)
        val synthesis = provider.synthesize(
            text = sample,
            language = language,
            voice = voice,
            speed = settings.speechSpeed,
            volume = settings.speechVolume,
        )

        when (synthesis) {
            is AppResult.Failure -> synthesis
            is AppResult.Success -> {
                val audio = synthesis.data.audio
                    ?: return@withContext AppResult.Success(Unit)
                audioPlayer.play(audio, settings.speechVolume)
            }
        }
    }

    private fun saveAudio(bytes: ByteArray, extension: String): String? = runCatching {
        val directory = File(context.filesDir, AUDIO_DIRECTORY).apply { mkdirs() }
        val file = File(directory, "translation_${System.currentTimeMillis()}.$extension")
        file.writeBytes(bytes)
        file.absolutePath
    }.getOrNull()

    private fun previewSentence(language: Language): String = when (language) {
        Language.PERSIAN -> "سلام، این یک نمونه صدا برای ترجمه زنده است."
        Language.ENGLISH -> "Hello, this is a voice sample for live translation."
        Language.ARABIC -> "مرحبًا، هذه عينة صوتية للترجمة الفورية."
        Language.FRENCH -> "Bonjour, ceci est un échantillon vocal pour la traduction en direct."
        Language.DUTCH -> "Hallo, dit is een stemvoorbeeld voor live vertaling."
        Language.GERMAN -> "Hallo, dies ist eine Sprachprobe für die Live-Übersetzung."
    }

    private companion object {
        const val TAG = "SpeechRepository"
        const val AUDIO_DIRECTORY = "translation_audio"

        /** Claude is absent on purpose: it has no audio input endpoint. */
        val STT_PREFERENCE_ORDER = listOf(AiProvider.OPENAI, AiProvider.GEMINI)
    }
}
