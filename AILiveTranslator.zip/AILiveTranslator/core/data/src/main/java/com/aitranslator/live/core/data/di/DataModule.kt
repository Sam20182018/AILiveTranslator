package com.aitranslator.live.core.data.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.preferencesDataStoreFile
import androidx.room.Room
import com.aitranslator.live.core.common.ApplicationScope
import com.aitranslator.live.core.common.DispatcherProvider
import com.aitranslator.live.core.data.db.AppDatabase
import com.aitranslator.live.core.data.db.HistoryDao
import com.aitranslator.live.core.data.registry.DefaultAIProviderRegistry
import com.aitranslator.live.core.data.repository.ApiKeyRepositoryImpl
import com.aitranslator.live.core.data.repository.HistoryRepositoryImpl
import com.aitranslator.live.core.data.repository.SettingsRepositoryImpl
import com.aitranslator.live.core.data.repository.SpeechRepositoryImpl
import com.aitranslator.live.core.data.repository.TranslationRepositoryImpl
import com.aitranslator.live.core.domain.provider.AIProviderRegistry
import com.aitranslator.live.core.domain.repository.ApiKeyRepository
import com.aitranslator.live.core.domain.repository.HistoryRepository
import com.aitranslator.live.core.domain.repository.SettingsRepository
import com.aitranslator.live.core.domain.repository.SpeechRepository
import com.aitranslator.live.core.domain.repository.TranslationRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DataModule {

    private const val SETTINGS_DATASTORE = "translator_settings"

    @Provides
    @Singleton
    fun providePreferencesDataStore(
        @ApplicationContext context: Context,
        @ApplicationScope scope: CoroutineScope,
        dispatchers: DispatcherProvider,
    ): DataStore<Preferences> = PreferenceDataStoreFactory.create(
        // A corrupt preferences file must not brick the app; the user re-enters their keys.
        corruptionHandler = ReplaceFileCorruptionHandler { emptyPreferences() },
        scope = CoroutineScope(scope.coroutineContext + dispatchers.io),
        produceFile = { context.preferencesDataStoreFile(SETTINGS_DATASTORE) },
    )

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, AppDatabase.NAME)
            // History is a convenience log, not a source of truth: a schema change may
            // rebuild it rather than shipping a migration for every release.
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun provideHistoryDao(database: AppDatabase): HistoryDao = database.historyDao()
}

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindSettingsRepository(impl: SettingsRepositoryImpl): SettingsRepository

    @Binds
    @Singleton
    abstract fun bindApiKeyRepository(impl: ApiKeyRepositoryImpl): ApiKeyRepository

    @Binds
    @Singleton
    abstract fun bindTranslationRepository(impl: TranslationRepositoryImpl): TranslationRepository

    @Binds
    @Singleton
    abstract fun bindSpeechRepository(impl: SpeechRepositoryImpl): SpeechRepository

    @Binds
    @Singleton
    abstract fun bindHistoryRepository(impl: HistoryRepositoryImpl): HistoryRepository

    @Binds
    @Singleton
    abstract fun bindProviderRegistry(impl: DefaultAIProviderRegistry): AIProviderRegistry
}
