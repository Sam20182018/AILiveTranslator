package com.aitranslator.live.core.data.repository

import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.common.DispatcherProvider
import com.aitranslator.live.core.common.Logger
import com.aitranslator.live.core.common.NetworkMonitor
import com.aitranslator.live.core.data.cache.TranslationCache
import com.aitranslator.live.core.domain.model.AiModelConfig
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.AppSettings
import com.aitranslator.live.core.domain.model.TranslationChunk
import com.aitranslator.live.core.domain.model.TranslationRequest
import com.aitranslator.live.core.domain.model.TranslationResult
import com.aitranslator.live.core.domain.provider.AIProviderRegistry
import com.aitranslator.live.core.domain.provider.AITranslationProvider
import com.aitranslator.live.core.domain.provider.TranslationStreamException
import com.aitranslator.live.core.domain.repository.ApiKeyRepository
import com.aitranslator.live.core.domain.repository.SettingsRepository
import com.aitranslator.live.core.domain.repository.TranslationRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Resolves provider + key + model, applies the cache, and delegates to the vendor
 * implementation. History is deliberately **not** written here — use cases own that, so a
 * single logical translation cannot be recorded twice.
 */
@Singleton
class TranslationRepositoryImpl @Inject constructor(
    private val registry: AIProviderRegistry,
    private val apiKeyRepository: ApiKeyRepository,
    private val settingsRepository: SettingsRepository,
    private val networkMonitor: NetworkMonitor,
    private val cache: TranslationCache,
    private val dispatchers: DispatcherProvider,
) : TranslationRepository {

    override suspend fun translate(
        request: TranslationRequest,
    ): AppResult<TranslationResult> = withContext(dispatchers.io) {
        val settings = settingsRepository.current()

        if (settings.translationCacheEnabled) {
            cache.get(request.text, request.sourceLanguage, request.targetLanguage)?.let { hit ->
                Logger.d(TAG, "cache hit")
                return@withContext AppResult.Success(hit.copy(fromCache = true))
            }
        }

        if (!networkMonitor.isCurrentlyOnline()) {
            return@withContext AppResult.Failure(AppError.NoInternet())
        }

        val resolved = resolve(settings)
        val (provider, implementation, apiKey) = when (resolved) {
            is AppResult.Failure -> return@withContext resolved
            is AppResult.Success -> resolved.data
        }

        val model = settings.modelFor(provider)
        val defaults = AiModelConfig.defaultFor(provider)

        val result = implementation.translate(
            request = request,
            apiKey = apiKey,
            model = model,
            maxOutputTokens = defaults.maxOutputTokens,
            temperature = defaults.temperature,
        )

        result.onSuccess { translation ->
            if (settings.translationCacheEnabled) {
                cache.put(
                    request.text,
                    request.sourceLanguage,
                    request.targetLanguage,
                    translation,
                )
            }
        }

        result
    }

    override fun translateStreaming(request: TranslationRequest): Flow<TranslationChunk> = flow {
        val settings = settingsRepository.current()

        if (settings.translationCacheEnabled) {
            cache.get(request.text, request.sourceLanguage, request.targetLanguage)?.let { hit ->
                emit(TranslationChunk.Delta(hit.translatedText))
                emit(TranslationChunk.Completed(hit.translatedText))
                return@flow
            }
        }

        if (!networkMonitor.isCurrentlyOnline()) {
            throw TranslationStreamException(AppError.NoInternet())
        }

        val resolved = resolve(settings)
        val (provider, implementation, apiKey) = when (resolved) {
            is AppResult.Failure -> throw TranslationStreamException(resolved.error)
            is AppResult.Success -> resolved.data
        }

        val model = settings.modelFor(provider)
        val defaults = AiModelConfig.defaultFor(provider)

        if (!implementation.supportsStreaming) {
            // Non-streaming providers still work: one call, delivered as a single delta.
            when (
                val single = implementation.translate(
                    request,
                    apiKey,
                    model,
                    defaults.maxOutputTokens,
                    defaults.temperature,
                )
            ) {
                is AppResult.Failure -> throw TranslationStreamException(single.error)
                is AppResult.Success -> {
                    emit(TranslationChunk.Delta(single.data.translatedText))
                    emit(TranslationChunk.Completed(single.data.translatedText))
                }
            }
            return@flow
        }

        var lastText = ""
        implementation.translateStream(
            request = request,
            apiKey = apiKey,
            model = model,
            maxOutputTokens = defaults.maxOutputTokens,
            temperature = defaults.temperature,
        ).collect { chunk ->
            if (chunk is TranslationChunk.Completed) lastText = chunk.fullText
            emit(chunk)
        }

        if (settings.translationCacheEnabled && lastText.isNotBlank()) {
            cache.put(
                request.text,
                request.sourceLanguage,
                request.targetLanguage,
                TranslationResult(
                    originalText = request.text,
                    translatedText = lastText,
                    sourceLanguage = request.sourceLanguage,
                    targetLanguage = request.targetLanguage,
                    provider = provider,
                    model = model,
                    latencyMillis = 0L,
                ),
            )
        }
    }.flowOn(dispatchers.io)

    override suspend fun resolveProvider(): AppResult<AiProvider> =
        resolve(settingsRepository.current()).map { it.provider }

    override suspend fun testConnection(
        provider: AiProvider,
        key: String?,
        model: String?,
    ): AppResult<Unit> = withContext(dispatchers.io) {
        val implementation = registry.translationProvider(provider)
            ?: return@withContext AppResult.Failure(
                AppError.NotConfigured(provider.id, "no implementation for this provider"),
            )

        val apiKey = key?.trim()?.takeIf { it.isNotEmpty() }
            ?: apiKeyRepository.getKey(provider)
            ?: return@withContext AppResult.Failure(AppError.NotConfigured(provider.id))

        val effectiveModel = model?.takeIf { it.isNotBlank() }
            ?: settingsRepository.current().modelFor(provider)

        implementation.testConnection(apiKey, effectiveModel)
    }

    override fun clearCache() = cache.clear()

    /** Provider, its implementation and a usable key — the three things every call needs. */
    private data class Resolved(
        val provider: AiProvider,
        val implementation: AITranslationProvider,
        val apiKey: String,
    )

    private suspend fun resolve(settings: AppSettings): AppResult<Resolved> {
        val candidates = if (settings.activeProvider.isConcrete) {
            listOf(settings.activeProvider)
        } else {
            autoOrder()
        }

        if (candidates.isEmpty()) {
            return AppResult.Failure(
                AppError.NotConfigured("none", "no API key has been saved yet"),
            )
        }

        var lastError: AppError = AppError.NotConfigured("none")

        for (provider in candidates) {
            val implementation = registry.translationProvider(provider)
            if (implementation == null) {
                lastError = AppError.NotConfigured(provider.id, "provider not compiled in")
                continue
            }
            val key = apiKeyRepository.getKey(provider)
            if (key.isNullOrBlank()) {
                lastError = AppError.NotConfigured(provider.id, "no key stored")
                continue
            }
            return AppResult.Success(Resolved(provider, implementation, key))
        }

        return AppResult.Failure(lastError)
    }

    /**
     * AUTO ranking. Providers the user marked active and that have a key come first, with
     * anything that failed its last validation pushed to the back, then the static
     * preference order below.
     */
    private suspend fun autoOrder(): List<AiProvider> {
        val entries = apiKeyRepository.entries.first()
        val usable = entries.filter { it.isStored && it.isActive }

        return usable
            .sortedWith(
                compareBy<com.aitranslator.live.core.domain.model.ApiKeyEntry> {
                    if (it.lastValidationSucceeded == false) 1 else 0
                }.thenBy { PREFERENCE_ORDER.indexOf(it.provider).takeIf { i -> i >= 0 } ?: 99 },
            )
            .map { it.provider }
    }

    private companion object {
        const val TAG = "TranslationRepository"

        /**
         * Text translation quality is comparable across all three at this price point, so
         * the order reflects breadth of capability: OpenAI also covers STT and TTS, Gemini
         * covers STT, Claude is translation-only.
         */
        val PREFERENCE_ORDER = listOf(AiProvider.OPENAI, AiProvider.GEMINI, AiProvider.CLAUDE)
    }
}
