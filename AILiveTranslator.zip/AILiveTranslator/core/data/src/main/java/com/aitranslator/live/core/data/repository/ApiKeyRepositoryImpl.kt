package com.aitranslator.live.core.data.repository

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.common.Logger
import com.aitranslator.live.core.data.datastore.PreferenceKeys
import com.aitranslator.live.core.data.security.KeystoreCrypto
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.ApiKeyEntry
import com.aitranslator.live.core.domain.repository.ApiKeyRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Keys are encrypted with a Keystore-backed AES/GCM key before they touch disk, and are
 * decrypted only inside [getKey], which is called at request-build time. The UI observes
 * [entries], which contains masks and status flags but never a usable key.
 */
@Singleton
class ApiKeyRepositoryImpl @Inject constructor(
    private val dataStore: DataStore<Preferences>,
    private val crypto: KeystoreCrypto,
) : ApiKeyRepository {

    override val entries: Flow<List<ApiKeyEntry>> = dataStore.data.map { preferences ->
        AiProvider.concreteProviders.map { provider ->
            val stored = !preferences[PreferenceKeys.encryptedApiKey(provider)].isNullOrBlank()
            ApiKeyEntry(
                provider = provider,
                isStored = stored,
                isActive = preferences[PreferenceKeys.apiKeyActive(provider)] ?: stored,
                maskedKey = preferences[PreferenceKeys.apiKeyMask(provider)].orEmpty(),
                lastValidatedMillis = preferences[PreferenceKeys.apiKeyValidatedAt(provider)],
                lastValidationSucceeded = preferences[PreferenceKeys.apiKeyValidatedOk(provider)],
            )
        }
    }

    override suspend fun saveKey(provider: AiProvider, key: String): AppResult<Unit> {
        val trimmed = key.trim()
        if (trimmed.isEmpty()) {
            return AppResult.Failure(AppError.EmptyInput("API key is empty"))
        }
        if (!provider.isConcrete) {
            return AppResult.Failure(AppError.NotConfigured(provider.id, "AUTO has no key"))
        }

        val encrypted = crypto.encrypt(trimmed)
            ?: return AppResult.Failure(
                AppError.Unknown("could not encrypt the key on this device"),
            )

        dataStore.edit { preferences ->
            preferences[PreferenceKeys.encryptedApiKey(provider)] = encrypted
            preferences[PreferenceKeys.apiKeyMask(provider)] = Logger.mask(trimmed)
            preferences[PreferenceKeys.apiKeyActive(provider)] = true
            preferences.remove(PreferenceKeys.apiKeyValidatedAt(provider))
            preferences.remove(PreferenceKeys.apiKeyValidatedOk(provider))
        }
        return AppResult.Success(Unit)
    }

    override suspend fun getKey(provider: AiProvider): String? {
        if (!provider.isConcrete) return null
        val encrypted = dataStore.data.first()[PreferenceKeys.encryptedApiKey(provider)]
        if (encrypted.isNullOrBlank()) return null
        return crypto.decrypt(encrypted)
    }

    override suspend fun deleteKey(provider: AiProvider): AppResult<Unit> {
        dataStore.edit { preferences ->
            preferences.remove(PreferenceKeys.encryptedApiKey(provider))
            preferences.remove(PreferenceKeys.apiKeyMask(provider))
            preferences.remove(PreferenceKeys.apiKeyActive(provider))
            preferences.remove(PreferenceKeys.apiKeyValidatedAt(provider))
            preferences.remove(PreferenceKeys.apiKeyValidatedOk(provider))
        }
        return AppResult.Success(Unit)
    }

    override suspend fun setActive(provider: AiProvider, active: Boolean) {
        dataStore.edit { it[PreferenceKeys.apiKeyActive(provider)] = active }
    }

    override suspend fun recordValidation(provider: AiProvider, succeeded: Boolean) {
        dataStore.edit { preferences ->
            preferences[PreferenceKeys.apiKeyValidatedAt(provider)] = System.currentTimeMillis()
            preferences[PreferenceKeys.apiKeyValidatedOk(provider)] = succeeded
        }
    }

    override suspend fun activeProvidersWithKeys(): List<AiProvider> =
        entries.first()
            .filter { it.isStored && it.isActive }
            .map { it.provider }
}
