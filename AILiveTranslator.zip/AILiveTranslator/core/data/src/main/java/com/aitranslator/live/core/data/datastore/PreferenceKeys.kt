package com.aitranslator.live.core.data.datastore

import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.aitranslator.live.core.domain.model.AiProvider

/** Every key used by the settings DataStore, in one place so nothing collides. */
internal object PreferenceKeys {

    val ACTIVE_PROVIDER = stringPreferencesKey("active_provider")
    val SOURCE_LANGUAGE = stringPreferencesKey("source_language")
    val TARGET_LANGUAGE = stringPreferencesKey("target_language")
    val CONVERSATION_LANGUAGE_A = stringPreferencesKey("conversation_language_a")
    val CONVERSATION_LANGUAGE_B = stringPreferencesKey("conversation_language_b")
    val CONVERSATION_TURN_MODE = stringPreferencesKey("conversation_turn_mode")
    val SELECTED_VOICE_ID = stringPreferencesKey("selected_voice_id")
    val PREFERRED_VOICE_GENDER = stringPreferencesKey("preferred_voice_gender")
    val VOICE_TRANSLATION_ENABLED = booleanPreferencesKey("voice_translation_enabled")
    val AUTO_PLAY_TRANSLATION = booleanPreferencesKey("auto_play_translation")
    val SPEECH_SPEED = floatPreferencesKey("speech_speed")
    val SPEECH_VOLUME = floatPreferencesKey("speech_volume")
    val SHOW_ORIGINAL_TEXT = booleanPreferencesKey("show_original_text")
    val SHOW_TRANSLATION = booleanPreferencesKey("show_translation")
    val SAVE_HISTORY = booleanPreferencesKey("save_history")
    val SAVE_AUDIO = booleanPreferencesKey("save_audio")
    val LATENCY_PROFILE = stringPreferencesKey("latency_profile")
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val TRANSLATION_CACHE_ENABLED = booleanPreferencesKey("translation_cache_enabled")

    fun modelOverride(provider: AiProvider) = stringPreferencesKey("model_override_${provider.id}")

    /** Base64 of the Keystore-encrypted key — never the key itself. */
    fun encryptedApiKey(provider: AiProvider) = stringPreferencesKey("api_key_enc_${provider.id}")

    fun apiKeyActive(provider: AiProvider) = booleanPreferencesKey("api_key_active_${provider.id}")

    fun apiKeyValidatedAt(provider: AiProvider) =
        longPreferencesKey("api_key_validated_at_${provider.id}")

    fun apiKeyValidatedOk(provider: AiProvider) =
        booleanPreferencesKey("api_key_validated_ok_${provider.id}")

    /** Kept only so a masked value can be shown without decrypting anything. */
    fun apiKeyMask(provider: AiProvider) = stringPreferencesKey("api_key_mask_${provider.id}")
}
