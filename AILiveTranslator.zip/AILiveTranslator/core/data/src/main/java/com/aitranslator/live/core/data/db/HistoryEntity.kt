package com.aitranslator.live.core.data.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.HistoryEntry
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.TranslationMode

@Entity(
    tableName = "translation_history",
    indices = [Index(value = ["timestamp_millis"])],
)
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    @ColumnInfo(name = "timestamp_millis")
    val timestampMillis: Long,

    @ColumnInfo(name = "source_language")
    val sourceLanguage: String,

    @ColumnInfo(name = "target_language")
    val targetLanguage: String,

    @ColumnInfo(name = "original_text")
    val originalText: String,

    @ColumnInfo(name = "translated_text")
    val translatedText: String,

    @ColumnInfo(name = "mode")
    val mode: String,

    @ColumnInfo(name = "provider")
    val provider: String,

    @ColumnInfo(name = "audio_file_path")
    val audioFilePath: String?,
)

internal fun HistoryEntity.toDomain(): HistoryEntry = HistoryEntry(
    id = id,
    timestampMillis = timestampMillis,
    sourceLanguage = Language.fromCodeOrDefault(sourceLanguage),
    targetLanguage = Language.fromCodeOrDefault(targetLanguage),
    originalText = originalText,
    translatedText = translatedText,
    mode = TranslationMode.fromId(mode),
    provider = AiProvider.fromId(provider),
    audioFilePath = audioFilePath,
)

internal fun HistoryEntry.toEntity(): HistoryEntity = HistoryEntity(
    id = id,
    timestampMillis = timestampMillis,
    sourceLanguage = sourceLanguage.code,
    targetLanguage = targetLanguage.code,
    originalText = originalText,
    translatedText = translatedText,
    mode = mode.id,
    provider = provider.id,
    audioFilePath = audioFilePath,
)
