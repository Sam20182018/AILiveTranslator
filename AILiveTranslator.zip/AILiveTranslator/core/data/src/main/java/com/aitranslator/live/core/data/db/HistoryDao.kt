package com.aitranslator.live.core.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {

    @Query("SELECT * FROM translation_history ORDER BY timestamp_millis DESC")
    fun observeAll(): Flow<List<HistoryEntity>>

    /**
     * `LIKE` is enough here: history is a few thousand rows at most, so an FTS table would
     * add a migration surface for no measurable gain.
     */
    @Query(
        """
        SELECT * FROM translation_history
        WHERE original_text LIKE '%' || :query || '%'
           OR translated_text LIKE '%' || :query || '%'
        ORDER BY timestamp_millis DESC
        """,
    )
    fun search(query: String): Flow<List<HistoryEntity>>

    @Insert
    suspend fun insert(entity: HistoryEntity): Long

    @Query("SELECT * FROM translation_history WHERE id = :id")
    suspend fun findById(id: Long): HistoryEntity?

    @Query("SELECT audio_file_path FROM translation_history WHERE audio_file_path IS NOT NULL")
    suspend fun allAudioPaths(): List<String>

    @Query("DELETE FROM translation_history WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM translation_history")
    suspend fun deleteAll()

    @Query("UPDATE translation_history SET audio_file_path = NULL")
    suspend fun clearAudioPaths()
}
