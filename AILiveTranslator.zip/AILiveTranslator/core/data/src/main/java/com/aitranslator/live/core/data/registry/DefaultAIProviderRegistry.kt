package com.aitranslator.live.core.data.registry

import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.TtsEngine
import com.aitranslator.live.core.domain.provider.AIProviderRegistry
import com.aitranslator.live.core.domain.provider.AITranslationProvider
import com.aitranslator.live.core.domain.provider.SpeechRecognitionProvider
import com.aitranslator.live.core.domain.provider.TextToSpeechProvider
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Indexes whatever provider implementations Hilt found.
 *
 * Because it is driven by multibindings rather than a hard-coded `when`, adding a vendor is
 * a single `@Binds @IntoSet` line in the module that implements it.
 */
@Singleton
class DefaultAIProviderRegistry @Inject constructor(
    translationProviders: Set<@JvmSuppressWildcards AITranslationProvider>,
    speechRecognitionProviders: Set<@JvmSuppressWildcards SpeechRecognitionProvider>,
    textToSpeechProviders: Set<@JvmSuppressWildcards TextToSpeechProvider>,
) : AIProviderRegistry {

    private val translationByProvider: Map<AiProvider, AITranslationProvider> =
        translationProviders.associateBy { it.provider }

    private val sttByProvider: Map<AiProvider, SpeechRecognitionProvider> =
        speechRecognitionProviders.associateBy { it.provider }

    private val ttsByEngine: Map<TtsEngine, TextToSpeechProvider> =
        textToSpeechProviders.associateBy { it.engine }

    override fun translationProvider(provider: AiProvider): AITranslationProvider? =
        translationByProvider[provider]

    override fun speechRecognitionProvider(provider: AiProvider): SpeechRecognitionProvider? =
        sttByProvider[provider]

    override fun textToSpeechProvider(engine: TtsEngine): TextToSpeechProvider? =
        ttsByEngine[engine]

    override fun availableTranslationProviders(): List<AiProvider> =
        AiProvider.concreteProviders.filter { translationByProvider.containsKey(it) }

    override fun availableSpeechRecognitionProviders(): List<AiProvider> =
        AiProvider.concreteProviders.filter { sttByProvider.containsKey(it) }
}
