package com.aitranslator.live.core.data.repository

import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.common.DispatcherProvider
import com.aitranslator.live.core.common.NetworkMonitor
import com.aitranslator.live.core.data.cache.TranslationCache
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.ApiKeyEntry
import com.aitranslator.live.core.domain.model.AppSettings
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.TranslationChunk
import com.aitranslator.live.core.domain.model.TranslationRequest
import com.aitranslator.live.core.domain.model.TranslationResult
import com.aitranslator.live.core.domain.model.TtsEngine
import com.aitranslator.live.core.domain.provider.AIProviderRegistry
import com.aitranslator.live.core.domain.provider.AITranslationProvider
import com.aitranslator.live.core.domain.provider.SpeechRecognitionProvider
import com.aitranslator.live.core.domain.provider.TextToSpeechProvider
import com.aitranslator.live.core.domain.repository.ApiKeyRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Covers the decisions this class actually owns: cache use, AUTO provider selection, the
 * offline short-circuit and what happens when no key is configured.
 */
class TranslationRepositoryImplTest {

    private val request = TranslationRequest(
        text = "سلام",
        sourceLanguage = Language.PERSIAN,
        targetLanguage = Language.ENGLISH,
    )

    private class FakeTranslationProvider(
        override val provider: AiProvider,
        private val answer: String = "Hello",
    ) : AITranslationProvider {
        var calls = 0
        override val supportsStreaming = true

        override suspend fun translate(
            request: TranslationRequest,
            apiKey: String,
            model: String,
            maxOutputTokens: Int,
            temperature: Float,
        ): AppResult<TranslationResult> {
            calls++
            return AppResult.Success(
                TranslationResult(
                    originalText = request.text,
                    translatedText = answer,
                    sourceLanguage = request.sourceLanguage,
                    targetLanguage = request.targetLanguage,
                    provider = provider,
                    model = model,
                    latencyMillis = 1,
                ),
            )
        }

        override fun translateStream(
            request: TranslationRequest,
            apiKey: String,
            model: String,
            maxOutputTokens: Int,
            temperature: Float,
        ): Flow<TranslationChunk> = flowOf(
            TranslationChunk.Delta(answer),
            TranslationChunk.Completed(answer),
        )

        override suspend fun testConnection(apiKey: String, model: String): AppResult<Unit> =
            AppResult.Success(Unit)
    }

    private class FakeRegistry(
        private val providers: List<AITranslationProvider>,
    ) : AIProviderRegistry {
        override fun translationProvider(provider: AiProvider): AITranslationProvider? =
            providers.firstOrNull { it.provider == provider }

        override fun speechRecognitionProvider(provider: AiProvider): SpeechRecognitionProvider? =
            null

        override fun textToSpeechProvider(engine: TtsEngine): TextToSpeechProvider? = null

        override fun availableTranslationProviders(): List<AiProvider> =
            providers.map { it.provider }

        override fun availableSpeechRecognitionProviders(): List<AiProvider> = emptyList()
    }

    private class FakeApiKeyRepository(
        private val keys: MutableMap<AiProvider, String> = mutableMapOf(),
        private val failedValidation: Set<AiProvider> = emptySet(),
    ) : ApiKeyRepository {
        override val entries: Flow<List<ApiKeyEntry>> = MutableStateFlow(
            keys.map { (provider, _) ->
                ApiKeyEntry(
                    provider = provider,
                    isStored = true,
                    isActive = true,
                    maskedKey = "••••",
                    lastValidationSucceeded = provider !in failedValidation,
                )
            },
        )

        override suspend fun saveKey(provider: AiProvider, key: String): AppResult<Unit> {
            keys[provider] = key
            return AppResult.Success(Unit)
        }

        override suspend fun getKey(provider: AiProvider): String? = keys[provider]

        override suspend fun deleteKey(provider: AiProvider): AppResult<Unit> {
            keys.remove(provider)
            return AppResult.Success(Unit)
        }

        override suspend fun setActive(provider: AiProvider, active: Boolean) = Unit

        override suspend fun recordValidation(provider: AiProvider, succeeded: Boolean) = Unit

        override suspend fun activeProvidersWithKeys(): List<AiProvider> = keys.keys.toList()
    }

    private class FakeNetworkMonitor(private val online: Boolean) : NetworkMonitor {
        override val isOnline: Flow<Boolean> = flowOf(online)
        override fun isCurrentlyOnline(): Boolean = online
    }

    private class TestDispatchers : DispatcherProvider {
        private val dispatcher = UnconfinedTestDispatcher()
        override val main = dispatcher
        override val io = dispatcher
        override val default = dispatcher
    }

    private fun repository(
        providers: List<AITranslationProvider>,
        keys: MutableMap<AiProvider, String>,
        settings: AppSettings = AppSettings(),
        online: Boolean = true,
        cache: TranslationCache = TranslationCache(),
        failedValidation: Set<AiProvider> = emptySet(),
    ) = TranslationRepositoryImpl(
        registry = FakeRegistry(providers),
        apiKeyRepository = FakeApiKeyRepository(keys, failedValidation),
        settingsRepository = FakeSettingsRepository(settings),
        networkMonitor = FakeNetworkMonitor(online),
        cache = cache,
        dispatchers = TestDispatchers(),
    )

    @Test
    fun `translates with the explicitly selected provider`() = runTest {
        val openAi = FakeTranslationProvider(AiProvider.OPENAI, "Hello")
        val repo = repository(
            providers = listOf(openAi),
            keys = mutableMapOf(AiProvider.OPENAI to "test-key"),
            settings = AppSettings(activeProvider = AiProvider.OPENAI),
        )

        val result = repo.translate(request)

        assertEquals("Hello", (result as AppResult.Success).data.translatedText)
        assertEquals(1, openAi.calls)
    }

    @Test
    fun `a second identical request is served from the cache`() = runTest {
        val openAi = FakeTranslationProvider(AiProvider.OPENAI, "Hello")
        val repo = repository(
            providers = listOf(openAi),
            keys = mutableMapOf(AiProvider.OPENAI to "test-key"),
            settings = AppSettings(activeProvider = AiProvider.OPENAI),
        )

        repo.translate(request)
        val second = repo.translate(request)

        assertEquals(1, openAi.calls)
        assertTrue((second as AppResult.Success).data.fromCache)
    }

    @Test
    fun `auto mode falls back to the next provider that has a key`() = runTest {
        val gemini = FakeTranslationProvider(AiProvider.GEMINI, "Hallo")
        val repo = repository(
            providers = listOf(FakeTranslationProvider(AiProvider.OPENAI), gemini),
            keys = mutableMapOf(AiProvider.GEMINI to "test-key"),
            settings = AppSettings(activeProvider = AiProvider.AUTO),
        )

        val result = repo.translate(request)

        assertEquals(AiProvider.GEMINI, (result as AppResult.Success).data.provider)
        assertEquals(1, gemini.calls)
    }

    @Test
    fun `auto mode deprioritises a provider whose last validation failed`() = runTest {
        val openAi = FakeTranslationProvider(AiProvider.OPENAI, "Hello")
        val gemini = FakeTranslationProvider(AiProvider.GEMINI, "Hallo")
        val repo = repository(
            providers = listOf(openAi, gemini),
            keys = mutableMapOf(AiProvider.OPENAI to "k1", AiProvider.GEMINI to "k2"),
            settings = AppSettings(activeProvider = AiProvider.AUTO),
            failedValidation = setOf(AiProvider.OPENAI),
        )

        val result = repo.translate(request)

        assertEquals(AiProvider.GEMINI, (result as AppResult.Success).data.provider)
    }

    @Test
    fun `no configured key produces a NotConfigured error, never a crash`() = runTest {
        val repo = repository(
            providers = listOf(FakeTranslationProvider(AiProvider.OPENAI)),
            keys = mutableMapOf(),
            settings = AppSettings(activeProvider = AiProvider.AUTO),
        )

        val result = repo.translate(request)

        assertTrue((result as AppResult.Failure).error is AppError.NotConfigured)
    }

    @Test
    fun `offline short-circuits before any provider call`() = runTest {
        val openAi = FakeTranslationProvider(AiProvider.OPENAI)
        val repo = repository(
            providers = listOf(openAi),
            keys = mutableMapOf(AiProvider.OPENAI to "test-key"),
            settings = AppSettings(activeProvider = AiProvider.OPENAI),
            online = false,
        )

        val result = repo.translate(request)

        assertTrue((result as AppResult.Failure).error is AppError.NoInternet)
        assertEquals(0, openAi.calls)
    }

    @Test
    fun `disabling the cache makes every request hit the provider`() = runTest {
        val openAi = FakeTranslationProvider(AiProvider.OPENAI)
        val repo = repository(
            providers = listOf(openAi),
            keys = mutableMapOf(AiProvider.OPENAI to "test-key"),
            settings = AppSettings(
                activeProvider = AiProvider.OPENAI,
                translationCacheEnabled = false,
            ),
        )

        repo.translate(request)
        repo.translate(request)

        assertEquals(2, openAi.calls)
    }
}
