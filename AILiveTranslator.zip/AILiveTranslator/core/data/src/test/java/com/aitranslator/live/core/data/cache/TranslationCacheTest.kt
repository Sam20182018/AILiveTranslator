package com.aitranslator.live.core.data.cache

import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.TranslationResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class TranslationCacheTest {

    private val cache = TranslationCache()

    private fun result(text: String) = TranslationResult(
        originalText = "سلام",
        translatedText = text,
        sourceLanguage = Language.PERSIAN,
        targetLanguage = Language.ENGLISH,
        provider = AiProvider.OPENAI,
        model = "gpt-4o-mini",
        latencyMillis = 10,
    )

    @Test
    fun `stores and returns a translation`() {
        cache.put("سلام", Language.PERSIAN, Language.ENGLISH, result("Hello"))

        assertEquals(
            "Hello",
            cache.get("سلام", Language.PERSIAN, Language.ENGLISH)?.translatedText,
        )
    }

    @Test
    fun `normalises whitespace and case so speech transcripts actually hit`() {
        cache.put("Hello there", Language.ENGLISH, Language.GERMAN, result("Hallo"))

        assertNotNull(cache.get("  hello THERE ", Language.ENGLISH, Language.GERMAN))
    }

    @Test
    fun `the language pair is part of the key`() {
        cache.put("Hello", Language.ENGLISH, Language.GERMAN, result("Hallo"))

        assertNull(cache.get("Hello", Language.ENGLISH, Language.FRENCH))
    }

    @Test
    fun `very long texts are not cached`() {
        val long = "a".repeat(1_000)
        cache.put(long, Language.ENGLISH, Language.GERMAN, result("x"))

        assertNull(cache.get(long, Language.ENGLISH, Language.GERMAN))
    }

    @Test
    fun `evicts the least recently used entry beyond the limit`() {
        repeat(250) { index ->
            cache.put("phrase $index", Language.ENGLISH, Language.GERMAN, result("t$index"))
        }

        assertEquals(200, cache.size())
        assertNull(cache.get("phrase 0", Language.ENGLISH, Language.GERMAN))
        assertNotNull(cache.get("phrase 249", Language.ENGLISH, Language.GERMAN))
    }

    @Test
    fun `clear empties the cache`() {
        cache.put("Hello", Language.ENGLISH, Language.GERMAN, result("Hallo"))
        cache.clear()

        assertEquals(0, cache.size())
    }
}
