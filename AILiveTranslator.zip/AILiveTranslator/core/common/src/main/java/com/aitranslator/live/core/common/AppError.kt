package com.aitranslator.live.core.common

/**
 * Typed, exhaustive error model used across every layer.
 *
 * No layer above [com.aitranslator.live.core.network] ever sees an exception: HTTP codes,
 * IO failures and provider error bodies are mapped into one of these before crossing a
 * module boundary. [technicalDetail] is only ever surfaced in debug logs, never in the UI.
 */
sealed class AppError {

    /** Human-safe detail for debug logs. Must never contain an API key. */
    abstract val technicalDetail: String?

    data class NoInternet(override val technicalDetail: String? = null) : AppError()

    data class InvalidApiKey(
        val provider: String,
        override val technicalDetail: String? = null,
    ) : AppError()

    data class NotConfigured(
        val provider: String,
        override val technicalDetail: String? = null,
    ) : AppError()

    data class RateLimited(
        val retryAfterSeconds: Long? = null,
        override val technicalDetail: String? = null,
    ) : AppError()

    data class ServerError(
        val httpCode: Int,
        override val technicalDetail: String? = null,
    ) : AppError()

    data class Timeout(override val technicalDetail: String? = null) : AppError()

    data class UnsupportedLanguage(
        val languageCode: String,
        override val technicalDetail: String? = null,
    ) : AppError()

    data class ModelUnavailable(
        val model: String,
        override val technicalDetail: String? = null,
    ) : AppError()

    data class AudioCapture(override val technicalDetail: String? = null) : AppError()

    data class AudioPlayback(override val technicalDetail: String? = null) : AppError()

    data class PermissionDenied(
        val permission: String,
        override val technicalDetail: String? = null,
    ) : AppError()

    data class CapabilityUnavailable(
        val capability: String,
        override val technicalDetail: String? = null,
    ) : AppError()

    data class EmptyInput(override val technicalDetail: String? = null) : AppError()

    data class Unknown(override val technicalDetail: String? = null) : AppError()
}
