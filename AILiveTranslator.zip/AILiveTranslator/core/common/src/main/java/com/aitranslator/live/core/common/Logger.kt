package com.aitranslator.live.core.common

import android.util.Log

/**
 * Central logging façade.
 *
 * Every message passes through [redact] first, so an API key can never reach Logcat even
 * if a caller accidentally interpolates one into a message. Verbose/debug output is
 * suppressed entirely unless [debugEnabled] was turned on by the application module for a
 * debug build.
 */
object Logger {

    private const val MAX_TAG_LENGTH = 23

    @Volatile
    var debugEnabled: Boolean = false

    private val secretPatterns = listOf(
        Regex("""sk-[A-Za-z0-9_\-]{8,}"""),
        Regex("""sk-ant-[A-Za-z0-9_\-]{8,}"""),
        Regex("""AIza[A-Za-z0-9_\-]{20,}"""),
        Regex("""(?i)(api[-_]?key|authorization|x-api-key)\s*[:=]\s*['"]?[A-Za-z0-9_\-.]{8,}"""),
        Regex("""(?i)([?&]key=)[A-Za-z0-9_\-.]{8,}"""),
        Regex("""(?i)(Bearer\s+)[A-Za-z0-9_\-.]{8,}"""),
    )

    fun redact(message: String): String {
        var out = message
        secretPatterns.forEach { pattern -> out = pattern.replace(out, "***REDACTED***") }
        return out
    }

    /** Masks a key for UI display, e.g. `sk-abc…7f9c`. */
    fun mask(key: String): String = when {
        key.isBlank() -> ""
        key.length <= 8 -> "•".repeat(key.length)
        else -> key.take(4) + "•".repeat(8) + key.takeLast(4)
    }

    fun d(tag: String, message: String) {
        if (debugEnabled) Log.d(tag.safe(), redact(message))
    }

    fun i(tag: String, message: String) {
        Log.i(tag.safe(), redact(message))
    }

    fun w(tag: String, message: String, throwable: Throwable? = null) {
        if (throwable != null) Log.w(tag.safe(), redact(message), throwable)
        else Log.w(tag.safe(), redact(message))
    }

    fun e(tag: String, message: String, throwable: Throwable? = null) {
        if (throwable != null) Log.e(tag.safe(), redact(message), throwable)
        else Log.e(tag.safe(), redact(message))
    }

    private fun String.safe(): String = if (length > MAX_TAG_LENGTH) take(MAX_TAG_LENGTH) else this
}
