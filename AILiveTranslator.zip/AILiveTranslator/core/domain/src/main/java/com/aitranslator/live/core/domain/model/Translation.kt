package com.aitranslator.live.core.domain.model

/** How a translation was produced. Stored with history entries. */
enum class TranslationMode(val id: String) {
    TEXT("text"),
    VOICE("voice"),
    LIVE("live"),
    CONVERSATION("conversation"),
    WHATSAPP("whatsapp"),
    PHONE_CALL("phone_call"),
    ;

    companion object {
        fun fromId(id: String?): TranslationMode =
            entries.firstOrNull { it.id == id } ?: TEXT
    }
}

data class TranslationRequest(
    val text: String,
    val sourceLanguage: Language,
    val targetLanguage: Language,
    val mode: TranslationMode = TranslationMode.TEXT,
    /** Recent turns, used by conversation mode so pronouns and register stay consistent. */
    val context: List<String> = emptyList(),
)

data class TranslationResult(
    val originalText: String,
    val translatedText: String,
    val sourceLanguage: Language,
    val targetLanguage: Language,
    val provider: AiProvider,
    val model: String,
    val latencyMillis: Long,
    val fromCache: Boolean = false,
)

/** Incremental output of a streaming translation call. */
sealed class TranslationChunk {
    data class Delta(val text: String) : TranslationChunk()
    data class Completed(val fullText: String) : TranslationChunk()
}
