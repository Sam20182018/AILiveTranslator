package com.aitranslator.live.core.domain.usecase

import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.common.NetworkMonitor
import com.aitranslator.live.core.domain.model.TranslationRequest
import com.aitranslator.live.core.domain.model.TranslationResult
import com.aitranslator.live.core.domain.repository.TranslationRepository
import javax.inject.Inject

/**
 * Guards the two cases that must never cost an API call: empty input and
 * source == target. Then delegates to the repository (cache → provider → history).
 */
class TranslateTextUseCase @Inject constructor(
    private val translationRepository: TranslationRepository,
    private val networkMonitor: NetworkMonitor,
) {

    suspend operator fun invoke(request: TranslationRequest): AppResult<TranslationResult> {
        val trimmed = request.text.trim()
        if (trimmed.isEmpty()) {
            return AppResult.Failure(AppError.EmptyInput())
        }

        if (request.sourceLanguage == request.targetLanguage) {
            return AppResult.Success(
                TranslationResult(
                    originalText = trimmed,
                    translatedText = trimmed,
                    sourceLanguage = request.sourceLanguage,
                    targetLanguage = request.targetLanguage,
                    provider = com.aitranslator.live.core.domain.model.AiProvider.AUTO,
                    model = "",
                    latencyMillis = 0L,
                    fromCache = true,
                ),
            )
        }

        if (!networkMonitor.isCurrentlyOnline()) {
            return AppResult.Failure(AppError.NoInternet())
        }

        return translationRepository.translate(request.copy(text = trimmed))
    }
}
