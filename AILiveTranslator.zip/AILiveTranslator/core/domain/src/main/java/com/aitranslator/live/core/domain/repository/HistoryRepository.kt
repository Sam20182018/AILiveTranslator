package com.aitranslator.live.core.domain.repository

import com.aitranslator.live.core.domain.model.HistoryEntry
import kotlinx.coroutines.flow.Flow

interface HistoryRepository {

    fun observeHistory(query: String = ""): Flow<List<HistoryEntry>>

    /** No-op when the user disabled history — the gate lives in the implementation. */
    suspend fun add(entry: HistoryEntry): Long

    suspend fun delete(id: Long)

    suspend fun deleteAll()

    /** Removes every stored audio file, used when "Save audio" is switched off. */
    suspend fun purgeAudio()
}
