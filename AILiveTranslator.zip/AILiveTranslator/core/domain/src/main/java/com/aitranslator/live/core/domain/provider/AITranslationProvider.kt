package com.aitranslator.live.core.domain.provider

import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.TranslationChunk
import com.aitranslator.live.core.domain.model.TranslationRequest
import com.aitranslator.live.core.domain.model.TranslationResult
import kotlinx.coroutines.flow.Flow

/**
 * One AI service that can translate text. Implemented once per vendor in `:core:network`.
 *
 * Implementations receive the API key per call and must never cache or log it.
 */
interface AITranslationProvider {

    val provider: AiProvider

    val supportsStreaming: Boolean

    suspend fun translate(
        request: TranslationRequest,
        apiKey: String,
        model: String,
        maxOutputTokens: Int,
        temperature: Float,
    ): AppResult<TranslationResult>

    /**
     * Incremental translation. Terminates with [TranslationChunk.Completed]. Errors are
     * delivered by throwing a [TranslationStreamException] so callers can `catch {}`.
     */
    fun translateStream(
        request: TranslationRequest,
        apiKey: String,
        model: String,
        maxOutputTokens: Int,
        temperature: Float,
    ): Flow<TranslationChunk>

    /** Cheapest possible round trip used by the "Test connection" button in Settings. */
    suspend fun testConnection(apiKey: String, model: String): AppResult<Unit>
}

/** Carries an [com.aitranslator.live.core.common.AppError] out of a streaming Flow. */
class TranslationStreamException(
    val appError: com.aitranslator.live.core.common.AppError,
) : Exception(appError.toString())
