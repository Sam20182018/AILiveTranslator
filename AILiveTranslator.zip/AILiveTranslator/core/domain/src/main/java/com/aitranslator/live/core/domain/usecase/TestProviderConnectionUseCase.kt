package com.aitranslator.live.core.domain.usecase

import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.common.NetworkMonitor
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.repository.ApiKeyRepository
import com.aitranslator.live.core.domain.repository.TranslationRepository
import javax.inject.Inject

/**
 * Validates a provider key with the cheapest possible request and records the outcome so
 * AUTO selection can prefer providers that are known to work.
 */
class TestProviderConnectionUseCase @Inject constructor(
    private val translationRepository: TranslationRepository,
    private val apiKeyRepository: ApiKeyRepository,
    private val networkMonitor: NetworkMonitor,
) {

    suspend operator fun invoke(
        provider: AiProvider,
        candidateKey: String? = null,
        model: String? = null,
    ): AppResult<Unit> {
        if (!provider.isConcrete) {
            return AppResult.Failure(AppError.NotConfigured(provider.id, "AUTO is not testable"))
        }
        if (!networkMonitor.isCurrentlyOnline()) {
            return AppResult.Failure(AppError.NoInternet())
        }

        val result = translationRepository.testConnection(provider, candidateKey, model)
        apiKeyRepository.recordValidation(provider, result.isSuccess)
        return result
    }
}
