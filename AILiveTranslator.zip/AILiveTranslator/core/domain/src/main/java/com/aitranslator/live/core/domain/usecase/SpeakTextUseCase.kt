package com.aitranslator.live.core.domain.usecase

import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.repository.SettingsRepository
import com.aitranslator.live.core.domain.repository.SpeechRepository
import javax.inject.Inject

/** Speaks arbitrary text, honouring the global "Voice translation ON/OFF" switch. */
class SpeakTextUseCase @Inject constructor(
    private val speechRepository: SpeechRepository,
    private val settingsRepository: SettingsRepository,
) {

    suspend operator fun invoke(
        text: String,
        language: Language,
        force: Boolean = false,
    ): AppResult<Unit> {
        if (text.isBlank()) return AppResult.Success(Unit)

        val settings = settingsRepository.current()
        if (!force && !settings.voiceTranslationEnabled) return AppResult.Success(Unit)

        return speechRepository
            .speak(text, language, persistAudio = false)
            .map { }
    }

    suspend fun stop() = speechRepository.stopSpeaking()
}
