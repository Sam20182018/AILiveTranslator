package com.aitranslator.live.core.domain.model

/**
 * Model identifiers are **never hard-coded at a call site**. They live here as editable
 * defaults and are overridable per provider from Settings, so a vendor renaming a model
 * only requires changing a string — no code change, no app update if the user edits it.
 */
data class AiModelConfig(
    val translationModel: String,
    val transcriptionModel: String,
    val speechModel: String,
    val realtimeModel: String,
    val maxOutputTokens: Int,
    val temperature: Float,
) {
    companion object {

        fun defaultFor(provider: AiProvider): AiModelConfig = when (provider) {
            AiProvider.OPENAI -> AiModelConfig(
                translationModel = "gpt-4o-mini",
                transcriptionModel = "whisper-1",
                speechModel = "tts-1",
                realtimeModel = "gpt-4o-realtime-preview",
                maxOutputTokens = 1024,
                temperature = 0.2f,
            )

            AiProvider.GEMINI -> AiModelConfig(
                translationModel = "gemini-1.5-flash",
                transcriptionModel = "gemini-1.5-flash",
                speechModel = "",
                realtimeModel = "",
                maxOutputTokens = 1024,
                temperature = 0.2f,
            )

            AiProvider.CLAUDE -> AiModelConfig(
                translationModel = "claude-3-5-haiku-20241022",
                transcriptionModel = "",
                speechModel = "",
                realtimeModel = "",
                maxOutputTokens = 1024,
                temperature = 0.2f,
            )

            AiProvider.AUTO -> defaultFor(AiProvider.OPENAI)
        }

        /**
         * Suggestions shown in Settings. Free text is still allowed, so a model released
         * after this build ships can be entered by hand.
         */
        fun suggestionsFor(provider: AiProvider): List<String> = when (provider) {
            AiProvider.OPENAI -> listOf("gpt-4o-mini", "gpt-4o", "gpt-4.1-mini", "gpt-4.1")
            AiProvider.GEMINI -> listOf(
                "gemini-1.5-flash",
                "gemini-1.5-pro",
                "gemini-2.0-flash",
                "gemini-2.5-flash",
            )
            AiProvider.CLAUDE -> listOf(
                "claude-3-5-haiku-20241022",
                "claude-3-5-sonnet-20241022",
                "claude-sonnet-4-20250514",
            )
            AiProvider.AUTO -> emptyList()
        }
    }
}

/** Trade-off preset that tunes VAD timing, token budget and which live engine is used. */
enum class LatencyProfile(val id: String) {
    LOW_LATENCY("low_latency"),
    BALANCED("balanced"),
    HIGH_QUALITY("high_quality"),
    ;

    /** Silence needed before a speech segment is considered finished. */
    val silenceMillis: Long
        get() = when (this) {
            LOW_LATENCY -> 450L
            BALANCED -> 700L
            HIGH_QUALITY -> 1_000L
        }

    /** Hard cap on a single segment so a monologue is still split into usable chunks. */
    val maxSegmentMillis: Long
        get() = when (this) {
            LOW_LATENCY -> 4_000L
            BALANCED -> 6_000L
            HIGH_QUALITY -> 9_000L
        }

    val preferRealtimeEngine: Boolean get() = this == LOW_LATENCY

    companion object {
        fun fromId(id: String?): LatencyProfile =
            entries.firstOrNull { it.id == id } ?: BALANCED
    }
}
