package com.aitranslator.live.core.domain.provider

import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.TtsEngine

/**
 * Looks up concrete provider implementations. Keeps repositories free of any knowledge
 * about which vendors exist, so adding one is a DI-only change.
 */
interface AIProviderRegistry {

    fun translationProvider(provider: AiProvider): AITranslationProvider?

    fun speechRecognitionProvider(provider: AiProvider): SpeechRecognitionProvider?

    fun textToSpeechProvider(engine: TtsEngine): TextToSpeechProvider?

    /** Providers that have a translation implementation compiled in. */
    fun availableTranslationProviders(): List<AiProvider>

    /** Providers that can do speech-to-text (Claude cannot). */
    fun availableSpeechRecognitionProviders(): List<AiProvider>
}
