package com.aitranslator.live.core.domain.model

/** Which side of a face-to-face conversation spoke. */
enum class Speaker(val id: String) {
    PERSON_A("a"),
    PERSON_B("b"),
    ;

    fun other(): Speaker = if (this == PERSON_A) PERSON_B else PERSON_A
}

data class ConversationTurn(
    val id: String,
    val speaker: Speaker,
    val sourceLanguage: Language,
    val targetLanguage: Language,
    val originalText: String,
    val translatedText: String,
    val timestampMillis: Long,
    val isTranslating: Boolean = false,
    val errorMessage: String? = null,
)

/** How turn-taking is driven in conversation mode. */
enum class ConversationTurnMode(val id: String) {
    /** Mic stays open; speaker is inferred from which language the utterance matches. */
    AUTOMATIC("automatic"),

    /** Each person presses their own button. */
    MANUAL("manual"),
    ;

    companion object {
        fun fromId(id: String?): ConversationTurnMode =
            entries.firstOrNull { it.id == id } ?: MANUAL
    }
}
