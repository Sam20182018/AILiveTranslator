package com.aitranslator.live.core.domain.model

/** The AI services the app can translate with. `AUTO` resolves at call time. */
enum class AiProvider(val id: String, val displayName: String) {
    GEMINI("gemini", "Google Gemini"),
    CLAUDE("claude", "Anthropic Claude"),
    OPENAI("openai", "OpenAI"),
    AUTO("auto", "Auto"),
    ;

    /** Providers that can actually serve a request (i.e. everything except AUTO). */
    val isConcrete: Boolean get() = this != AUTO

    companion object {
        val concreteProviders: List<AiProvider> = listOf(GEMINI, CLAUDE, OPENAI)

        fun fromId(id: String?): AiProvider =
            entries.firstOrNull { it.id == id } ?: AUTO
    }
}

/** Which capabilities each provider actually exposes today. Used to avoid false promises. */
data class ProviderCapabilities(
    val translation: Boolean,
    val streamingTranslation: Boolean,
    val speechToText: Boolean,
    val textToSpeech: Boolean,
    val realtimeDuplex: Boolean,
) {
    companion object {
        fun of(provider: AiProvider): ProviderCapabilities = when (provider) {
            AiProvider.OPENAI -> ProviderCapabilities(
                translation = true,
                streamingTranslation = true,
                speechToText = true,
                textToSpeech = true,
                realtimeDuplex = true,
            )
            AiProvider.GEMINI -> ProviderCapabilities(
                translation = true,
                streamingTranslation = true,
                speechToText = true,
                textToSpeech = false,
                realtimeDuplex = false,
            )
            AiProvider.CLAUDE -> ProviderCapabilities(
                translation = true,
                streamingTranslation = true,
                speechToText = false,
                textToSpeech = false,
                realtimeDuplex = false,
            )
            AiProvider.AUTO -> ProviderCapabilities(
                translation = true,
                streamingTranslation = true,
                speechToText = true,
                textToSpeech = true,
                realtimeDuplex = true,
            )
        }
    }
}
