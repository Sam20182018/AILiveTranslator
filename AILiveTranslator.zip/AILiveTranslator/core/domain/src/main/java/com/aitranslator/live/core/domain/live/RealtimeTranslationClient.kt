package com.aitranslator.live.core.domain.live

import com.aitranslator.live.core.common.AppError
import kotlinx.coroutines.flow.Flow

/** Signals produced by a bidirectional realtime translation session. */
sealed class RealtimeSignal {
    data object Connected : RealtimeSignal()
    data object SpeechStarted : RealtimeSignal()
    data object SpeechStopped : RealtimeSignal()

    /** What the user said, as recognised by the service. */
    data class InputTranscript(val text: String) : RealtimeSignal()

    data class OutputTextDelta(val text: String) : RealtimeSignal()
    data class OutputTextDone(val text: String) : RealtimeSignal()

    /** 16-bit PCM mono at [RealtimeAudioSpec.SAMPLE_RATE_HZ], ready for playback. */
    data class OutputAudioDelta(val pcm: ByteArray) : RealtimeSignal() {
        override fun equals(other: Any?): Boolean =
            other is OutputAudioDelta && pcm.contentEquals(other.pcm)

        override fun hashCode(): Int = pcm.contentHashCode()
    }

    data object ResponseCompleted : RealtimeSignal()
    data class Failed(val error: AppError) : RealtimeSignal()
    data object Closed : RealtimeSignal()
}

/** Audio format the realtime transport expects in both directions. */
object RealtimeAudioSpec {
    const val SAMPLE_RATE_HZ = 24_000
    const val BYTES_PER_SAMPLE = 2
    const val CHUNK_MILLIS = 40
    const val CHUNK_BYTES = SAMPLE_RATE_HZ / 1000 * CHUNK_MILLIS * BYTES_PER_SAMPLE
}

data class RealtimeConfig(
    val instructions: String,
    val voice: String,
    val wantAudioOutput: Boolean,
)

/**
 * A duplex speech-to-speech translation transport.
 *
 * Declared in the domain so `:core:audio` — which owns the microphone — can drive a
 * realtime session without depending on any vendor SDK or on `:core:network`.
 */
interface RealtimeTranslationClient {

    /** `false` when the underlying service has no key configured or is not reachable. */
    suspend fun isAvailable(): Boolean

    fun connect(config: RealtimeConfig, inputAudio: Flow<ByteArray>): Flow<RealtimeSignal>
}
