package com.aitranslator.live.core.domain.model

/**
 * The languages the app can translate between.
 *
 * Adding a language is a one-line change: every selector, prompt, STT hint, TTS locale
 * lookup and history filter derives from this enum, so no other file has to be touched.
 */
enum class Language(
    val code: String,
    val bcp47: String,
    val englishName: String,
    val nativeName: String,
    val flag: String,
    val isRtl: Boolean,
) {
    PERSIAN("fa", "fa-IR", "Persian", "فارسی", "🇮🇷", true),
    ENGLISH("en", "en-US", "English", "English", "🇬🇧", false),
    ARABIC("ar", "ar-SA", "Arabic", "العربية", "🇸🇦", true),
    FRENCH("fr", "fr-FR", "French", "Français", "🇫🇷", false),
    DUTCH("nl", "nl-NL", "Dutch", "Nederlands", "🇳🇱", false),
    GERMAN("de", "de-DE", "German", "Deutsch", "🇩🇪", false),
    ;

    val displayLabel: String get() = "$flag $nativeName"

    companion object {
        val DEFAULT_SOURCE = PERSIAN
        val DEFAULT_TARGET = ENGLISH

        fun fromCode(code: String?): Language? {
            if (code.isNullOrBlank()) return null
            val normalized = code.lowercase().substringBefore('-').substringBefore('_')
            return entries.firstOrNull { it.code == normalized }
        }

        fun fromCodeOrDefault(code: String?, fallback: Language = ENGLISH): Language =
            fromCode(code) ?: fallback
    }
}
