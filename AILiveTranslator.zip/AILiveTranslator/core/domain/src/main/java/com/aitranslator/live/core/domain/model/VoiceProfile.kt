package com.aitranslator.live.core.domain.model

enum class VoiceGender(val id: String) {
    MALE("male"),
    FEMALE("female"),
    NEUTRAL("neutral"),
    ;

    companion object {
        fun fromId(id: String?): VoiceGender =
            entries.firstOrNull { it.id == id } ?: NEUTRAL
    }
}

/** Which engine renders the speech. */
enum class TtsEngine(val id: String) {
    /** On-device `android.speech.tts.TextToSpeech`. Works offline, quality varies. */
    ANDROID("android"),

    /** OpenAI `/v1/audio/speech`. Consistent, expressive, needs an OpenAI key. */
    OPENAI("openai"),
    ;

    companion object {
        fun fromId(id: String?): TtsEngine =
            entries.firstOrNull { it.id == id } ?: ANDROID
    }
}

/**
 * A selectable voice. The catalogue always contains at least 5 male + 5 female cloud
 * voices; device voices discovered at runtime are appended to it.
 */
data class VoiceProfile(
    val id: String,
    val displayName: String,
    val gender: VoiceGender,
    val engine: TtsEngine,
    /** Voice identifier understood by the engine (OpenAI voice name / Android voice name). */
    val engineVoiceId: String,
    /** `null` means the voice works for every supported language. */
    val languages: Set<Language>? = null,
    val description: String = "",
) {
    fun supports(language: Language): Boolean = languages == null || language in languages

    companion object {

        /** The 5 male cloud voices required by the spec. */
        val OPENAI_MALE: List<VoiceProfile> = listOf(
            cloud("onyx", "Male Voice 1 · Onyx", VoiceGender.MALE, "Deep and calm"),
            cloud("echo", "Male Voice 2 · Echo", VoiceGender.MALE, "Neutral and clear"),
            cloud("ash", "Male Voice 3 · Ash", VoiceGender.MALE, "Warm and steady"),
            cloud("ballad", "Male Voice 4 · Ballad", VoiceGender.MALE, "Expressive"),
            cloud("verse", "Male Voice 5 · Verse", VoiceGender.MALE, "Narrative"),
        )

        /** The 5 female cloud voices required by the spec. */
        val OPENAI_FEMALE: List<VoiceProfile> = listOf(
            cloud("nova", "Female Voice 1 · Nova", VoiceGender.FEMALE, "Bright and friendly"),
            cloud("shimmer", "Female Voice 2 · Shimmer", VoiceGender.FEMALE, "Soft"),
            cloud("alloy", "Female Voice 3 · Alloy", VoiceGender.FEMALE, "Balanced"),
            cloud("coral", "Female Voice 4 · Coral", VoiceGender.FEMALE, "Lively"),
            cloud("sage", "Female Voice 5 · Sage", VoiceGender.FEMALE, "Measured"),
        )

        val OPENAI_VOICES: List<VoiceProfile> = OPENAI_MALE + OPENAI_FEMALE

        /** Used before settings load and whenever no OpenAI key is configured. */
        val DEVICE_DEFAULT = VoiceProfile(
            id = "android:default",
            displayName = "Device default voice",
            gender = VoiceGender.NEUTRAL,
            engine = TtsEngine.ANDROID,
            engineVoiceId = "",
            description = "System text-to-speech voice for the selected language",
        )

        private fun cloud(
            voiceId: String,
            label: String,
            gender: VoiceGender,
            description: String,
        ) = VoiceProfile(
            id = "openai:$voiceId",
            displayName = label,
            gender = gender,
            engine = TtsEngine.OPENAI,
            engineVoiceId = voiceId,
            description = description,
        )
    }
}

/** PCM/MP3 bytes plus the mime type the player needs. */
data class SynthesizedAudio(
    val bytes: ByteArray,
    val mimeType: String,
    val fileExtension: String,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is SynthesizedAudio) return false
        return mimeType == other.mimeType &&
            fileExtension == other.fileExtension &&
            bytes.contentEquals(other.bytes)
    }

    override fun hashCode(): Int {
        var result = bytes.contentHashCode()
        result = 31 * result + mimeType.hashCode()
        result = 31 * result + fileExtension.hashCode()
        return result
    }
}
