package com.aitranslator.live.core.domain.repository

import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.AppSettings
import com.aitranslator.live.core.domain.model.ConversationTurnMode
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.LatencyProfile
import com.aitranslator.live.core.domain.model.ThemeMode
import com.aitranslator.live.core.domain.model.VoiceGender
import kotlinx.coroutines.flow.Flow

interface SettingsRepository {

    val settings: Flow<AppSettings>

    suspend fun current(): AppSettings

    suspend fun setActiveProvider(provider: AiProvider)
    suspend fun setModelOverride(provider: AiProvider, model: String?)
    suspend fun setSourceLanguage(language: Language)
    suspend fun setTargetLanguage(language: Language)
    suspend fun swapLanguages()
    suspend fun setConversationLanguages(personA: Language, personB: Language)
    suspend fun setConversationTurnMode(mode: ConversationTurnMode)
    suspend fun setVoice(voiceId: String)
    suspend fun setPreferredVoiceGender(gender: VoiceGender)
    suspend fun setVoiceTranslationEnabled(enabled: Boolean)
    suspend fun setAutoPlayTranslation(enabled: Boolean)
    suspend fun setSpeechSpeed(speed: Float)
    suspend fun setSpeechVolume(volume: Float)
    suspend fun setShowOriginalText(show: Boolean)
    suspend fun setShowTranslation(show: Boolean)
    suspend fun setSaveHistory(enabled: Boolean)
    suspend fun setSaveAudio(enabled: Boolean)
    suspend fun setLatencyProfile(profile: LatencyProfile)
    suspend fun setThemeMode(mode: ThemeMode)
    suspend fun setTranslationCacheEnabled(enabled: Boolean)
}
