package com.aitranslator.live.core.domain.live

import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.LatencyProfile
import com.aitranslator.live.core.domain.model.LiveEvent
import com.aitranslator.live.core.domain.model.TranslationMode
import kotlinx.coroutines.flow.Flow

data class LiveSessionConfig(
    val sourceLanguage: Language,
    val targetLanguage: Language,
    val mode: TranslationMode = TranslationMode.LIVE,
    val latencyProfile: LatencyProfile = LatencyProfile.BALANCED,
    val autoSpeak: Boolean = true,
)

/**
 * A continuous mic → translation → speech loop.
 *
 * Two implementations ship: a chunked VAD pipeline that works with every provider, and an
 * OpenAI Realtime WebSocket engine for the lowest latency. Both emit the same events so
 * the UI never knows which one is running.
 */
interface LiveTranslationEngine {

    val id: String

    /** e.g. the realtime engine is only supported when an OpenAI key is configured. */
    suspend fun isSupported(config: LiveSessionConfig): Boolean

    /** Cold flow: collecting starts the session, cancelling stops and releases the mic. */
    fun run(config: LiveSessionConfig): Flow<LiveEvent>
}

/** Chooses the best engine for the current settings. Implemented in `:core:audio`. */
interface LiveTranslationEngineSelector {
    suspend fun select(config: LiveSessionConfig): LiveTranslationEngine
}
