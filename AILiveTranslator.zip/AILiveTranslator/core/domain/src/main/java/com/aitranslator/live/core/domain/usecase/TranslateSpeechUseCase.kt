package com.aitranslator.live.core.domain.usecase

import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.HistoryEntry
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.TranslationMode
import com.aitranslator.live.core.domain.model.TranslationRequest
import com.aitranslator.live.core.domain.model.TranslationResult
import com.aitranslator.live.core.domain.repository.HistoryRepository
import com.aitranslator.live.core.domain.repository.SettingsRepository
import com.aitranslator.live.core.domain.repository.SpeechRepository
import javax.inject.Inject

/**
 * The full voice path: WAV → transcript → translation → (optional) spoken output.
 *
 * History and audio persistence are applied here so every voice-driven screen behaves the
 * same way and honours the privacy switches.
 */
class TranslateSpeechUseCase @Inject constructor(
    private val speechRepository: SpeechRepository,
    private val translateText: TranslateTextUseCase,
    private val settingsRepository: SettingsRepository,
    private val historyRepository: HistoryRepository,
) {

    data class Output(
        val transcript: String,
        val result: TranslationResult,
        val spokenAudioPath: String?,
    )

    suspend operator fun invoke(
        wavAudio: ByteArray,
        sourceLanguage: Language,
        targetLanguage: Language,
        mode: TranslationMode,
        speakResult: Boolean? = null,
    ): AppResult<Output> {
        val settings = settingsRepository.current()

        val transcript = when (val stt = speechRepository.transcribe(wavAudio, sourceLanguage)) {
            is AppResult.Failure -> return stt
            is AppResult.Success -> stt.data.trim()
        }

        if (transcript.isEmpty()) {
            return AppResult.Failure(AppError.EmptyInput("speech recognition returned no text"))
        }

        val translation = translateText(
            TranslationRequest(
                text = transcript,
                sourceLanguage = sourceLanguage,
                targetLanguage = targetLanguage,
                mode = mode,
            ),
        )

        val result = when (translation) {
            is AppResult.Failure -> return translation
            is AppResult.Success -> translation.data
        }

        val shouldSpeak = speakResult
            ?: (settings.voiceTranslationEnabled && settings.autoPlayTranslation)

        var audioPath: String? = null
        if (shouldSpeak) {
            val spoken = speechRepository.speak(
                text = result.translatedText,
                language = targetLanguage,
                persistAudio = settings.saveAudio,
            )
            audioPath = spoken.getOrNull()
        }

        historyRepository.add(
            HistoryEntry(
                timestampMillis = System.currentTimeMillis(),
                sourceLanguage = sourceLanguage,
                targetLanguage = targetLanguage,
                originalText = transcript,
                translatedText = result.translatedText,
                mode = mode,
                provider = result.provider,
                audioFilePath = audioPath,
            ),
        )

        return AppResult.Success(Output(transcript, result, audioPath))
    }
}
