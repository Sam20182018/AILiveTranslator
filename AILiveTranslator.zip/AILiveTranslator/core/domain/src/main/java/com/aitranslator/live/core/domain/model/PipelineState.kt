package com.aitranslator.live.core.domain.model

import com.aitranslator.live.core.common.AppError

/**
 * The single state machine shared by voice, live, conversation and assist modes.
 *
 * `Idle → Listening → Processing → Translating → Speaking → Listening` with `Error` and
 * `Stopped` reachable from anywhere.
 */
sealed class PipelineState {

    data object Idle : PipelineState()

    /** Mic is open. [amplitude] is 0..1 and drives the waveform animation. */
    data class Listening(val amplitude: Float = 0f) : PipelineState()

    /** Audio captured, speech recognition in flight. */
    data object Processing : PipelineState()

    data object Translating : PipelineState()

    data object Speaking : PipelineState()

    data class Error(val error: AppError) : PipelineState()

    data object Stopped : PipelineState()

    val isActive: Boolean
        get() = this is Listening || this is Processing || this is Translating || this is Speaking
}

/** Events emitted by any live/continuous engine. The UI is engine-agnostic. */
sealed class LiveEvent {
    data class StateChanged(val state: PipelineState) : LiveEvent()
    data class PartialTranscript(val text: String) : LiveEvent()
    data class FinalTranscript(val text: String) : LiveEvent()
    data class PartialTranslation(val text: String) : LiveEvent()
    data class FinalTranslation(val result: TranslationResult) : LiveEvent()
    data class Failed(val error: AppError) : LiveEvent()
}
