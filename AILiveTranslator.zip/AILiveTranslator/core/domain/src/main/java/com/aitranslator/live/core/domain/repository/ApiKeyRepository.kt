package com.aitranslator.live.core.domain.repository

import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.ApiKeyEntry
import kotlinx.coroutines.flow.Flow

/**
 * Stores API keys encrypted with an Android Keystore-backed AES/GCM key.
 *
 * Contract for every implementation:
 * * plaintext keys are never persisted, never logged, never put in a UI state object;
 * * [getKey] is called at request-build time only and the result is not retained.
 */
interface ApiKeyRepository {

    /** Metadata for all providers — safe for the UI to observe. */
    val entries: Flow<List<ApiKeyEntry>>

    suspend fun saveKey(provider: AiProvider, key: String): AppResult<Unit>

    /** Decrypts on demand. Returns `null` when no key is stored for the provider. */
    suspend fun getKey(provider: AiProvider): String?

    suspend fun deleteKey(provider: AiProvider): AppResult<Unit>

    suspend fun setActive(provider: AiProvider, active: Boolean)

    suspend fun recordValidation(provider: AiProvider, succeeded: Boolean)

    /** Providers that have a stored key and are marked active. */
    suspend fun activeProvidersWithKeys(): List<AiProvider>
}
