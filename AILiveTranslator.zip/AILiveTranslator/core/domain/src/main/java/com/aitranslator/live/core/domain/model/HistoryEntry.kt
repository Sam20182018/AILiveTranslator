package com.aitranslator.live.core.domain.model

data class HistoryEntry(
    val id: Long = 0L,
    val timestampMillis: Long,
    val sourceLanguage: Language,
    val targetLanguage: Language,
    val originalText: String,
    val translatedText: String,
    val mode: TranslationMode,
    val provider: AiProvider,
    /** Absolute path of the saved translation audio, or `null` when audio saving is off. */
    val audioFilePath: String? = null,
)
