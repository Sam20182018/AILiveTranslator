package com.aitranslator.live.core.domain.repository

import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.VoiceProfile

/**
 * Speech-to-text and text-to-speech, with provider/engine selection and graceful fallback
 * already applied (e.g. Claude cannot transcribe, so STT routes to OpenAI or Gemini).
 */
interface SpeechRepository {

    suspend fun transcribe(wavAudio: ByteArray, language: Language): AppResult<String>

    /**
     * Speaks [text]. Returns the path of the saved audio file when the user enabled
     * "Save audio", otherwise `null`.
     */
    suspend fun speak(
        text: String,
        language: Language,
        persistAudio: Boolean = false,
    ): AppResult<String?>

    suspend fun stopSpeaking()

    /** Full catalogue: 10 cloud voices plus whatever the device engine reports. */
    suspend fun voiceCatalogue(): List<VoiceProfile>

    suspend fun selectedVoice(): VoiceProfile

    /** Plays a short sample sentence with [voice] without changing the saved selection. */
    suspend fun previewVoice(voice: VoiceProfile, language: Language): AppResult<Unit>
}
