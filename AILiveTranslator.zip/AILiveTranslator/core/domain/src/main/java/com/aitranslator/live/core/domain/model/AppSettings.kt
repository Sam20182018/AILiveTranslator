package com.aitranslator.live.core.domain.model

enum class ThemeMode(val id: String) {
    SYSTEM("system"),
    LIGHT("light"),
    DARK("dark"),
    ;

    companion object {
        fun fromId(id: String?): ThemeMode = entries.firstOrNull { it.id == id } ?: SYSTEM
    }
}

/**
 * Everything the user can configure. Persisted in DataStore; API keys are **not** part of
 * this object — they live encrypted in [com.aitranslator.live.core.domain.repository.ApiKeyRepository].
 */
data class AppSettings(
    val activeProvider: AiProvider = AiProvider.AUTO,
    val modelOverrides: Map<AiProvider, String> = emptyMap(),
    val sourceLanguage: Language = Language.DEFAULT_SOURCE,
    val targetLanguage: Language = Language.DEFAULT_TARGET,
    val conversationLanguageA: Language = Language.PERSIAN,
    val conversationLanguageB: Language = Language.GERMAN,
    val conversationTurnMode: ConversationTurnMode = ConversationTurnMode.MANUAL,
    val selectedVoiceId: String = VoiceProfile.DEVICE_DEFAULT.id,
    val preferredVoiceGender: VoiceGender = VoiceGender.NEUTRAL,
    val voiceTranslationEnabled: Boolean = true,
    val autoPlayTranslation: Boolean = true,
    val speechSpeed: Float = 1.0f,
    val speechVolume: Float = 1.0f,
    val showOriginalText: Boolean = true,
    val showTranslation: Boolean = true,
    val saveHistory: Boolean = true,
    val saveAudio: Boolean = false,
    val latencyProfile: LatencyProfile = LatencyProfile.BALANCED,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val translationCacheEnabled: Boolean = true,
) {
    /** Effective model id for a provider: user override first, then the built-in default. */
    fun modelFor(provider: AiProvider): String {
        val concrete = if (provider.isConcrete) provider else AiProvider.OPENAI
        return modelOverrides[concrete]?.takeIf { it.isNotBlank() }
            ?: AiModelConfig.defaultFor(concrete).translationModel
    }
}
