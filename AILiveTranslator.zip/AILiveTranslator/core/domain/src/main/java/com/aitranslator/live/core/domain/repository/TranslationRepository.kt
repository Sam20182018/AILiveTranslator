package com.aitranslator.live.core.domain.repository

import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.TranslationChunk
import com.aitranslator.live.core.domain.model.TranslationRequest
import com.aitranslator.live.core.domain.model.TranslationResult
import kotlinx.coroutines.flow.Flow

/**
 * The single entry point for text translation.
 *
 * Responsibilities: resolve the provider (honouring AUTO), fetch the key, apply the cache,
 * map errors, and record history when the user allows it.
 */
interface TranslationRepository {

    suspend fun translate(request: TranslationRequest): AppResult<TranslationResult>

    /** Streaming variant. Falls back to a single-shot call for non-streaming providers. */
    fun translateStreaming(request: TranslationRequest): Flow<TranslationChunk>

    /** Resolves which concrete provider a request would use right now. */
    suspend fun resolveProvider(): AppResult<AiProvider>

    /**
     * Round-trips the smallest possible request. [key] lets Settings validate a key the
     * user just typed before saving it.
     */
    suspend fun testConnection(
        provider: AiProvider,
        key: String? = null,
        model: String? = null,
    ): AppResult<Unit>

    fun clearCache()
}
