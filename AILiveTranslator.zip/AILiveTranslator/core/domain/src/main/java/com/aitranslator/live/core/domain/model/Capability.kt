package com.aitranslator.live.core.domain.model

/**
 * Honest capability reporting.
 *
 * Several things users expect from a "call translator" are **not implementable** by a
 * normal Android app. Instead of silently failing, every assist feature declares its real
 * status here and the UI shows it before the user starts.
 */
enum class CapabilityStatus {
    /** Works on every supported device. */
    AVAILABLE,

    /** May work, depends on OEM/Android version/other app holding the mic. */
    DEVICE_DEPENDENT,

    /** Requires a runtime permission or a system toggle the user has not granted yet. */
    REQUIRES_SETUP,

    /** The Android platform forbids it for non-system apps. Will never work. */
    BLOCKED_BY_PLATFORM,
}

data class Capability(
    val id: String,
    val title: String,
    val status: CapabilityStatus,
    val explanation: String,
    /** What the app does instead when the status is not [CapabilityStatus.AVAILABLE]. */
    val alternative: String? = null,
)

data class CapabilityReport(
    val feature: String,
    val capabilities: List<Capability>,
) {
    val hasBlocked: Boolean
        get() = capabilities.any { it.status == CapabilityStatus.BLOCKED_BY_PLATFORM }
}
