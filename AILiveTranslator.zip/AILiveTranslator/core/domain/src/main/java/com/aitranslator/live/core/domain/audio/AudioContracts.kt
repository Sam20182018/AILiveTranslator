package com.aitranslator.live.core.domain.audio

import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.SynthesizedAudio
import kotlinx.coroutines.flow.Flow

/** Fixed capture format for the whole app. 16 kHz mono PCM16 is what every STT API wants. */
object AudioFormatSpec {
    const val SAMPLE_RATE_HZ = 16_000
    const val CHANNELS = 1
    const val BITS_PER_SAMPLE = 16
    const val FRAME_MILLIS = 20
    const val BYTES_PER_SAMPLE = 2

    /** 20 ms of audio = 320 samples = 640 bytes. */
    const val FRAME_BYTES = SAMPLE_RATE_HZ / 1000 * FRAME_MILLIS * BYTES_PER_SAMPLE
}

/** One capture frame plus its measured loudness, so the VAD and the UI share a source. */
data class AudioFrame(
    val pcm: ByteArray,
    val rms: Float,
    val timestampMillis: Long,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is AudioFrame) return false
        return rms == other.rms &&
            timestampMillis == other.timestampMillis &&
            pcm.contentEquals(other.pcm)
    }

    override fun hashCode(): Int {
        var result = pcm.contentHashCode()
        result = 31 * result + rms.hashCode()
        result = 31 * result + timestampMillis.hashCode()
        return result
    }
}

/** Microphone capture. Implemented with `AudioRecord` in `:core:audio`. */
interface AudioRecorder {
    val isRecording: Boolean

    /**
     * Cold flow of 20 ms frames. Collecting starts the mic; cancelling stops and releases
     * it. Emits an [com.aitranslator.live.core.common.AppError] via [AudioCaptureException].
     */
    fun frames(): Flow<AudioFrame>
}

class AudioCaptureException(
    val appError: com.aitranslator.live.core.common.AppError,
) : Exception(appError.toString())

/** Decision output of the voice activity detector for a single frame. */
enum class VadDecision { SILENCE, SPEECH_START, SPEECH, SPEECH_END }

interface VoiceActivityDetector {
    fun reset()
    fun accept(frame: AudioFrame): VadDecision
}

/** A complete utterance ready to be uploaded. */
data class SpeechSegment(
    val wav: ByteArray,
    val durationMillis: Long,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is SpeechSegment) return false
        return durationMillis == other.durationMillis && wav.contentEquals(other.wav)
    }

    override fun hashCode(): Int = 31 * wav.contentHashCode() + durationMillis.hashCode()
}

/** Plays cloud-synthesised audio bytes. */
interface AudioPlayer {
    val isPlaying: Boolean
    suspend fun play(audio: SynthesizedAudio, volume: Float): AppResult<Unit>
    suspend fun playFile(path: String, volume: Float): AppResult<Unit>
    fun stop()
    fun release()
}
