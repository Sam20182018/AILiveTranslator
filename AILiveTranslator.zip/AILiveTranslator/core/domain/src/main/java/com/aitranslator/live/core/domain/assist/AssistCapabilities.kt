package com.aitranslator.live.core.domain.assist

import com.aitranslator.live.core.domain.model.Capability
import com.aitranslator.live.core.domain.model.CapabilityReport
import com.aitranslator.live.core.domain.model.CapabilityStatus

/**
 * The honest capability matrix for the two "translate someone else's call" features.
 *
 * These strings are shown to the user *before* they start either mode. The project
 * deliberately refuses to imply that a normal Android app can read or inject call audio,
 * because it cannot — see the per-capability explanations below.
 */
object AssistCapabilities {

    const val WHATSAPP = "whatsapp"
    const val PHONE_CALL = "phone_call"

    val whatsApp = CapabilityReport(
        feature = WHATSAPP,
        capabilities = listOf(
            Capability(
                id = "chat_text_translation",
                title = "Translate WhatsApp chat messages",
                status = CapabilityStatus.REQUIRES_SETUP,
                explanation = "An Accessibility Service reads the message text that is " +
                    "visible on screen and translates it. You must enable the service " +
                    "yourself in Android Settings, and it only reads WhatsApp screens.",
                alternative = null,
            ),
            Capability(
                id = "call_audio_capture",
                title = "Capture the other person's voice during a WhatsApp call",
                status = CapabilityStatus.BLOCKED_BY_PLATFORM,
                explanation = "Android only lets an app capture another app's audio through " +
                    "MediaProjection + AudioPlaybackCaptureConfiguration, and that API can " +
                    "never capture streams whose usage is VOICE_COMMUNICATION — which is " +
                    "what every VoIP call uses. It also honours each app's capture policy, " +
                    "and WhatsApp does not opt in. No permission changes this.",
                alternative = "Speaker Assist: put the call on speakerphone and let the app " +
                    "listen through the microphone.",
            ),
            Capability(
                id = "call_audio_injection",
                title = "Send the translated voice into the WhatsApp call",
                status = CapabilityStatus.BLOCKED_BY_PLATFORM,
                explanation = "Android has no public API to write audio into another app's " +
                    "microphone input. A virtual microphone requires a system or OEM audio " +
                    "HAL, not an installable app.",
                alternative = "The translation is played on your speaker, so the other side " +
                    "hears it acoustically while the call is on speakerphone.",
            ),
            Capability(
                id = "speaker_assist",
                title = "Speaker Assist (mic listens to the speakerphone)",
                status = CapabilityStatus.DEVICE_DEPENDENT,
                explanation = "Since Android 10 the microphone is exclusive to the app that " +
                    "holds audio focus. On many devices a background app gets silence while " +
                    "a VoIP call is active. Where it does work, quality is limited because " +
                    "the audio has been through a speaker and a microphone.",
                alternative = "If no audio is detected the app tells you instead of showing " +
                    "an empty screen.",
            ),
        ),
    )

    val phoneCall = CapabilityReport(
        feature = PHONE_CALL,
        capabilities = listOf(
            Capability(
                id = "call_audio_stream",
                title = "Read the cellular call audio stream",
                status = CapabilityStatus.BLOCKED_BY_PLATFORM,
                explanation = "MediaRecorder.AudioSource.VOICE_CALL / VOICE_DOWNLINK / " +
                    "VOICE_UPLINK require android.permission.CAPTURE_AUDIO_OUTPUT, which is " +
                    "signature|privileged. A Play Store app cannot hold it; on Android 10+ " +
                    "the request fails or returns silence.",
                alternative = "Call Assistant Mode with speakerphone + microphone.",
            ),
            Capability(
                id = "call_recording",
                title = "Record the call",
                status = CapabilityStatus.BLOCKED_BY_PLATFORM,
                explanation = "Call recording was closed off in Android 10 and hardened in " +
                    "Android 11. Play policy also forbids using an Accessibility Service to " +
                    "record calls, so there is no compliant workaround.",
                alternative = null,
            ),
            Capability(
                id = "uplink_injection",
                title = "Speak the translation into the call for the other party",
                status = CapabilityStatus.BLOCKED_BY_PLATFORM,
                explanation = "InCallService and the dialer role let an app control a call " +
                    "(answer, mute, hold, route to speaker) but give no access to the audio " +
                    "samples. CallScreeningService sees metadata only.",
                alternative = "Play the translation out loud on speakerphone so the other " +
                    "party hears it.",
            ),
            Capability(
                id = "call_state",
                title = "Detect that a call is in progress",
                status = CapabilityStatus.REQUIRES_SETUP,
                explanation = "With the optional READ_PHONE_STATE permission the app can " +
                    "notice an active call and offer to start Call Assistant Mode.",
                alternative = null,
            ),
            Capability(
                id = "assistant_mode",
                title = "Call Assistant Mode (subtitles + read-aloud)",
                status = CapabilityStatus.DEVICE_DEPENDENT,
                explanation = "The microphone picks up the speakerphone output, transcribes " +
                    "and translates it into on-screen subtitles; your replies are translated " +
                    "and can be played aloud. Whether the mic receives audio during a call " +
                    "depends on the device and Android version.",
                alternative = null,
            ),
        ),
    )

    fun forFeature(feature: String): CapabilityReport = when (feature) {
        WHATSAPP -> whatsApp
        else -> phoneCall
    }
}
