package com.aitranslator.live.core.domain.model

/**
 * The *metadata* of a stored key. The plaintext key itself is only ever returned by
 * `ApiKeyRepository.getKey()` at the moment a request is built — it is never held in a
 * ViewModel, never put into a UI state object and never logged.
 */
data class ApiKeyEntry(
    val provider: AiProvider,
    val isStored: Boolean,
    val isActive: Boolean,
    /** e.g. `sk-a••••••••3f9c` — safe to display. */
    val maskedKey: String,
    val lastValidatedMillis: Long? = null,
    val lastValidationSucceeded: Boolean? = null,
)
