package com.aitranslator.live.core.domain.provider

import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.SynthesizedAudio
import com.aitranslator.live.core.domain.model.TtsEngine
import com.aitranslator.live.core.domain.model.VoiceProfile

/**
 * Speech-to-text. The first release uses cloud recognition only, because on-device
 * recognition for Persian/Arabic/Dutch is not guaranteed to be installed.
 *
 * An offline implementation can be added later without touching any caller.
 */
interface SpeechRecognitionProvider {

    val provider: AiProvider

    /**
     * @param wavAudio a complete 16-bit PCM WAV container (see `WavEncoder`).
     * @param language expected spoken language; passed as a hint to improve accuracy.
     */
    suspend fun transcribe(
        wavAudio: ByteArray,
        language: Language,
        apiKey: String,
        model: String,
    ): AppResult<String>
}

/** Text-to-speech. Two implementations exist: device TTS and OpenAI cloud TTS. */
interface TextToSpeechProvider {

    val engine: TtsEngine

    /** Voices this engine can offer right now (device engines resolve theirs at runtime). */
    suspend fun availableVoices(): List<VoiceProfile>

    /**
     * Cloud engines return audio bytes for the caller to play; the device engine plays
     * directly and returns `null` bytes — see [SpeechSynthesis].
     */
    suspend fun synthesize(
        text: String,
        language: Language,
        voice: VoiceProfile,
        speed: Float,
        volume: Float,
    ): AppResult<SpeechSynthesis>

    /** Stops any in-flight speech immediately. */
    suspend fun stop()
}

/**
 * Result of a synthesis call.
 *
 * [audio] is `null` for the device engine, which has already spoken the text by the time
 * the call returns; cloud engines return bytes that the caller hands to an `AudioPlayer`
 * so the same code path can also save them to history.
 */
data class SpeechSynthesis(
    val audio: SynthesizedAudio?,
    val playedByEngine: Boolean,
)
