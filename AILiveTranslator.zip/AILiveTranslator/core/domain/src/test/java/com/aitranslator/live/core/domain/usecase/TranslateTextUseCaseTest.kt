package com.aitranslator.live.core.domain.usecase

import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.common.NetworkMonitor
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.TranslationChunk
import com.aitranslator.live.core.domain.model.TranslationRequest
import com.aitranslator.live.core.domain.model.TranslationResult
import com.aitranslator.live.core.domain.repository.TranslationRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The use case exists to stop three classes of pointless API calls: empty input, the same
 * language on both sides, and calls made while offline.
 */
class TranslateTextUseCaseTest {

    private class RecordingRepository : TranslationRepository {
        var calls = 0

        override suspend fun translate(
            request: TranslationRequest,
        ): AppResult<TranslationResult> {
            calls++
            return AppResult.Success(
                TranslationResult(
                    originalText = request.text,
                    translatedText = "Hello",
                    sourceLanguage = request.sourceLanguage,
                    targetLanguage = request.targetLanguage,
                    provider = AiProvider.OPENAI,
                    model = "test",
                    latencyMillis = 1,
                ),
            )
        }

        override fun translateStreaming(request: TranslationRequest): Flow<TranslationChunk> =
            emptyFlow()

        override suspend fun resolveProvider(): AppResult<AiProvider> =
            AppResult.Success(AiProvider.OPENAI)

        override suspend fun testConnection(
            provider: AiProvider,
            key: String?,
            model: String?,
        ): AppResult<Unit> = AppResult.Success(Unit)

        override fun clearCache() = Unit
    }

    private class StubNetworkMonitor(private val online: Boolean) : NetworkMonitor {
        override val isOnline: Flow<Boolean> = flowOf(online)
        override fun isCurrentlyOnline(): Boolean = online
    }

    private fun useCase(repository: TranslationRepository, online: Boolean = true) =
        TranslateTextUseCase(repository, StubNetworkMonitor(online))

    @Test
    fun `blank input never reaches the repository`() = runTest {
        val repository = RecordingRepository()

        val result = useCase(repository)(
            TranslationRequest("   ", Language.PERSIAN, Language.ENGLISH),
        )

        assertTrue((result as AppResult.Failure).error is AppError.EmptyInput)
        assertEquals(0, repository.calls)
    }

    @Test
    fun `same source and target is returned unchanged without an API call`() = runTest {
        val repository = RecordingRepository()

        val result = useCase(repository)(
            TranslationRequest("Hello", Language.ENGLISH, Language.ENGLISH),
        )

        assertEquals("Hello", (result as AppResult.Success).data.translatedText)
        assertEquals(0, repository.calls)
    }

    @Test
    fun `offline fails fast with NoInternet`() = runTest {
        val repository = RecordingRepository()

        val result = useCase(repository, online = false)(
            TranslationRequest("سلام", Language.PERSIAN, Language.ENGLISH),
        )

        assertTrue((result as AppResult.Failure).error is AppError.NoInternet)
        assertEquals(0, repository.calls)
    }

    @Test
    fun `input is trimmed before it is sent`() = runTest {
        val repository = RecordingRepository()

        val result = useCase(repository)(
            TranslationRequest("  سلام  ", Language.PERSIAN, Language.ENGLISH),
        )

        assertEquals("سلام", (result as AppResult.Success).data.originalText)
        assertEquals(1, repository.calls)
    }
}
