package com.aitranslator.live.core.network.stt

import android.util.Base64
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.provider.SpeechRecognitionProvider
import com.aitranslator.live.core.network.ApiHosts
import com.aitranslator.live.core.network.api.GeminiApi
import com.aitranslator.live.core.network.dto.GeminiContent
import com.aitranslator.live.core.network.dto.GeminiGenerationConfig
import com.aitranslator.live.core.network.dto.GeminiInlineData
import com.aitranslator.live.core.network.dto.GeminiPart
import com.aitranslator.live.core.network.dto.GeminiRequest
import com.aitranslator.live.core.network.error.ErrorMapper
import com.aitranslator.live.core.network.prompt.TranslationPrompt
import com.aitranslator.live.core.network.provider.safeApiCall
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Gemini transcribes audio by accepting it as `inline_data` inside a normal
 * `generateContent` call. Used as the STT fallback when no OpenAI key is configured.
 */
@Singleton
class GeminiSpeechRecognitionProvider @Inject constructor(
    private val api: GeminiApi,
    private val errorMapper: ErrorMapper,
    private val hosts: ApiHosts,
) : SpeechRecognitionProvider {

    override val provider: AiProvider = AiProvider.GEMINI

    override suspend fun transcribe(
        wavAudio: ByteArray,
        language: Language,
        apiKey: String,
        model: String,
    ): AppResult<String> {
        val encoded = Base64.encodeToString(wavAudio, Base64.NO_WRAP)

        val body = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    role = GeminiContent.ROLE_USER,
                    parts = listOf(
                        GeminiPart(text = TranslationPrompt.transcriptionPrompt(language.englishName)),
                        GeminiPart(
                            inlineData = GeminiInlineData(
                                mimeType = "audio/wav",
                                data = encoded,
                            ),
                        ),
                    ),
                ),
            ),
            generationConfig = GeminiGenerationConfig(
                temperature = 0f,
                maxOutputTokens = 512,
                responseMimeType = "text/plain",
            ),
        )

        val response = safeApiCall(provider, errorMapper, model) {
            api.generateContent(
                url = hosts.geminiGenerateContent(model),
                apiKey = apiKey,
                body = body,
            )
        }

        return response.map { it.firstText().trim() }
    }
}
