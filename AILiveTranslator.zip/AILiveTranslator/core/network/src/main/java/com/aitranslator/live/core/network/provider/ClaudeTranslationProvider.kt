package com.aitranslator.live.core.network.provider

import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.TranslationChunk
import com.aitranslator.live.core.domain.model.TranslationRequest
import com.aitranslator.live.core.domain.model.TranslationResult
import com.aitranslator.live.core.domain.provider.AITranslationProvider
import com.aitranslator.live.core.domain.provider.TranslationStreamException
import com.aitranslator.live.core.network.ApiHosts
import com.aitranslator.live.core.network.api.ClaudeApi
import com.aitranslator.live.core.network.dto.ClaudeMessage
import com.aitranslator.live.core.network.dto.ClaudeRequest
import com.aitranslator.live.core.network.dto.ClaudeStreamEvent
import com.aitranslator.live.core.network.error.ErrorMapper
import com.aitranslator.live.core.network.http.sseEvents
import com.aitranslator.live.core.network.prompt.TranslationPrompt
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ClaudeTranslationProvider @Inject constructor(
    private val api: ClaudeApi,
    private val errorMapper: ErrorMapper,
    private val json: Json,
    private val hosts: ApiHosts,
) : AITranslationProvider {

    override val provider: AiProvider = AiProvider.CLAUDE

    override val supportsStreaming: Boolean = true

    override suspend fun translate(
        request: TranslationRequest,
        apiKey: String,
        model: String,
        maxOutputTokens: Int,
        temperature: Float,
    ): AppResult<TranslationResult> {
        val started = System.currentTimeMillis()

        val response = safeApiCall(provider, errorMapper, model) {
            api.messages(
                url = hosts.claudeMessages,
                apiKey = apiKey,
                version = ApiHosts.ANTHROPIC_VERSION,
                body = ClaudeRequest(
                    model = model,
                    maxTokens = maxOutputTokens,
                    system = TranslationPrompt.systemInstruction(request),
                    messages = listOf(ClaudeMessage(ClaudeMessage.ROLE_USER, request.text)),
                    temperature = temperature,
                ),
            )
        }

        return response.flatMap { body ->
            val text = body.firstText().cleanTranslationOutput()
            if (text.isBlank()) {
                AppResult.Failure(
                    AppError.Unknown("provider=claude model=$model returned no translation"),
                )
            } else {
                AppResult.Success(
                    TranslationResult(
                        originalText = request.text,
                        translatedText = text,
                        sourceLanguage = request.sourceLanguage,
                        targetLanguage = request.targetLanguage,
                        provider = provider,
                        model = body.model ?: model,
                        latencyMillis = System.currentTimeMillis() - started,
                    ),
                )
            }
        }
    }

    override fun translateStream(
        request: TranslationRequest,
        apiKey: String,
        model: String,
        maxOutputTokens: Int,
        temperature: Float,
    ): Flow<TranslationChunk> = flow {
        val streamResult = safeStreamCall(provider, errorMapper, model) {
            api.messagesStream(
                url = hosts.claudeMessages,
                apiKey = apiKey,
                version = ApiHosts.ANTHROPIC_VERSION,
                accept = SSE_ACCEPT,
                body = ClaudeRequest(
                    model = model,
                    maxTokens = maxOutputTokens,
                    system = TranslationPrompt.systemInstruction(request),
                    messages = listOf(ClaudeMessage(ClaudeMessage.ROLE_USER, request.text)),
                    temperature = temperature,
                    stream = true,
                ),
            )
        }

        val body = when (streamResult) {
            is AppResult.Failure -> throw TranslationStreamException(streamResult.error)
            is AppResult.Success -> streamResult.data
        }

        val accumulated = StringBuilder()
        body.sseEvents().collect { event ->
            val parsed = runCatching {
                json.decodeFromString(ClaudeStreamEvent.serializer(), event.data)
            }.getOrNull() ?: return@collect

            if (parsed.type == "content_block_delta") {
                val delta = parsed.delta?.text
                if (!delta.isNullOrEmpty()) {
                    accumulated.append(delta)
                    emit(TranslationChunk.Delta(delta))
                }
            }
        }

        emit(TranslationChunk.Completed(accumulated.toString().cleanTranslationOutput()))
    }

    override suspend fun testConnection(apiKey: String, model: String): AppResult<Unit> {
        val response = safeApiCall(provider, errorMapper, model) {
            api.messages(
                url = hosts.claudeMessages,
                apiKey = apiKey,
                version = ApiHosts.ANTHROPIC_VERSION,
                body = ClaudeRequest(
                    model = model,
                    maxTokens = 8,
                    messages = listOf(ClaudeMessage(ClaudeMessage.ROLE_USER, "ping")),
                    temperature = 0f,
                ),
            )
        }
        return response.map { }
    }
}
