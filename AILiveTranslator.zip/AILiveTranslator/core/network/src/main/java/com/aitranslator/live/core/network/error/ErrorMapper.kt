package com.aitranslator.live.core.network.error

import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.domain.model.AiProvider
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeoutException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Converts everything a network call can go wrong with into an [AppError].
 *
 * The technical detail (HTTP code, provider error type, message) is preserved for debug
 * logs; the UI only ever renders the typed error.
 */
@Singleton
class ErrorMapper @Inject constructor() {

    private val lenientJson = Json { ignoreUnknownKeys = true; isLenient = true }

    fun fromThrowable(throwable: Throwable, provider: AiProvider): AppError = when (throwable) {
        is UnknownHostException -> AppError.NoInternet(throwable.message)
        is SocketTimeoutException, is TimeoutException -> AppError.Timeout(throwable.message)
        is IOException -> AppError.NoInternet(throwable.message ?: "IO failure")
        else -> AppError.Unknown("${provider.id}: ${throwable.message}")
    }

    fun fromHttp(
        code: Int,
        rawBody: String?,
        provider: AiProvider,
        model: String? = null,
        retryAfterHeader: String? = null,
    ): AppError {
        val parsed = parseProviderMessage(rawBody)
        val detail = buildString {
            append("provider=${provider.id} http=$code")
            if (!model.isNullOrBlank()) append(" model=$model")
            if (!parsed.isNullOrBlank()) append(" message=$parsed")
        }

        val looksLikeMissingModel = parsed?.contains("model", ignoreCase = true) == true &&
            (
                parsed.contains("not found", ignoreCase = true) ||
                    parsed.contains("does not exist", ignoreCase = true) ||
                    parsed.contains("unsupported", ignoreCase = true)
                )

        return when {
            code == 401 || code == 403 -> AppError.InvalidApiKey(provider.id, detail)
            code == 429 -> AppError.RateLimited(retryAfterHeader?.toLongOrNull(), detail)
            code == 404 || looksLikeMissingModel ->
                AppError.ModelUnavailable(model.orEmpty(), detail)
            code == 408 -> AppError.Timeout(detail)
            code in 500..599 -> AppError.ServerError(code, detail)
            code == 400 && looksLikeMissingModel -> AppError.ModelUnavailable(model.orEmpty(), detail)
            else -> AppError.Unknown(detail)
        }
    }

    /**
     * All three vendors nest the human-readable reason differently:
     * OpenAI `{"error":{"message":…}}`, Gemini `{"error":{"message":…}}`,
     * Claude `{"error":{"message":…,"type":…}}` — plus occasional plain text.
     */
    private fun parseProviderMessage(rawBody: String?): String? {
        if (rawBody.isNullOrBlank()) return null
        return runCatching {
            val root = lenientJson.parseToJsonElement(rawBody) as? JsonObject ?: return@runCatching null
            val error = root["error"]?.jsonObject
            error?.get("message")?.jsonPrimitive?.content
                ?: root["message"]?.jsonPrimitive?.content
        }.getOrNull() ?: rawBody.take(300)
    }
}
