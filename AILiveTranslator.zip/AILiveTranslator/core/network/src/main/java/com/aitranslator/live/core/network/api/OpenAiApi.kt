package com.aitranslator.live.core.network.api

import com.aitranslator.live.core.network.dto.OpenAiChatRequest
import com.aitranslator.live.core.network.dto.OpenAiChatResponse
import com.aitranslator.live.core.network.dto.OpenAiSpeechRequest
import com.aitranslator.live.core.network.dto.OpenAiTranscriptionResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Streaming
import retrofit2.http.Url

/**
 * The API key is passed per call as a header and is never stored on the client, so a key
 * change takes effect immediately and nothing is cached that would have to be invalidated.
 */
interface OpenAiApi {

    @POST
    suspend fun chatCompletion(
        @Url url: String,
        @Header("Authorization") authorization: String,
        @Body body: OpenAiChatRequest,
    ): Response<OpenAiChatResponse>

    @Streaming
    @POST
    suspend fun chatCompletionStream(
        @Url url: String,
        @Header("Authorization") authorization: String,
        @Header("Accept") accept: String,
        @Body body: OpenAiChatRequest,
    ): Response<ResponseBody>

    @Multipart
    @POST
    suspend fun transcribe(
        @Url url: String,
        @Header("Authorization") authorization: String,
        @Part file: MultipartBody.Part,
        @Part("model") model: RequestBody,
        @Part("language") language: RequestBody?,
        @Part("prompt") prompt: RequestBody?,
        @Part("response_format") responseFormat: RequestBody,
    ): Response<OpenAiTranscriptionResponse>

    @Streaming
    @POST
    suspend fun speech(
        @Url url: String,
        @Header("Authorization") authorization: String,
        @Body body: OpenAiSpeechRequest,
    ): Response<ResponseBody>

    @GET
    suspend fun models(
        @Url url: String,
        @Header("Authorization") authorization: String,
    ): Response<ResponseBody>
}
