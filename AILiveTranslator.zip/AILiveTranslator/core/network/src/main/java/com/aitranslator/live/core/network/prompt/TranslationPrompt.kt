package com.aitranslator.live.core.network.prompt

import com.aitranslator.live.core.domain.model.TranslationMode
import com.aitranslator.live.core.domain.model.TranslationRequest

/**
 * Builds the instruction sent to every provider.
 *
 * Kept in one place so the three vendors behave identically and so prompt tuning is a
 * single edit. The rules are deliberately strict: the model must return the translation
 * and nothing else, otherwise TTS would read explanations aloud.
 */
object TranslationPrompt {

    fun systemInstruction(request: TranslationRequest): String = buildString {
        append("You are a professional real-time translator. ")
        append("Translate the user's message from ${request.sourceLanguage.englishName} ")
        append("into ${request.targetLanguage.englishName}.\n\n")
        append("Rules:\n")
        append("1. Output ONLY the translated text. No preamble, no notes, no quotes, ")
        append("no transliteration, no explanation of your reasoning.\n")
        append("2. Preserve meaning, tone and register. Keep it natural and idiomatic ")
        append("rather than literal.\n")
        append("3. Keep numbers, dates, names, URLs and code unchanged unless the target ")
        append("language conventionally writes them differently.\n")
        append("4. If the input is already in ${request.targetLanguage.englishName}, return it unchanged.\n")
        append("5. If the input is empty or unintelligible, return an empty string.\n")

        when (request.mode) {
            TranslationMode.LIVE, TranslationMode.CONVERSATION -> {
                append("6. This is live speech: the input comes from speech recognition and ")
                append("may contain fillers, false starts or missing punctuation. Clean it up ")
                append("lightly and translate the intended meaning. Prefer short sentences.\n")
            }

            TranslationMode.PHONE_CALL, TranslationMode.WHATSAPP -> {
                append("6. This is conversational phone/chat speech. Use spoken register and ")
                append("keep sentences short so they are easy to read aloud.\n")
            }

            else -> Unit
        }

        if (request.context.isNotEmpty()) {
            append("\nRecent conversation context (for pronouns and consistency only, ")
            append("do not translate it again):\n")
            request.context.takeLast(MAX_CONTEXT_TURNS).forEach { line ->
                append("- ").append(line.take(MAX_CONTEXT_CHARS)).append('\n')
            }
        }
    }

    /** Gemini has no dedicated system role in `generateContent` parts, so we inline it. */
    fun singleTurnPrompt(request: TranslationRequest): String =
        systemInstruction(request) + "\n\nText to translate:\n" + request.text

    fun transcriptionPrompt(languageEnglishName: String): String =
        "Transcribe this audio verbatim in $languageEnglishName. " +
            "Output only the transcript text, with no commentary, no timestamps and no speaker labels. " +
            "If the audio contains no speech, output an empty string."

    private const val MAX_CONTEXT_TURNS = 6
    private const val MAX_CONTEXT_CHARS = 200
}
