package com.aitranslator.live.core.network.realtime

import android.util.Base64
import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.Logger
import com.aitranslator.live.core.domain.live.RealtimeConfig
import com.aitranslator.live.core.domain.live.RealtimeSignal
import com.aitranslator.live.core.domain.live.RealtimeTranslationClient
import com.aitranslator.live.core.domain.model.AiModelConfig
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.repository.ApiKeyRepository
import com.aitranslator.live.core.network.ApiHosts
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import javax.inject.Inject
import javax.inject.Singleton

/**
 * OpenAI Realtime WebSocket transport.
 *
 * This is the low-latency path for Live mode: audio goes up while the user is still
 * speaking and the translated audio comes back before they finish, which a
 * record → upload → translate → synthesise round trip cannot match.
 *
 * The session is driven entirely by `inputAudio`; when that flow completes the buffer is
 * committed and the socket closes. Turn detection is done server-side, so no local VAD
 * runs in this mode.
 */
@Singleton
class OpenAiRealtimeClient @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val json: Json,
    private val apiKeyRepository: ApiKeyRepository,
    private val hosts: ApiHosts,
) : RealtimeTranslationClient {

    override suspend fun isAvailable(): Boolean =
        !apiKeyRepository.getKey(AiProvider.OPENAI).isNullOrBlank()

    override fun connect(
        config: RealtimeConfig,
        inputAudio: Flow<ByteArray>,
    ): Flow<RealtimeSignal> = callbackFlow {
        val apiKey = apiKeyRepository.getKey(AiProvider.OPENAI)
        if (apiKey.isNullOrBlank()) {
            trySend(
                RealtimeSignal.Failed(
                    AppError.NotConfigured(AiProvider.OPENAI.id, "realtime requires an OpenAI key"),
                ),
            )
            close()
            return@callbackFlow
        }

        val models = AiModelConfig.defaultFor(AiProvider.OPENAI)

        val request = Request.Builder()
            .url("${hosts.openAiRealtimeWs}?model=${models.realtimeModel}")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("OpenAI-Beta", "realtime=v1")
            .build()

        val producerScope = this
        var uploadJob: Job? = null

        val listener = object : WebSocketListener() {

            override fun onOpen(webSocket: WebSocket, response: Response) {
                Logger.d(TAG, "realtime socket opened")
                webSocket.send(sessionUpdatePayload(config, models.transcriptionModel))
                trySend(RealtimeSignal.Connected)

                uploadJob = producerScope.launch {
                    runCatching {
                        inputAudio.collect { pcm ->
                            if (pcm.isNotEmpty()) {
                                webSocket.send(appendAudioPayload(pcm))
                            }
                        }
                    }.onFailure { throwable ->
                        Logger.w(TAG, "audio upload ended: ${throwable.message}")
                    }
                    runCatching { webSocket.send(COMMIT_PAYLOAD) }
                }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val event = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
                    ?: return
                dispatch(event)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val code = response?.code ?: 0
                val error = when {
                    code == 401 || code == 403 ->
                        AppError.InvalidApiKey("openai", "realtime handshake rejected")
                    code == 429 -> AppError.RateLimited(null, "realtime rate limited")
                    code in 500..599 -> AppError.ServerError(code, t.message)
                    else -> AppError.NoInternet(t.message)
                }
                trySend(RealtimeSignal.Failed(error))
                close()
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                trySend(RealtimeSignal.Closed)
                close()
            }

            private fun dispatch(event: JsonObject) {
                when (val type = event["type"]?.jsonPrimitive?.content) {
                    "input_audio_buffer.speech_started" -> trySend(RealtimeSignal.SpeechStarted)

                    "input_audio_buffer.speech_stopped" -> trySend(RealtimeSignal.SpeechStopped)

                    "conversation.item.input_audio_transcription.completed" -> {
                        val transcript = event["transcript"]?.jsonPrimitive?.content.orEmpty()
                        if (transcript.isNotBlank()) {
                            trySend(RealtimeSignal.InputTranscript(transcript.trim()))
                        }
                    }

                    "response.audio_transcript.delta", "response.text.delta" -> {
                        val delta = event["delta"]?.jsonPrimitive?.content.orEmpty()
                        if (delta.isNotEmpty()) trySend(RealtimeSignal.OutputTextDelta(delta))
                    }

                    "response.audio_transcript.done", "response.text.done" -> {
                        val done = event["transcript"]?.jsonPrimitive?.content
                            ?: event["text"]?.jsonPrimitive?.content
                        if (!done.isNullOrBlank()) {
                            trySend(RealtimeSignal.OutputTextDone(done.trim()))
                        }
                    }

                    "response.audio.delta" -> {
                        val encoded = event["delta"]?.jsonPrimitive?.content
                        if (!encoded.isNullOrEmpty()) {
                            runCatching { Base64.decode(encoded, Base64.NO_WRAP) }
                                .getOrNull()
                                ?.let { trySend(RealtimeSignal.OutputAudioDelta(it)) }
                        }
                    }

                    "response.done" -> trySend(RealtimeSignal.ResponseCompleted)

                    "error" -> {
                        val message = event["error"]?.jsonObject
                            ?.get("message")?.jsonPrimitive?.content
                            .orEmpty()
                        trySend(RealtimeSignal.Failed(AppError.Unknown("realtime: $message")))
                    }

                    else -> Logger.d(TAG, "unhandled realtime event: $type")
                }
            }
        }

        val socket = okHttpClient.newWebSocket(request, listener)

        awaitClose {
            uploadJob?.cancel()
            runCatching { socket.close(NORMAL_CLOSURE, "client closed") }
        }
    }

    private fun sessionUpdatePayload(config: RealtimeConfig, transcriptionModel: String): String =
        buildJsonObject {
            put("type", "session.update")
            putJsonObject("session") {
                putJsonArray("modalities") {
                    add("text")
                    if (config.wantAudioOutput) add("audio")
                }
                put("instructions", config.instructions)
                put("voice", config.voice)
                put("input_audio_format", "pcm16")
                put("output_audio_format", "pcm16")
                putJsonObject("input_audio_transcription") {
                    put("model", transcriptionModel)
                }
                putJsonObject("turn_detection") {
                    put("type", "server_vad")
                    put("threshold", 0.5)
                    put("prefix_padding_ms", 300)
                    put("silence_duration_ms", 500)
                }
            }
        }.toString()

    private fun appendAudioPayload(pcm: ByteArray): String = buildJsonObject {
        put("type", "input_audio_buffer.append")
        put("audio", Base64.encodeToString(pcm, Base64.NO_WRAP))
    }.toString()

    private companion object {
        const val TAG = "Realtime"
        const val NORMAL_CLOSURE = 1000
        val COMMIT_PAYLOAD: String = buildJsonObject {
            put("type", "input_audio_buffer.commit")
        }.toString()
    }
}
