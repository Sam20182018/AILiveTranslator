package com.aitranslator.live.core.network

/**
 * Every absolute URL the app talks to.
 *
 * Injected rather than referenced as constants so that (a) a proxy or enterprise gateway
 * is a one-line DI change and (b) tests can point the same providers at a local
 * `MockWebServer` without any production code knowing about it.
 */
data class ApiHosts(
    val openAiBase: String = DEFAULT_OPENAI_BASE,
    val geminiBase: String = DEFAULT_GEMINI_BASE,
    val claudeBase: String = DEFAULT_CLAUDE_BASE,
    val openAiRealtimeWs: String = DEFAULT_OPENAI_REALTIME_WS,
) {
    val openAiChatCompletions: String get() = "${openAiBase}chat/completions"
    val openAiTranscriptions: String get() = "${openAiBase}audio/transcriptions"
    val openAiSpeech: String get() = "${openAiBase}audio/speech"
    val claudeMessages: String get() = "${claudeBase}messages"

    fun geminiGenerateContent(model: String): String = "${geminiBase}models/$model:generateContent"

    fun geminiStreamGenerateContent(model: String): String =
        "${geminiBase}models/$model:streamGenerateContent?alt=sse"

    companion object {
        const val DEFAULT_OPENAI_BASE = "https://api.openai.com/v1/"
        const val DEFAULT_GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/"
        const val DEFAULT_CLAUDE_BASE = "https://api.anthropic.com/v1/"
        const val DEFAULT_OPENAI_REALTIME_WS = "wss://api.openai.com/v1/realtime"

        /** Retrofit requires a base URL even when every call supplies an absolute `@Url`. */
        const val PLACEHOLDER_BASE_URL = "https://api.invalid/"

        const val ANTHROPIC_VERSION_HEADER = "anthropic-version"
        const val ANTHROPIC_VERSION = "2023-06-01"
    }
}
