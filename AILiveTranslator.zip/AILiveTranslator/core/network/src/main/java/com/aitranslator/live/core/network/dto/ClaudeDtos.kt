package com.aitranslator.live.core.network.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ClaudeRequest(
    val model: String,
    @SerialName("max_tokens") val maxTokens: Int,
    val messages: List<ClaudeMessage>,
    val system: String? = null,
    val temperature: Float? = null,
    val stream: Boolean? = null,
)

@Serializable
data class ClaudeMessage(
    val role: String,
    val content: String,
) {
    companion object {
        const val ROLE_USER = "user"
        const val ROLE_ASSISTANT = "assistant"
    }
}

@Serializable
data class ClaudeResponse(
    val id: String? = null,
    val model: String? = null,
    val content: List<ClaudeContentBlock> = emptyList(),
    @SerialName("stop_reason") val stopReason: String? = null,
    val usage: ClaudeUsage? = null,
) {
    fun firstText(): String =
        content.filter { it.type == "text" }.mapNotNull { it.text }.joinToString(separator = "")
}

@Serializable
data class ClaudeContentBlock(
    val type: String = "text",
    val text: String? = null,
)

@Serializable
data class ClaudeUsage(
    @SerialName("input_tokens") val inputTokens: Int = 0,
    @SerialName("output_tokens") val outputTokens: Int = 0,
)

/** Streaming envelope: only `content_block_delta` carries text. */
@Serializable
data class ClaudeStreamEvent(
    val type: String,
    val delta: ClaudeStreamDelta? = null,
)

@Serializable
data class ClaudeStreamDelta(
    val type: String? = null,
    val text: String? = null,
)
