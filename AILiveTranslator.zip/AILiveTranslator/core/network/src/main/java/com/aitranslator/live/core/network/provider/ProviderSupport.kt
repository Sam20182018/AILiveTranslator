package com.aitranslator.live.core.network.provider

import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.network.error.ErrorMapper
import retrofit2.Response
import java.util.concurrent.CancellationException

internal const val SSE_ACCEPT = "text/event-stream"

/**
 * Wraps a suspending Retrofit call so that no exception and no unsuccessful HTTP response
 * can escape as anything other than an [AppError].
 */
internal suspend fun <T> safeApiCall(
    provider: AiProvider,
    errorMapper: ErrorMapper,
    model: String? = null,
    block: suspend () -> Response<T>,
): AppResult<T> = try {
    val response = block()
    if (response.isSuccessful) {
        val body = response.body()
        if (body == null) {
            AppResult.Failure(
                AppError.Unknown("provider=${provider.id} http=${response.code()} empty body"),
            )
        } else {
            AppResult.Success(body)
        }
    } else {
        AppResult.Failure(
            errorMapper.fromHttp(
                code = response.code(),
                rawBody = response.errorBody()?.string(),
                provider = provider,
                model = model,
                retryAfterHeader = response.headers()["retry-after"],
            ),
        )
    }
} catch (cancellation: CancellationException) {
    throw cancellation
} catch (throwable: Throwable) {
    AppResult.Failure(errorMapper.fromThrowable(throwable, provider))
}

/** Same guarantees for calls whose success body is a raw stream. */
internal suspend fun safeStreamCall(
    provider: AiProvider,
    errorMapper: ErrorMapper,
    model: String? = null,
    block: suspend () -> Response<okhttp3.ResponseBody>,
): AppResult<okhttp3.ResponseBody> = try {
    val response = block()
    if (response.isSuccessful) {
        val body = response.body()
        if (body == null) {
            AppResult.Failure(AppError.Unknown("provider=${provider.id} empty stream body"))
        } else {
            AppResult.Success(body)
        }
    } else {
        AppResult.Failure(
            errorMapper.fromHttp(
                code = response.code(),
                rawBody = response.errorBody()?.string(),
                provider = provider,
                model = model,
                retryAfterHeader = response.headers()["retry-after"],
            ),
        )
    }
} catch (cancellation: CancellationException) {
    throw cancellation
} catch (throwable: Throwable) {
    AppResult.Failure(errorMapper.fromThrowable(throwable, provider))
}

/**
 * Models occasionally wrap output in quotes or prefix it with `Translation:` despite the
 * system prompt. This strips those without touching legitimate content.
 */
internal fun String.cleanTranslationOutput(): String {
    var text = trim()
    val prefixes = listOf("translation:", "translated text:", "ترجمه:", "übersetzung:")
    prefixes.forEach { prefix ->
        if (text.lowercase().startsWith(prefix)) {
            text = text.substring(prefix.length).trim()
        }
    }
    if (text.length >= 2) {
        val first = text.first()
        val last = text.last()
        val quoted = (first == '"' && last == '"') || (first == '«' && last == '»') ||
            (first == '“' && last == '”')
        if (quoted) text = text.substring(1, text.length - 1).trim()
    }
    return text
}
