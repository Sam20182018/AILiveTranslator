package com.aitranslator.live.core.network.api

import com.aitranslator.live.core.network.dto.GeminiRequest
import com.aitranslator.live.core.network.dto.GeminiResponse
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Streaming
import retrofit2.http.Url

/**
 * Gemini accepts the key either as `?key=` or as the `x-goog-api-key` header. The header
 * is used so the key never appears in a URL (and therefore never in a log or a crash trace).
 */
interface GeminiApi {

    @POST
    suspend fun generateContent(
        @Url url: String,
        @Header("x-goog-api-key") apiKey: String,
        @Body body: GeminiRequest,
    ): Response<GeminiResponse>

    @Streaming
    @POST
    suspend fun streamGenerateContent(
        @Url url: String,
        @Header("x-goog-api-key") apiKey: String,
        @Header("Accept") accept: String,
        @Body body: GeminiRequest,
    ): Response<ResponseBody>
}
