package com.aitranslator.live.core.network.provider

import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.TranslationChunk
import com.aitranslator.live.core.domain.model.TranslationRequest
import com.aitranslator.live.core.domain.model.TranslationResult
import com.aitranslator.live.core.domain.provider.AITranslationProvider
import com.aitranslator.live.core.domain.provider.TranslationStreamException
import com.aitranslator.live.core.network.ApiHosts
import com.aitranslator.live.core.network.api.GeminiApi
import com.aitranslator.live.core.network.dto.GeminiContent
import com.aitranslator.live.core.network.dto.GeminiGenerationConfig
import com.aitranslator.live.core.network.dto.GeminiRequest
import com.aitranslator.live.core.network.dto.GeminiResponse
import com.aitranslator.live.core.network.error.ErrorMapper
import com.aitranslator.live.core.network.http.sseEvents
import com.aitranslator.live.core.network.prompt.TranslationPrompt
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GeminiTranslationProvider @Inject constructor(
    private val api: GeminiApi,
    private val errorMapper: ErrorMapper,
    private val json: Json,
    private val hosts: ApiHosts,
) : AITranslationProvider {

    override val provider: AiProvider = AiProvider.GEMINI

    override val supportsStreaming: Boolean = true

    override suspend fun translate(
        request: TranslationRequest,
        apiKey: String,
        model: String,
        maxOutputTokens: Int,
        temperature: Float,
    ): AppResult<TranslationResult> {
        val started = System.currentTimeMillis()

        val response = safeApiCall(provider, errorMapper, model) {
            api.generateContent(
                url = hosts.geminiGenerateContent(model),
                apiKey = apiKey,
                body = buildRequest(request, maxOutputTokens, temperature),
            )
        }

        return response.flatMap { body ->
            val blocked = body.promptFeedback?.blockReason
            if (blocked != null) {
                return@flatMap AppResult.Failure(
                    AppError.Unknown("provider=gemini blocked reason=$blocked"),
                )
            }
            val text = body.firstText().cleanTranslationOutput()
            if (text.isBlank()) {
                AppResult.Failure(
                    AppError.Unknown("provider=gemini model=$model returned no translation"),
                )
            } else {
                AppResult.Success(
                    TranslationResult(
                        originalText = request.text,
                        translatedText = text,
                        sourceLanguage = request.sourceLanguage,
                        targetLanguage = request.targetLanguage,
                        provider = provider,
                        model = model,
                        latencyMillis = System.currentTimeMillis() - started,
                    ),
                )
            }
        }
    }

    override fun translateStream(
        request: TranslationRequest,
        apiKey: String,
        model: String,
        maxOutputTokens: Int,
        temperature: Float,
    ): Flow<TranslationChunk> = flow {
        val streamResult = safeStreamCall(provider, errorMapper, model) {
            api.streamGenerateContent(
                url = hosts.geminiStreamGenerateContent(model),
                apiKey = apiKey,
                accept = SSE_ACCEPT,
                body = buildRequest(request, maxOutputTokens, temperature),
            )
        }

        val body = when (streamResult) {
            is AppResult.Failure -> throw TranslationStreamException(streamResult.error)
            is AppResult.Success -> streamResult.data
        }

        val accumulated = StringBuilder()
        body.sseEvents().collect { event ->
            val delta = runCatching {
                json.decodeFromString(GeminiResponse.serializer(), event.data).firstText()
            }.getOrNull()

            if (!delta.isNullOrEmpty()) {
                accumulated.append(delta)
                emit(TranslationChunk.Delta(delta))
            }
        }

        emit(TranslationChunk.Completed(accumulated.toString().cleanTranslationOutput()))
    }

    override suspend fun testConnection(apiKey: String, model: String): AppResult<Unit> {
        val response = safeApiCall(provider, errorMapper, model) {
            api.generateContent(
                url = hosts.geminiGenerateContent(model),
                apiKey = apiKey,
                body = GeminiRequest(
                    contents = listOf(GeminiContent.text("ping", GeminiContent.ROLE_USER)),
                    generationConfig = GeminiGenerationConfig(maxOutputTokens = 5, temperature = 0f),
                ),
            )
        }
        return response.map { }
    }

    private fun buildRequest(
        request: TranslationRequest,
        maxOutputTokens: Int,
        temperature: Float,
    ) = GeminiRequest(
        contents = listOf(GeminiContent.text(request.text, GeminiContent.ROLE_USER)),
        systemInstruction = GeminiContent.text(TranslationPrompt.systemInstruction(request)),
        generationConfig = GeminiGenerationConfig(
            temperature = temperature,
            maxOutputTokens = maxOutputTokens,
            responseMimeType = "text/plain",
        ),
    )
}
