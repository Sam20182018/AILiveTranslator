package com.aitranslator.live.core.network.http

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import okhttp3.ResponseBody

/** One parsed Server-Sent Event. */
data class SseEvent(val event: String?, val data: String)

/**
 * Minimal SSE reader. All three vendors use the same wire format
 * (`event: …` / `data: …` separated by blank lines), so one parser covers them.
 *
 * The flow closes the body when collection ends, including on cancellation.
 */
fun ResponseBody.sseEvents(): Flow<SseEvent> = flow {
    source().use { source ->
        var eventName: String? = null
        val dataBuilder = StringBuilder()

        while (true) {
            val line = source.readUtf8Line() ?: break

            when {
                line.isEmpty() -> {
                    if (dataBuilder.isNotEmpty()) {
                        emit(SseEvent(eventName, dataBuilder.toString()))
                        dataBuilder.setLength(0)
                    }
                    eventName = null
                }

                line.startsWith(":") -> Unit // comment / keep-alive

                line.startsWith("event:") -> eventName = line.removePrefix("event:").trim()

                line.startsWith("data:") -> {
                    if (dataBuilder.isNotEmpty()) dataBuilder.append('\n')
                    dataBuilder.append(line.removePrefix("data:").trim())
                }
            }
        }

        if (dataBuilder.isNotEmpty()) {
            emit(SseEvent(eventName, dataBuilder.toString()))
        }
    }
}
