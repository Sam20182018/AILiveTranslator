package com.aitranslator.live.core.network.api

import com.aitranslator.live.core.network.dto.ClaudeRequest
import com.aitranslator.live.core.network.dto.ClaudeResponse
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Streaming
import retrofit2.http.Url

interface ClaudeApi {

    @POST
    suspend fun messages(
        @Url url: String,
        @Header("x-api-key") apiKey: String,
        @Header("anthropic-version") version: String,
        @Body body: ClaudeRequest,
    ): Response<ClaudeResponse>

    @Streaming
    @POST
    suspend fun messagesStream(
        @Url url: String,
        @Header("x-api-key") apiKey: String,
        @Header("anthropic-version") version: String,
        @Header("Accept") accept: String,
        @Body body: ClaudeRequest,
    ): Response<ResponseBody>
}
