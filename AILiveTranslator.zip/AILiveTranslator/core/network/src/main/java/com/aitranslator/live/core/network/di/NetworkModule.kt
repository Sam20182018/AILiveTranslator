package com.aitranslator.live.core.network.di

import com.aitranslator.live.core.domain.live.RealtimeTranslationClient
import com.aitranslator.live.core.domain.provider.AITranslationProvider
import com.aitranslator.live.core.domain.provider.SpeechRecognitionProvider
import com.aitranslator.live.core.domain.provider.TextToSpeechProvider
import com.aitranslator.live.core.network.ApiHosts
import com.aitranslator.live.core.network.BuildConfig
import com.aitranslator.live.core.network.api.ClaudeApi
import com.aitranslator.live.core.network.api.GeminiApi
import com.aitranslator.live.core.network.api.OpenAiApi
import com.aitranslator.live.core.network.http.RedactingInterceptor
import com.aitranslator.live.core.network.provider.ClaudeTranslationProvider
import com.aitranslator.live.core.network.provider.GeminiTranslationProvider
import com.aitranslator.live.core.network.provider.OpenAiTranslationProvider
import com.aitranslator.live.core.network.realtime.OpenAiRealtimeClient
import com.aitranslator.live.core.network.stt.GeminiSpeechRecognitionProvider
import com.aitranslator.live.core.network.stt.OpenAiSpeechRecognitionProvider
import com.aitranslator.live.core.network.tts.OpenAiTtsProvider
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoSet
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun provideApiHosts(): ApiHosts = ApiHosts()

    @Provides
    @Singleton
    fun provideJson(): Json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        encodeDefaults = false
        isLenient = true
    }

    /**
     * One client for everything. Read timeout is generous because streaming responses hold
     * the connection open between tokens; the write timeout stays short so a stalled upload
     * surfaces quickly. `pingInterval` keeps the realtime WebSocket alive on mobile NAT.
     */
    @Provides
    @Singleton
    fun provideOkHttpClient(
        redactingInterceptor: RedactingInterceptor,
    ): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .callTimeout(0, TimeUnit.SECONDS)
            .pingInterval(20, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .addInterceptor(redactingInterceptor)

        if (BuildConfig.VERBOSE_HTTP_LOG) {
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
                // Never let credentials reach Logcat, even in debug builds.
                redactHeader("Authorization")
                redactHeader("x-api-key")
                redactHeader("x-goog-api-key")
            }
            builder.addInterceptor(logging)
        }

        return builder.build()
    }

    @Provides
    @Singleton
    fun provideRetrofit(okHttpClient: OkHttpClient, json: Json): Retrofit =
        Retrofit.Builder()
            .baseUrl(ApiHosts.PLACEHOLDER_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()

    @Provides
    @Singleton
    fun provideOpenAiApi(retrofit: Retrofit): OpenAiApi = retrofit.create(OpenAiApi::class.java)

    @Provides
    @Singleton
    fun provideGeminiApi(retrofit: Retrofit): GeminiApi = retrofit.create(GeminiApi::class.java)

    @Provides
    @Singleton
    fun provideClaudeApi(retrofit: Retrofit): ClaudeApi = retrofit.create(ClaudeApi::class.java)
}

/**
 * Multibindings: the registry in `:core:data` receives whatever set of providers is
 * compiled in, so adding a vendor never touches consumer code.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class ProviderBindingsModule {

    @Binds
    @IntoSet
    abstract fun bindOpenAiTranslation(impl: OpenAiTranslationProvider): AITranslationProvider

    @Binds
    @IntoSet
    abstract fun bindGeminiTranslation(impl: GeminiTranslationProvider): AITranslationProvider

    @Binds
    @IntoSet
    abstract fun bindClaudeTranslation(impl: ClaudeTranslationProvider): AITranslationProvider

    @Binds
    @IntoSet
    abstract fun bindOpenAiStt(impl: OpenAiSpeechRecognitionProvider): SpeechRecognitionProvider

    @Binds
    @IntoSet
    abstract fun bindGeminiStt(impl: GeminiSpeechRecognitionProvider): SpeechRecognitionProvider

    @Binds
    @IntoSet
    abstract fun bindOpenAiTts(impl: OpenAiTtsProvider): TextToSpeechProvider

    @Binds
    abstract fun bindRealtimeClient(impl: OpenAiRealtimeClient): RealtimeTranslationClient
}
