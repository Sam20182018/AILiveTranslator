package com.aitranslator.live.core.network.http

import com.aitranslator.live.core.common.Logger
import okhttp3.Interceptor
import okhttp3.Response
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Sits in front of OkHttp's logging interceptor.
 *
 * It does not modify the outgoing request — it only emits a redacted, key-free trace line
 * so that even with `HttpLoggingInterceptor` disabled we still get useful debug output and
 * never leak `Authorization` / `x-api-key` / `?key=` values.
 */
@Singleton
class RedactingInterceptor @Inject constructor() : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val started = System.nanoTime()

        Logger.d(TAG, "→ ${request.method} ${request.url.redactedUrl()}")

        val response = chain.proceed(request)
        val tookMs = (System.nanoTime() - started) / 1_000_000

        Logger.d(TAG, "← ${response.code} ${request.url.redactedUrl()} (${tookMs}ms)")
        return response
    }

    private fun okhttp3.HttpUrl.redactedUrl(): String {
        val sanitized = newBuilder().apply {
            queryParameterNames.forEach { name ->
                if (name.equals("key", ignoreCase = true) ||
                    name.equals("api_key", ignoreCase = true) ||
                    name.equals("access_token", ignoreCase = true)
                ) {
                    setQueryParameter(name, "REDACTED")
                }
            }
        }.build()
        return sanitized.toString()
    }

    private companion object {
        const val TAG = "Http"
    }
}
