package com.aitranslator.live.core.network.stt

import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.provider.SpeechRecognitionProvider
import com.aitranslator.live.core.network.ApiHosts
import com.aitranslator.live.core.network.api.OpenAiApi
import com.aitranslator.live.core.network.error.ErrorMapper
import com.aitranslator.live.core.network.provider.safeApiCall
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Cloud speech recognition via `/v1/audio/transcriptions`.
 *
 * Chosen as the default because on-device recognition is not guaranteed to be installed
 * for Persian, Arabic or Dutch, while Whisper-class models handle all six languages.
 */
@Singleton
class OpenAiSpeechRecognitionProvider @Inject constructor(
    private val api: OpenAiApi,
    private val errorMapper: ErrorMapper,
    private val hosts: ApiHosts,
) : SpeechRecognitionProvider {

    override val provider: AiProvider = AiProvider.OPENAI

    override suspend fun transcribe(
        wavAudio: ByteArray,
        language: Language,
        apiKey: String,
        model: String,
    ): AppResult<String> {
        val filePart = MultipartBody.Part.createFormData(
            "file",
            "speech.wav",
            wavAudio.toRequestBody(WAV_MEDIA_TYPE),
        )

        val response = safeApiCall(provider, errorMapper, model) {
            api.transcribe(
                url = hosts.openAiTranscriptions,
                authorization = "Bearer $apiKey",
                file = filePart,
                model = model.asPlainPart(),
                language = language.code.asPlainPart(),
                prompt = null,
                responseFormat = "json".asPlainPart(),
            )
        }

        return response.map { it.text.trim() }
    }

    private fun String.asPlainPart(): RequestBody = toRequestBody(PLAIN_MEDIA_TYPE)

    private companion object {
        val WAV_MEDIA_TYPE = "audio/wav".toMediaType()
        val PLAIN_MEDIA_TYPE = "text/plain".toMediaType()
    }
}
