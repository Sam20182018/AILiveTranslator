package com.aitranslator.live.core.network.tts

import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.AiModelConfig
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.SynthesizedAudio
import com.aitranslator.live.core.domain.model.TtsEngine
import com.aitranslator.live.core.domain.model.VoiceProfile
import com.aitranslator.live.core.domain.provider.SpeechSynthesis
import com.aitranslator.live.core.domain.provider.TextToSpeechProvider
import com.aitranslator.live.core.domain.repository.ApiKeyRepository
import com.aitranslator.live.core.network.ApiHosts
import com.aitranslator.live.core.network.api.OpenAiApi
import com.aitranslator.live.core.network.dto.OpenAiSpeechRequest
import com.aitranslator.live.core.network.error.ErrorMapper
import com.aitranslator.live.core.network.provider.safeStreamCall
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Cloud text-to-speech. Provides the 10 named voice profiles (5 male, 5 female) required
 * by the spec, with consistent quality across all six languages.
 *
 * Returns audio bytes rather than playing them, so the caller can both play and — when the
 * user enabled "Save audio" — persist the same buffer.
 */
@Singleton
class OpenAiTtsProvider @Inject constructor(
    private val api: OpenAiApi,
    private val errorMapper: ErrorMapper,
    private val apiKeyRepository: ApiKeyRepository,
    private val hosts: ApiHosts,
) : TextToSpeechProvider {

    override val engine: TtsEngine = TtsEngine.OPENAI

    override suspend fun availableVoices(): List<VoiceProfile> =
        if (apiKeyRepository.getKey(AiProvider.OPENAI).isNullOrBlank()) {
            emptyList()
        } else {
            VoiceProfile.OPENAI_VOICES
        }

    override suspend fun synthesize(
        text: String,
        language: Language,
        voice: VoiceProfile,
        speed: Float,
        volume: Float,
    ): AppResult<SpeechSynthesis> {
        val apiKey = apiKeyRepository.getKey(AiProvider.OPENAI)
        if (apiKey.isNullOrBlank()) {
            return AppResult.Failure(
                AppError.NotConfigured(AiProvider.OPENAI.id, "OpenAI key required for cloud TTS"),
            )
        }

        val model = AiModelConfig.defaultFor(AiProvider.OPENAI).speechModel
        val voiceId = voice.engineVoiceId.ifBlank { DEFAULT_VOICE }

        val result = safeStreamCall(AiProvider.OPENAI, errorMapper, model) {
            api.speech(
                url = hosts.openAiSpeech,
                authorization = "Bearer $apiKey",
                body = OpenAiSpeechRequest(
                    model = model,
                    input = text,
                    voice = voiceId,
                    speed = speed.coerceIn(MIN_SPEED, MAX_SPEED),
                    responseFormat = RESPONSE_FORMAT,
                ),
            )
        }

        return result.map { body ->
            val bytes = body.use { it.bytes() }
            SpeechSynthesis(
                audio = SynthesizedAudio(
                    bytes = bytes,
                    mimeType = "audio/mpeg",
                    fileExtension = "mp3",
                ),
                playedByEngine = false,
            )
        }
    }

    /** Nothing to stop: playback is owned by the caller's `AudioPlayer`. */
    override suspend fun stop() = Unit

    private companion object {
        const val DEFAULT_VOICE = "alloy"
        const val RESPONSE_FORMAT = "mp3"
        const val MIN_SPEED = 0.25f
        const val MAX_SPEED = 4.0f
    }
}
