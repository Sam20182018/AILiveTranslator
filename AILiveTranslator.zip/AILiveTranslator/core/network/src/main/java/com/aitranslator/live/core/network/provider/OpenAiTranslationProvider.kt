package com.aitranslator.live.core.network.provider

import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.TranslationChunk
import com.aitranslator.live.core.domain.model.TranslationRequest
import com.aitranslator.live.core.domain.model.TranslationResult
import com.aitranslator.live.core.domain.provider.AITranslationProvider
import com.aitranslator.live.core.domain.provider.TranslationStreamException
import com.aitranslator.live.core.network.ApiHosts
import com.aitranslator.live.core.network.api.OpenAiApi
import com.aitranslator.live.core.network.dto.OpenAiChatRequest
import com.aitranslator.live.core.network.dto.OpenAiMessage
import com.aitranslator.live.core.network.error.ErrorMapper
import com.aitranslator.live.core.network.http.sseEvents
import com.aitranslator.live.core.network.prompt.TranslationPrompt
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class OpenAiTranslationProvider @Inject constructor(
    private val api: OpenAiApi,
    private val errorMapper: ErrorMapper,
    private val json: Json,
    private val hosts: ApiHosts,
) : AITranslationProvider {

    override val provider: AiProvider = AiProvider.OPENAI

    override val supportsStreaming: Boolean = true

    override suspend fun translate(
        request: TranslationRequest,
        apiKey: String,
        model: String,
        maxOutputTokens: Int,
        temperature: Float,
    ): AppResult<TranslationResult> {
        val started = System.currentTimeMillis()

        val response = safeApiCall(provider, errorMapper, model) {
            api.chatCompletion(
                url = hosts.openAiChatCompletions,
                authorization = "Bearer $apiKey",
                body = OpenAiChatRequest(
                    model = model,
                    messages = listOf(
                        OpenAiMessage(
                            OpenAiMessage.ROLE_SYSTEM,
                            TranslationPrompt.systemInstruction(request),
                        ),
                        OpenAiMessage(OpenAiMessage.ROLE_USER, request.text),
                    ),
                    temperature = temperature,
                    maxTokens = maxOutputTokens,
                ),
            )
        }

        return response.flatMap { body ->
            val text = body.choices.firstOrNull()?.message?.content.orEmpty().cleanTranslationOutput()
            if (text.isBlank()) {
                AppResult.Failure(
                    AppError.Unknown("provider=openai model=$model returned no translation"),
                )
            } else {
                AppResult.Success(
                    TranslationResult(
                        originalText = request.text,
                        translatedText = text,
                        sourceLanguage = request.sourceLanguage,
                        targetLanguage = request.targetLanguage,
                        provider = provider,
                        model = body.model ?: model,
                        latencyMillis = System.currentTimeMillis() - started,
                    ),
                )
            }
        }
    }

    override fun translateStream(
        request: TranslationRequest,
        apiKey: String,
        model: String,
        maxOutputTokens: Int,
        temperature: Float,
    ): Flow<TranslationChunk> = flow {
        val streamResult = safeStreamCall(provider, errorMapper, model) {
            api.chatCompletionStream(
                url = hosts.openAiChatCompletions,
                authorization = "Bearer $apiKey",
                accept = SSE_ACCEPT,
                body = OpenAiChatRequest(
                    model = model,
                    messages = listOf(
                        OpenAiMessage(
                            OpenAiMessage.ROLE_SYSTEM,
                            TranslationPrompt.systemInstruction(request),
                        ),
                        OpenAiMessage(OpenAiMessage.ROLE_USER, request.text),
                    ),
                    temperature = temperature,
                    maxTokens = maxOutputTokens,
                    stream = true,
                ),
            )
        }

        val body = when (streamResult) {
            is AppResult.Failure -> throw TranslationStreamException(streamResult.error)
            is AppResult.Success -> streamResult.data
        }

        val accumulated = StringBuilder()
        body.sseEvents().collect { event ->
            if (event.data == "[DONE]") return@collect
            val delta = runCatching {
                json.decodeFromString(
                    com.aitranslator.live.core.network.dto.OpenAiChatResponse.serializer(),
                    event.data,
                ).choices.firstOrNull()?.delta?.content
            }.getOrNull()

            if (!delta.isNullOrEmpty()) {
                accumulated.append(delta)
                emit(TranslationChunk.Delta(delta))
            }
        }

        emit(TranslationChunk.Completed(accumulated.toString().cleanTranslationOutput()))
    }

    override suspend fun testConnection(apiKey: String, model: String): AppResult<Unit> {
        val response = safeApiCall(provider, errorMapper, model) {
            api.chatCompletion(
                url = hosts.openAiChatCompletions,
                authorization = "Bearer $apiKey",
                body = OpenAiChatRequest(
                    model = model,
                    messages = listOf(OpenAiMessage(OpenAiMessage.ROLE_USER, "ping")),
                    maxTokens = 5,
                    temperature = 0f,
                ),
            )
        }
        return response.map { }
    }
}
