package com.aitranslator.live.core.network.error

import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.domain.model.AiProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class ErrorMapperTest {

    private val mapper = ErrorMapper()

    @Test
    fun `unknown host is reported as no internet`() {
        val error = mapper.fromThrowable(UnknownHostException("api.openai.com"), AiProvider.OPENAI)
        assertTrue(error is AppError.NoInternet)
    }

    @Test
    fun `socket timeout is reported as a timeout`() {
        val error = mapper.fromThrowable(SocketTimeoutException(), AiProvider.CLAUDE)
        assertTrue(error is AppError.Timeout)
    }

    @Test
    fun `generic io failures fall back to no internet rather than unknown`() {
        val error = mapper.fromThrowable(IOException("stream reset"), AiProvider.GEMINI)
        assertTrue(error is AppError.NoInternet)
    }

    @Test
    fun `403 is an invalid key`() {
        val error = mapper.fromHttp(403, null, AiProvider.GEMINI)
        assertTrue(error is AppError.InvalidApiKey)
    }

    @Test
    fun `retry-after header is carried into the rate limit error`() {
        val error = mapper.fromHttp(429, null, AiProvider.OPENAI, retryAfterHeader = "12")
        assertEquals(12L, (error as AppError.RateLimited).retryAfterSeconds)
    }

    @Test
    fun `a 400 naming a missing model becomes model unavailable`() {
        val body = """{"error":{"message":"The model `gpt-9` does not exist"}}"""
        val error = mapper.fromHttp(400, body, AiProvider.OPENAI, model = "gpt-9")
        assertTrue(error is AppError.ModelUnavailable)
    }

    @Test
    fun `provider message is kept in the technical detail but not the type`() {
        val body = """{"error":{"message":"Service overloaded"}}"""
        val error = mapper.fromHttp(500, body, AiProvider.CLAUDE, model = "claude-x")
        assertTrue(error is AppError.ServerError)
        assertTrue(error.technicalDetail?.contains("Service overloaded") == true)
    }

    @Test
    fun `a non-json error body still produces a typed error`() {
        val error = mapper.fromHttp(502, "<html>bad gateway</html>", AiProvider.GEMINI)
        assertEquals(502, (error as AppError.ServerError).httpCode)
    }
}
