package com.aitranslator.live.core.network.provider

import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.TranslationChunk
import com.aitranslator.live.core.domain.model.TranslationRequest
import com.aitranslator.live.core.domain.provider.TranslationStreamException
import com.aitranslator.live.core.network.ApiHosts
import com.aitranslator.live.core.network.api.OpenAiApi
import com.aitranslator.live.core.network.error.ErrorMapper
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory

/**
 * No real key and no real network: the provider is pointed at a local MockWebServer via
 * the injectable [ApiHosts], which is exactly why that indirection exists.
 */
class OpenAiTranslationProviderTest {

    private lateinit var server: MockWebServer
    private lateinit var provider: OpenAiTranslationProvider

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    private val request = TranslationRequest(
        text = "سلام",
        sourceLanguage = Language.PERSIAN,
        targetLanguage = Language.ENGLISH,
    )

    @Before
    fun setUp() {
        server = MockWebServer()
        server.start()

        val retrofit = Retrofit.Builder()
            .baseUrl(server.url("/"))
            .client(OkHttpClient.Builder().build())
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()

        provider = OpenAiTranslationProvider(
            api = retrofit.create(OpenAiApi::class.java),
            errorMapper = ErrorMapper(),
            json = json,
            hosts = ApiHosts(openAiBase = server.url("/v1/").toString()),
        )
    }

    @After
    fun tearDown() {
        server.shutdown()
    }

    @Test
    fun `returns the translated text on success`() = runTest {
        server.enqueue(
            MockResponse()
                .setResponseCode(200)
                .setHeader("Content-Type", "application/json")
                .setBody(
                    """
                    {
                      "id": "chatcmpl-1",
                      "model": "gpt-4o-mini",
                      "choices": [
                        {"index":0,"message":{"role":"assistant","content":"Hello"},"finish_reason":"stop"}
                      ]
                    }
                    """.trimIndent(),
                ),
        )

        val result = provider.translate(request, "test-key", "gpt-4o-mini", 256, 0.2f)

        assertTrue(result is AppResult.Success)
        assertEquals("Hello", (result as AppResult.Success).data.translatedText)
    }

    @Test
    fun `sends the key as a bearer header and never in the url`() = runTest {
        server.enqueue(
            MockResponse()
                .setResponseCode(200)
                .setHeader("Content-Type", "application/json")
                .setBody("""{"choices":[{"message":{"role":"assistant","content":"Hello"}}]}"""),
        )

        provider.translate(request, "test-key", "gpt-4o-mini", 256, 0.2f)

        val recorded = server.takeRequest()
        assertEquals("Bearer test-key", recorded.getHeader("Authorization"))
        assertTrue(recorded.path.orEmpty().none { it == '?' })
    }

    @Test
    fun `maps 401 to an invalid key error`() = runTest {
        server.enqueue(
            MockResponse()
                .setResponseCode(401)
                .setBody("""{"error":{"message":"Incorrect API key provided"}}"""),
        )

        val result = provider.translate(request, "wrong", "gpt-4o-mini", 256, 0.2f)

        assertTrue(result is AppResult.Failure)
        assertTrue((result as AppResult.Failure).error is AppError.InvalidApiKey)
    }

    @Test
    fun `maps 429 to a rate limit error`() = runTest {
        server.enqueue(
            MockResponse()
                .setResponseCode(429)
                .setHeader("retry-after", "30")
                .setBody("""{"error":{"message":"Rate limit reached"}}"""),
        )

        val result = provider.translate(request, "test-key", "gpt-4o-mini", 256, 0.2f)

        val error = (result as AppResult.Failure).error
        assertTrue(error is AppError.RateLimited)
        assertEquals(30L, (error as AppError.RateLimited).retryAfterSeconds)
    }

    @Test
    fun `maps 500 to a server error`() = runTest {
        server.enqueue(MockResponse().setResponseCode(503).setBody("upstream unavailable"))

        val result = provider.translate(request, "test-key", "gpt-4o-mini", 256, 0.2f)

        assertTrue((result as AppResult.Failure).error is AppError.ServerError)
    }

    @Test
    fun `parses streaming deltas and completes with the joined text`() = runTest {
        val sse = buildString {
            append("data: {\"choices\":[{\"delta\":{\"content\":\"Hel\"}}]}\n\n")
            append("data: {\"choices\":[{\"delta\":{\"content\":\"lo\"}}]}\n\n")
            append("data: [DONE]\n\n")
        }

        server.enqueue(
            MockResponse()
                .setResponseCode(200)
                .setHeader("Content-Type", "text/event-stream")
                .setBody(sse),
        )

        val chunks = provider
            .translateStream(request, "test-key", "gpt-4o-mini", 256, 0.2f)
            .toList()

        assertEquals(
            listOf("Hel", "lo"),
            chunks.filterIsInstance<TranslationChunk.Delta>().map { it.text },
        )
        assertEquals(
            "Hello",
            chunks.filterIsInstance<TranslationChunk.Completed>().single().fullText,
        )
    }

    @Test
    fun `streaming failure surfaces as a typed stream exception`() = runTest {
        server.enqueue(
            MockResponse()
                .setResponseCode(401)
                .setBody("""{"error":{"message":"bad key"}}"""),
        )

        val thrown = runCatching {
            provider.translateStream(request, "bad", "gpt-4o-mini", 256, 0.2f).toList()
        }.exceptionOrNull()

        assertTrue(thrown is TranslationStreamException)
        assertTrue((thrown as TranslationStreamException).appError is AppError.InvalidApiKey)
    }

    @Test
    fun `strips a quoted or prefixed model answer`() = runTest {
        server.enqueue(
            MockResponse()
                .setResponseCode(200)
                .setHeader("Content-Type", "application/json")
                .setBody(
                    """{"choices":[{"message":{"content":"Translation: \"Hello there\""}}]}""",
                ),
        )

        val result = provider.translate(request, "test-key", "gpt-4o-mini", 256, 0.2f)

        assertEquals("Hello there", (result as AppResult.Success).data.translatedText)
    }
}
