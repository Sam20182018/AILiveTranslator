package com.aitranslator.live.core.audio.vad

import com.aitranslator.live.core.domain.audio.AudioFormatSpec
import com.aitranslator.live.core.domain.audio.AudioFrame
import com.aitranslator.live.core.domain.audio.VadDecision
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The VAD is what keeps the API bill down, so its boundaries are worth pinning: silence
 * must never open a segment, a click must not open one either, and a natural pause must
 * close one.
 */
class EnergyVoiceActivityDetectorTest {

    private fun frame(rms: Float, index: Int) = AudioFrame(
        pcm = ByteArray(AudioFormatSpec.FRAME_BYTES),
        rms = rms,
        timestampMillis = index * AudioFormatSpec.FRAME_MILLIS.toLong(),
    )

    @Test
    fun `silence never starts a segment`() {
        val detector = EnergyVoiceActivityDetector()

        val decisions = (0 until 100).map { detector.accept(frame(0.001f, it)) }

        assertTrue(decisions.all { it == VadDecision.SILENCE })
    }

    @Test
    fun `a short click does not start a segment`() {
        val detector = EnergyVoiceActivityDetector(minSpeechMillis = 250L)

        // 250 ms is 12.5 frames; five loud frames is 100 ms — below the guard.
        val decisions = (0 until 5).map { detector.accept(frame(0.6f, it)) }

        assertTrue(decisions.none { it == VadDecision.SPEECH_START })
    }

    @Test
    fun `sustained speech opens a segment exactly once`() {
        val detector = EnergyVoiceActivityDetector(minSpeechMillis = 100L)

        val decisions = (0 until 20).map { detector.accept(frame(0.6f, it)) }

        assertEquals(1, decisions.count { it == VadDecision.SPEECH_START })
    }

    @Test
    fun `a pause closes the segment after the configured silence`() {
        val detector = EnergyVoiceActivityDetector(
            silenceMillis = 200L,
            minSpeechMillis = 100L,
        )

        repeat(20) { detector.accept(frame(0.6f, it)) }

        // 200 ms of silence is 10 frames of 20 ms.
        val tail = (0 until 12).map { detector.accept(frame(0.001f, 20 + it)) }

        assertTrue(tail.contains(VadDecision.SPEECH_END))
    }

    @Test
    fun `a long monologue is split at the maximum segment length`() {
        val detector = EnergyVoiceActivityDetector(
            silenceMillis = 5_000L,
            minSpeechMillis = 100L,
            maxSegmentMillis = 400L,
        )

        val decisions = (0 until 60).map { detector.accept(frame(0.6f, it)) }

        assertTrue(decisions.count { it == VadDecision.SPEECH_END } >= 1)
    }

    @Test
    fun `the threshold adapts upward in a noisy room`() {
        val detector = EnergyVoiceActivityDetector()
        val quietThreshold = detector.currentThreshold()

        // Deliberately below the activation threshold: only quiet frames move the floor.
        repeat(200) { detector.accept(frame(0.02f, it)) }

        assertTrue(detector.currentThreshold() > quietThreshold)
    }
}
