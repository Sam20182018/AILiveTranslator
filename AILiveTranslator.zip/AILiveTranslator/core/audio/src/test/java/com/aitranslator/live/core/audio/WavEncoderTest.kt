package com.aitranslator.live.core.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.ByteBuffer
import java.nio.ByteOrder

class WavEncoderTest {

    @Test
    fun `writes a valid 44 byte RIFF header`() {
        val pcm = ByteArray(1600) { 0 }

        val wav = WavEncoder.encode(pcm, sampleRate = 16_000, channels = 1, bitsPerSample = 16)

        assertEquals(44 + pcm.size, wav.size)
        assertEquals("RIFF", String(wav.copyOfRange(0, 4), Charsets.US_ASCII))
        assertEquals("WAVE", String(wav.copyOfRange(8, 12), Charsets.US_ASCII))
        assertEquals("fmt ", String(wav.copyOfRange(12, 16), Charsets.US_ASCII))
        assertEquals("data", String(wav.copyOfRange(36, 40), Charsets.US_ASCII))

        val buffer = ByteBuffer.wrap(wav).order(ByteOrder.LITTLE_ENDIAN)
        assertEquals(16, buffer.getInt(16))                 // PCM subchunk size
        assertEquals(1.toShort(), buffer.getShort(20))      // format = PCM
        assertEquals(1.toShort(), buffer.getShort(22))      // channels
        assertEquals(16_000, buffer.getInt(24))             // sample rate
        assertEquals(32_000, buffer.getInt(28))             // byte rate
        assertEquals(pcm.size, buffer.getInt(40))           // data size
    }

    @Test
    fun `rms of pure silence is zero`() {
        assertEquals(0f, WavEncoder.rms(ByteArray(640)), 0.0001f)
    }

    @Test
    fun `rms of a full scale square wave approaches one`() {
        val pcm = ByteArray(640)
        var index = 0
        while (index + 1 < pcm.size) {
            // 0x7FFF little-endian = maximum positive 16-bit sample
            pcm[index] = 0xFF.toByte()
            pcm[index + 1] = 0x7F
            index += 2
        }

        assertTrue(WavEncoder.rms(pcm) > 0.99f)
    }

    @Test
    fun `resampling 16k to 24k grows the buffer by half`() {
        val pcm = ByteArray(3_200) // 100 ms at 16 kHz

        val resampled = WavEncoder.resamplePcm16(pcm, fromRate = 16_000, toRate = 24_000)

        assertEquals(4_800, resampled.size)
    }

    @Test
    fun `resampling to the same rate returns the input untouched`() {
        val pcm = ByteArray(64) { it.toByte() }

        assertTrue(WavEncoder.resamplePcm16(pcm, 16_000, 16_000).contentEquals(pcm))
    }
}
