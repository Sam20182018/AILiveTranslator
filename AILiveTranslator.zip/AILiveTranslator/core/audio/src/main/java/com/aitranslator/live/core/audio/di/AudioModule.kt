package com.aitranslator.live.core.audio.di

import com.aitranslator.live.core.audio.live.DefaultLiveEngineSelector
import com.aitranslator.live.core.audio.player.MediaPlayerAudioPlayer
import com.aitranslator.live.core.audio.recorder.PcmAudioRecorder
import com.aitranslator.live.core.audio.tts.AndroidTextToSpeechProvider
import com.aitranslator.live.core.domain.audio.AudioPlayer
import com.aitranslator.live.core.domain.audio.AudioRecorder
import com.aitranslator.live.core.domain.live.LiveTranslationEngineSelector
import com.aitranslator.live.core.domain.provider.TextToSpeechProvider
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoSet
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class AudioModule {

    @Binds
    @Singleton
    abstract fun bindAudioRecorder(impl: PcmAudioRecorder): AudioRecorder

    @Binds
    @Singleton
    abstract fun bindAudioPlayer(impl: MediaPlayerAudioPlayer): AudioPlayer

    @Binds
    @Singleton
    abstract fun bindLiveEngineSelector(
        impl: DefaultLiveEngineSelector,
    ): LiveTranslationEngineSelector

    /**
     * Joins the same multibinding set as the cloud TTS provider, so the router in
     * `:core:data` sees both engines without either module knowing about the other.
     */
    @Binds
    @IntoSet
    abstract fun bindAndroidTts(impl: AndroidTextToSpeechProvider): TextToSpeechProvider
}
