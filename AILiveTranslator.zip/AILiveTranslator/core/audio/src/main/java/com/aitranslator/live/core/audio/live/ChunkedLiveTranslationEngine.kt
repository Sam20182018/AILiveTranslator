package com.aitranslator.live.core.audio.live

import com.aitranslator.live.core.audio.WavEncoder
import com.aitranslator.live.core.audio.vad.EnergyVoiceActivityDetector
import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.common.Logger
import com.aitranslator.live.core.domain.audio.AudioCaptureException
import com.aitranslator.live.core.domain.audio.AudioFormatSpec
import com.aitranslator.live.core.domain.audio.AudioRecorder
import com.aitranslator.live.core.domain.audio.VadDecision
import com.aitranslator.live.core.domain.live.LiveSessionConfig
import com.aitranslator.live.core.domain.live.LiveTranslationEngine
import com.aitranslator.live.core.domain.model.LiveEvent
import com.aitranslator.live.core.domain.model.PipelineState
import com.aitranslator.live.core.domain.model.TranslationChunk
import com.aitranslator.live.core.domain.model.TranslationRequest
import com.aitranslator.live.core.domain.model.TranslationResult
import com.aitranslator.live.core.domain.provider.TranslationStreamException
import com.aitranslator.live.core.domain.repository.SettingsRepository
import com.aitranslator.live.core.domain.repository.SpeechRepository
import com.aitranslator.live.core.domain.repository.TranslationRepository
import kotlinx.coroutines.channels.ProducerScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.catch
import java.io.ByteArrayOutputStream
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The provider-agnostic live pipeline:
 *
 * `mic → VAD → WAV → STT → streaming translation → TTS`
 *
 * Everything runs sequentially per utterance on purpose. Firing overlapping requests would
 * produce out-of-order subtitles and multiply the API bill without making anything feel
 * faster, because the bottleneck is the speech API round trip.
 *
 * While the translation is being spoken the microphone input is ignored (half-duplex gate)
 * so the app never transcribes its own output.
 */
@Singleton
class ChunkedLiveTranslationEngine @Inject constructor(
    private val audioRecorder: AudioRecorder,
    private val speechRepository: SpeechRepository,
    private val translationRepository: TranslationRepository,
    private val settingsRepository: SettingsRepository,
) : LiveTranslationEngine {

    override val id: String = ENGINE_ID

    /** Works with every provider, so it is always supported. */
    override suspend fun isSupported(config: LiveSessionConfig): Boolean = true

    override fun run(config: LiveSessionConfig): Flow<LiveEvent> = channelFlow {
        val detector = EnergyVoiceActivityDetector(
            silenceMillis = config.latencyProfile.silenceMillis,
            maxSegmentMillis = config.latencyProfile.maxSegmentMillis,
        )

        val buffer = ByteArrayOutputStream()
        var framesSinceAmplitude = 0
        var muted = false
        var lastTranscript = ""

        send(LiveEvent.StateChanged(PipelineState.Listening()))

        audioRecorder.frames()
            .catch { throwable ->
                val error = (throwable as? AudioCaptureException)?.appError
                    ?: AppError.AudioCapture(throwable.message)
                send(LiveEvent.Failed(error))
                send(LiveEvent.StateChanged(PipelineState.Error(error)))
            }
            .collect { frame ->
                if (muted) return@collect

                when (detector.accept(frame)) {
                    VadDecision.SPEECH_START -> {
                        buffer.reset()
                        buffer.write(frame.pcm)
                    }

                    VadDecision.SPEECH -> buffer.write(frame.pcm)

                    VadDecision.SPEECH_END -> {
                        buffer.write(frame.pcm)
                        val pcm = buffer.toByteArray()
                        buffer.reset()

                        val durationMs = pcm.size.toLong() * 1000 /
                            (AudioFormatSpec.SAMPLE_RATE_HZ * AudioFormatSpec.BYTES_PER_SAMPLE)

                        if (durationMs < MIN_UTTERANCE_MILLIS) {
                            Logger.d(TAG, "dropping ${durationMs}ms segment — too short")
                            return@collect
                        }

                        muted = true
                        val transcript = processSegment(pcm, config, lastTranscript)
                        if (transcript != null) lastTranscript = transcript
                        muted = false
                        detector.reset()
                        send(LiveEvent.StateChanged(PipelineState.Listening()))
                    }

                    VadDecision.SILENCE -> Unit
                }

                framesSinceAmplitude++
                if (framesSinceAmplitude >= AMPLITUDE_EVERY_N_FRAMES) {
                    framesSinceAmplitude = 0
                    send(LiveEvent.StateChanged(PipelineState.Listening(frame.rms)))
                }
            }
    }

    /** @return the recognised transcript, or `null` when the segment produced nothing usable. */
    private suspend fun ProducerScope<LiveEvent>.processSegment(
        pcm: ByteArray,
        config: LiveSessionConfig,
        previousTranscript: String,
    ): String? {
        send(LiveEvent.StateChanged(PipelineState.Processing))

        val wav = WavEncoder.encode(pcm)
        val transcript = when (val stt = speechRepository.transcribe(wav, config.sourceLanguage)) {
            is AppResult.Failure -> {
                send(LiveEvent.Failed(stt.error))
                return null
            }

            is AppResult.Success -> stt.data.trim()
        }

        if (transcript.isBlank()) return null

        // Repeat suppression: speech recognisers frequently return the same short phrase for
        // background noise, and re-translating it would cost money for no benefit.
        if (transcript.equals(previousTranscript, ignoreCase = true)) {
            Logger.d(TAG, "skipping repeated transcript")
            return transcript
        }

        send(LiveEvent.FinalTranscript(transcript))
        send(LiveEvent.StateChanged(PipelineState.Translating))

        val request = TranslationRequest(
            text = transcript,
            sourceLanguage = config.sourceLanguage,
            targetLanguage = config.targetLanguage,
            mode = config.mode,
        )

        var finalText: String? = null
        val builder = StringBuilder()

        try {
            translationRepository.translateStreaming(request).collect { chunk ->
                when (chunk) {
                    is TranslationChunk.Delta -> {
                        builder.append(chunk.text)
                        send(LiveEvent.PartialTranslation(builder.toString()))
                    }

                    is TranslationChunk.Completed -> finalText = chunk.fullText
                }
            }
        } catch (streamError: TranslationStreamException) {
            send(LiveEvent.Failed(streamError.appError))
            return transcript
        }

        val translated = finalText?.takeIf { it.isNotBlank() } ?: builder.toString()
        if (translated.isBlank()) return transcript

        val settings = settingsRepository.current()
        val provider = translationRepository.resolveProvider().getOrNull()
            ?: com.aitranslator.live.core.domain.model.AiProvider.AUTO

        send(
            LiveEvent.FinalTranslation(
                TranslationResult(
                    originalText = transcript,
                    translatedText = translated,
                    sourceLanguage = config.sourceLanguage,
                    targetLanguage = config.targetLanguage,
                    provider = provider,
                    model = settings.modelFor(provider),
                    latencyMillis = 0L,
                ),
            ),
        )

        if (config.autoSpeak && settings.voiceTranslationEnabled) {
            send(LiveEvent.StateChanged(PipelineState.Speaking))
            speechRepository.speak(translated, config.targetLanguage, persistAudio = false)
        }

        return transcript
    }

    private companion object {
        const val ENGINE_ID = "chunked"
        const val TAG = "ChunkedLive"
        const val MIN_UTTERANCE_MILLIS = 400L
        const val AMPLITUDE_EVERY_N_FRAMES = 5
    }
}
