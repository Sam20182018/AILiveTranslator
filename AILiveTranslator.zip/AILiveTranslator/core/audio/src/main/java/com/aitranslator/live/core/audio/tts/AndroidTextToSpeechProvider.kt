package com.aitranslator.live.core.audio.tts

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.common.Logger
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.TtsEngine
import com.aitranslator.live.core.domain.model.VoiceGender
import com.aitranslator.live.core.domain.model.VoiceProfile
import com.aitranslator.live.core.domain.provider.SpeechSynthesis
import com.aitranslator.live.core.domain.provider.TextToSpeechProvider
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicReference
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume

/**
 * On-device text-to-speech.
 *
 * Always available (no key, no network), so it is the fallback whenever cloud TTS is not
 * configured. Voice quality and the set of installed languages vary by device, which is
 * why the cloud voices exist alongside it rather than instead of it.
 */
@Singleton
class AndroidTextToSpeechProvider @Inject constructor(
    @ApplicationContext private val context: Context,
) : TextToSpeechProvider {

    override val engine: TtsEngine = TtsEngine.ANDROID

    private val initMutex = Mutex()
    private val pending = ConcurrentHashMap<String, (Boolean) -> Unit>()

    @Volatile
    private var tts: TextToSpeech? = null

    override suspend fun availableVoices(): List<VoiceProfile> {
        val engineInstance = ensureReady() ?: return listOf(VoiceProfile.DEVICE_DEFAULT)

        val deviceVoices = runCatching { engineInstance.voices }.getOrNull().orEmpty()
            .asSequence()
            .mapNotNull { voice -> voice.toProfile() }
            .sortedBy { it.displayName }
            .toList()

        return listOf(VoiceProfile.DEVICE_DEFAULT) + deviceVoices
    }

    override suspend fun synthesize(
        text: String,
        language: Language,
        voice: VoiceProfile,
        speed: Float,
        volume: Float,
    ): AppResult<SpeechSynthesis> {
        if (text.isBlank()) return AppResult.Success(SpeechSynthesis(null, playedByEngine = true))

        val engineInstance = ensureReady()
            ?: return AppResult.Failure(
                AppError.CapabilityUnavailable("android_tts", "no text-to-speech engine installed"),
            )

        val localeResult = runCatching {
            engineInstance.setLanguage(Locale.forLanguageTag(language.bcp47))
        }.getOrDefault(TextToSpeech.LANG_NOT_SUPPORTED)

        if (localeResult == TextToSpeech.LANG_MISSING_DATA ||
            localeResult == TextToSpeech.LANG_NOT_SUPPORTED
        ) {
            return AppResult.Failure(
                AppError.UnsupportedLanguage(
                    language.code,
                    "device TTS has no voice data for ${language.bcp47}",
                ),
            )
        }

        if (voice.engine == TtsEngine.ANDROID && voice.engineVoiceId.isNotBlank()) {
            runCatching {
                engineInstance.voices
                    ?.firstOrNull { it.name == voice.engineVoiceId }
                    ?.let(engineInstance::setVoice)
            }
        }

        engineInstance.setSpeechRate(speed.coerceIn(MIN_RATE, MAX_RATE))

        val utteranceId = "utt_${System.nanoTime()}"
        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.coerceIn(0f, 1f))
        }

        val spoken = suspendCancellableCoroutine { continuation ->
            pending[utteranceId] = { success ->
                if (continuation.isActive) continuation.resume(success)
            }

            val queued = engineInstance.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
            if (queued != TextToSpeech.SUCCESS) {
                pending.remove(utteranceId)
                if (continuation.isActive) continuation.resume(false)
            }

            continuation.invokeOnCancellation {
                pending.remove(utteranceId)
                runCatching { engineInstance.stop() }
            }
        }

        return if (spoken) {
            AppResult.Success(SpeechSynthesis(audio = null, playedByEngine = true))
        } else {
            AppResult.Failure(AppError.AudioPlayback("device TTS failed to speak"))
        }
    }

    override suspend fun stop() {
        runCatching { tts?.stop() }
        pending.keys.toList().forEach { key -> pending.remove(key)?.invoke(false) }
    }

    fun shutdown() {
        runCatching { tts?.shutdown() }
        tts = null
    }

    private suspend fun ensureReady(): TextToSpeech? {
        tts?.let { return it }

        return initMutex.withLock {
            tts?.let { return@withLock it }

            // The instance must be published before the init callback is consumed, so it is
            // held in a reference that is written inside the (fully executed) suspend block.
            val engineRef = AtomicReference<TextToSpeech?>(null)
            val status = suspendCancellableCoroutine { continuation ->
                val instance = TextToSpeech(context) { initStatus ->
                    if (continuation.isActive) continuation.resume(initStatus)
                }
                engineRef.set(instance)
                continuation.invokeOnCancellation { runCatching { instance.shutdown() } }
            }

            val created = if (status == TextToSpeech.SUCCESS) {
                engineRef.get()
            } else {
                Logger.w(TAG, "device TTS init failed with status=$status")
                runCatching { engineRef.get()?.shutdown() }
                null
            }

            created?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit

                override fun onDone(utteranceId: String?) {
                    utteranceId?.let { pending.remove(it)?.invoke(true) }
                }

                @Deprecated("Kept for API < 21 compatibility of the abstract class")
                override fun onError(utteranceId: String?) {
                    utteranceId?.let { pending.remove(it)?.invoke(false) }
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    Logger.w(TAG, "device TTS error code=$errorCode")
                    utteranceId?.let { pending.remove(it)?.invoke(false) }
                }
            })

            tts = created
            created
        }
    }

    /**
     * Android voice names are engine-specific (e.g. `fa-ir-x-fad-local`,
     * `de-DE-language#male`). There is no gender field in the API, so the name and the
     * feature set are the only signals available.
     */
    private fun Voice.toProfile(): VoiceProfile? {
        val language = Language.fromCode(locale?.language) ?: return null
        val lowered = name.lowercase()
        val gender = when {
            lowered.contains("female") || lowered.contains("#f") -> VoiceGender.FEMALE
            lowered.contains("male") || lowered.contains("#m") -> VoiceGender.MALE
            else -> VoiceGender.NEUTRAL
        }

        return VoiceProfile(
            id = "android:$name",
            displayName = "${language.nativeName} · $name",
            gender = gender,
            engine = TtsEngine.ANDROID,
            engineVoiceId = name,
            languages = setOf(language),
            description = if (isNetworkConnectionRequired) "Requires network" else "On-device",
        )
    }

    private companion object {
        const val TAG = "AndroidTts"
        const val MIN_RATE = 0.1f
        const val MAX_RATE = 3.0f
    }
}
