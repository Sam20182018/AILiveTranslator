package com.aitranslator.live.core.audio.live

import com.aitranslator.live.core.audio.WavEncoder
import com.aitranslator.live.core.audio.player.PcmStreamPlayer
import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.Logger
import com.aitranslator.live.core.domain.audio.AudioCaptureException
import com.aitranslator.live.core.domain.audio.AudioFormatSpec
import com.aitranslator.live.core.domain.audio.AudioRecorder
import com.aitranslator.live.core.domain.live.LiveSessionConfig
import com.aitranslator.live.core.domain.live.LiveTranslationEngine
import com.aitranslator.live.core.domain.live.RealtimeAudioSpec
import com.aitranslator.live.core.domain.live.RealtimeConfig
import com.aitranslator.live.core.domain.live.RealtimeSignal
import com.aitranslator.live.core.domain.live.RealtimeTranslationClient
import com.aitranslator.live.core.domain.model.LiveEvent
import com.aitranslator.live.core.domain.model.PipelineState
import com.aitranslator.live.core.domain.model.TranslationResult
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.VoiceProfile
import com.aitranslator.live.core.domain.repository.SettingsRepository
import com.aitranslator.live.core.domain.repository.SpeechRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Lowest-latency live engine: a duplex WebSocket session.
 *
 * Instead of waiting for an utterance to end before uploading it, microphone frames stream
 * up continuously and translated audio streams back down, so the listener hears the
 * translation while the speaker is still talking.
 *
 * Only selected when the transport is actually available (an OpenAI key is configured);
 * otherwise the selector falls back to [ChunkedLiveTranslationEngine], which works with
 * every provider.
 */
@Singleton
class RealtimeLiveTranslationEngine @Inject constructor(
    private val audioRecorder: AudioRecorder,
    private val realtimeClient: RealtimeTranslationClient,
    private val settingsRepository: SettingsRepository,
    private val speechRepository: SpeechRepository,
    private val pcmStreamPlayer: PcmStreamPlayer,
) : LiveTranslationEngine {

    override val id: String = ENGINE_ID

    override suspend fun isSupported(config: LiveSessionConfig): Boolean =
        realtimeClient.isAvailable()

    override fun run(config: LiveSessionConfig): Flow<LiveEvent> = channelFlow {
        val settings = settingsRepository.current()
        val speakOutput = config.autoSpeak && settings.voiceTranslationEnabled

        val voice = speechRepository.selectedVoice()
            .takeIf { it.engine == com.aitranslator.live.core.domain.model.TtsEngine.OPENAI }
            ?: VoiceProfile.OPENAI_FEMALE.first()

        val realtimeConfig = RealtimeConfig(
            instructions = buildInstructions(config),
            voice = voice.engineVoiceId,
            wantAudioOutput = speakOutput,
        )

        // 16 kHz capture is resampled to the 24 kHz the transport expects.
        val uplink = audioRecorder.frames()
            .map { frame ->
                WavEncoder.resamplePcm16(
                    frame.pcm,
                    AudioFormatSpec.SAMPLE_RATE_HZ,
                    RealtimeAudioSpec.SAMPLE_RATE_HZ,
                )
            }
            .catch { throwable ->
                val error = (throwable as? AudioCaptureException)?.appError
                    ?: AppError.AudioCapture(throwable.message)
                Logger.w(TAG, "capture failed: $error")
                throw throwable
            }
            .flowOn(Dispatchers.IO)

        if (speakOutput) {
            pcmStreamPlayer.start(settings.speechVolume)
        }

        send(LiveEvent.StateChanged(PipelineState.Listening()))

        val partial = StringBuilder()
        var lastTranscript = ""

        try {
            realtimeClient.connect(realtimeConfig, uplink).collect { signal ->
                when (signal) {
                    is RealtimeSignal.Connected ->
                        send(LiveEvent.StateChanged(PipelineState.Listening()))

                    is RealtimeSignal.SpeechStarted ->
                        send(LiveEvent.StateChanged(PipelineState.Listening(SPEAKING_AMPLITUDE)))

                    is RealtimeSignal.SpeechStopped ->
                        send(LiveEvent.StateChanged(PipelineState.Processing))

                    is RealtimeSignal.InputTranscript -> {
                        lastTranscript = signal.text
                        send(LiveEvent.FinalTranscript(signal.text))
                        send(LiveEvent.StateChanged(PipelineState.Translating))
                    }

                    is RealtimeSignal.OutputTextDelta -> {
                        partial.append(signal.text)
                        send(LiveEvent.PartialTranslation(partial.toString()))
                    }

                    is RealtimeSignal.OutputTextDone -> {
                        val text = signal.text.ifBlank { partial.toString() }
                        partial.setLength(0)
                        if (text.isNotBlank()) {
                            send(
                                LiveEvent.FinalTranslation(
                                    TranslationResult(
                                        originalText = lastTranscript,
                                        translatedText = text,
                                        sourceLanguage = config.sourceLanguage,
                                        targetLanguage = config.targetLanguage,
                                        provider = AiProvider.OPENAI,
                                        model = REALTIME_MODEL_LABEL,
                                        latencyMillis = 0L,
                                    ),
                                ),
                            )
                        }
                    }

                    is RealtimeSignal.OutputAudioDelta -> {
                        if (speakOutput) {
                            send(LiveEvent.StateChanged(PipelineState.Speaking))
                            withContext(Dispatchers.IO) { pcmStreamPlayer.write(signal.pcm) }
                        }
                    }

                    is RealtimeSignal.ResponseCompleted ->
                        send(LiveEvent.StateChanged(PipelineState.Listening()))

                    is RealtimeSignal.Failed -> {
                        send(LiveEvent.Failed(signal.error))
                        send(LiveEvent.StateChanged(PipelineState.Error(signal.error)))
                    }

                    is RealtimeSignal.Closed ->
                        send(LiveEvent.StateChanged(PipelineState.Stopped))
                }
            }
        } finally {
            pcmStreamPlayer.stop()
        }
    }

    private fun buildInstructions(config: LiveSessionConfig): String = buildString {
        append("You are a simultaneous interpreter. ")
        append("Listen to speech in ${config.sourceLanguage.englishName} and immediately ")
        append("respond with the ${config.targetLanguage.englishName} translation only. ")
        append("Never answer the speaker, never add commentary, never explain. ")
        append("Speak the translation naturally, matching the speaker's tone and register. ")
        append("If the audio contains no intelligible speech, stay silent.")
    }

    private companion object {
        const val ENGINE_ID = "realtime"
        const val TAG = "RealtimeLive"
        const val SPEAKING_AMPLITUDE = 0.6f
        const val REALTIME_MODEL_LABEL = "realtime"
    }
}
