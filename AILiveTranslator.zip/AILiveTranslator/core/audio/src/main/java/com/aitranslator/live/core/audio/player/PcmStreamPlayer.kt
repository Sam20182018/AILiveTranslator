package com.aitranslator.live.core.audio.player

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import com.aitranslator.live.core.common.Logger
import com.aitranslator.live.core.domain.live.RealtimeAudioSpec
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Streams PCM chunks straight to the speaker with [AudioTrack].
 *
 * Used by the realtime engine: audio deltas arrive while the response is still being
 * generated, so buffering them into a file and handing them to `MediaPlayer` would throw
 * away the latency advantage the WebSocket bought us.
 */
@Singleton
class PcmStreamPlayer @Inject constructor() {

    private var track: AudioTrack? = null

    @Volatile
    private var open = false

    val isPlaying: Boolean get() = open

    @Synchronized
    fun start(volume: Float) {
        if (open) return

        val minBuffer = AudioTrack.getMinBufferSize(
            RealtimeAudioSpec.SAMPLE_RATE_HZ,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
        )
        val bufferSize = if (minBuffer > 0) minBuffer * 2 else RealtimeAudioSpec.CHUNK_BYTES * 8

        val audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build(),
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RealtimeAudioSpec.SAMPLE_RATE_HZ)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build(),
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        val clamped = volume.coerceIn(0f, 1f)
        runCatching { audioTrack.setVolume(clamped) }
        audioTrack.play()

        track = audioTrack
        open = true
        Logger.d(TAG, "AudioTrack started, buffer=$bufferSize")
    }

    /** Blocking write; call from an IO dispatcher. */
    fun write(pcm: ByteArray) {
        val audioTrack = track ?: return
        if (!open || pcm.isEmpty()) return
        runCatching { audioTrack.write(pcm, 0, pcm.size, AudioTrack.WRITE_BLOCKING) }
    }

    @Synchronized
    fun stop() {
        val audioTrack = track ?: return
        open = false
        runCatching { audioTrack.pause() }
        runCatching { audioTrack.flush() }
        runCatching { audioTrack.stop() }
        runCatching { audioTrack.release() }
        track = null
    }

    private companion object {
        const val TAG = "PcmStreamPlayer"
        @Suppress("unused")
        const val LEGACY_STREAM = AudioManager.STREAM_MUSIC
    }
}
