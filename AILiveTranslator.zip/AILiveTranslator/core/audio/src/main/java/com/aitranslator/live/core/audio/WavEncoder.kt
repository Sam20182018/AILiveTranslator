package com.aitranslator.live.core.audio

import com.aitranslator.live.core.domain.audio.AudioFormatSpec
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Wraps raw PCM in a RIFF/WAVE container.
 *
 * Speech APIs accept several formats but all of them accept 16-bit PCM WAV, and building
 * the 44-byte header ourselves avoids pulling in an encoder just to upload a few seconds
 * of audio.
 */
object WavEncoder {

    private const val HEADER_SIZE = 44

    fun encode(
        pcm: ByteArray,
        sampleRate: Int = AudioFormatSpec.SAMPLE_RATE_HZ,
        channels: Int = AudioFormatSpec.CHANNELS,
        bitsPerSample: Int = AudioFormatSpec.BITS_PER_SAMPLE,
    ): ByteArray {
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val blockAlign = channels * bitsPerSample / 8

        val header = ByteBuffer.allocate(HEADER_SIZE).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(36 + pcm.size)
            put("WAVE".toByteArray(Charsets.US_ASCII))

            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16)                          // PCM subchunk size
            putShort(1)                         // audio format: 1 = PCM
            putShort(channels.toShort())
            putInt(sampleRate)
            putInt(byteRate)
            putShort(blockAlign.toShort())
            putShort(bitsPerSample.toShort())

            put("data".toByteArray(Charsets.US_ASCII))
            putInt(pcm.size)
        }

        val out = ByteArrayOutputStream(HEADER_SIZE + pcm.size)
        out.write(header.array())
        out.write(pcm)
        return out.toByteArray()
    }

    /** Root-mean-square loudness of a 16-bit little-endian PCM buffer, normalised to 0..1. */
    fun rms(pcm: ByteArray): Float {
        if (pcm.size < 2) return 0f
        var sumSquares = 0.0
        var sampleCount = 0
        var index = 0
        while (index + 1 < pcm.size) {
            val sample = ((pcm[index + 1].toInt() shl 8) or (pcm[index].toInt() and 0xFF)).toShort()
            val normalized = sample.toDouble() / Short.MAX_VALUE
            sumSquares += normalized * normalized
            sampleCount++
            index += 2
        }
        if (sampleCount == 0) return 0f
        return kotlin.math.sqrt(sumSquares / sampleCount).toFloat().coerceIn(0f, 1f)
    }

    /**
     * Cheap linear resampler used to feed the 24 kHz realtime transport from the 16 kHz
     * capture stream. Nearest-neighbour is adequate for speech at these rates and costs
     * far less than a proper filter on a phone CPU.
     */
    fun resamplePcm16(pcm: ByteArray, fromRate: Int, toRate: Int): ByteArray {
        if (fromRate == toRate || pcm.size < 2) return pcm

        val inputSamples = pcm.size / 2
        val outputSamples = (inputSamples.toLong() * toRate / fromRate).toInt()
        if (outputSamples <= 0) return ByteArray(0)

        val out = ByteArray(outputSamples * 2)
        for (i in 0 until outputSamples) {
            val sourceIndex = (i.toLong() * fromRate / toRate).toInt().coerceAtMost(inputSamples - 1)
            out[i * 2] = pcm[sourceIndex * 2]
            out[i * 2 + 1] = pcm[sourceIndex * 2 + 1]
        }
        return out
    }
}
