package com.aitranslator.live.core.audio.recorder

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import androidx.core.content.ContextCompat
import com.aitranslator.live.core.audio.WavEncoder
import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.Logger
import com.aitranslator.live.core.domain.audio.AudioCaptureException
import com.aitranslator.live.core.domain.audio.AudioFormatSpec
import com.aitranslator.live.core.domain.audio.AudioFrame
import com.aitranslator.live.core.domain.audio.AudioRecorder
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.currentCoroutineContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Microphone capture built on [AudioRecord].
 *
 * `AudioRecord` is used instead of `MediaRecorder` because every downstream stage — VAD,
 * chunking, the realtime uploader — needs raw PCM frames, not an encoded file.
 *
 * The hardware effects (AEC/NS/AGC) are enabled when the device offers them: without echo
 * cancellation the app would transcribe its own spoken translation in Live mode.
 */
@Singleton
class PcmAudioRecorder @Inject constructor(
    @ApplicationContext private val context: Context,
) : AudioRecorder {

    @Volatile
    private var recording = false

    override val isRecording: Boolean get() = recording

    @SuppressLint("MissingPermission")
    override fun frames(): Flow<AudioFrame> = flow {
        if (!hasPermission()) {
            throw AudioCaptureException(AppError.PermissionDenied(Manifest.permission.RECORD_AUDIO))
        }

        val minBuffer = AudioRecord.getMinBufferSize(
            AudioFormatSpec.SAMPLE_RATE_HZ,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
        )
        if (minBuffer == AudioRecord.ERROR || minBuffer == AudioRecord.ERROR_BAD_VALUE) {
            throw AudioCaptureException(
                AppError.AudioCapture("device rejected 16 kHz mono PCM16 capture"),
            )
        }

        val bufferSize = maxOf(minBuffer, AudioFormatSpec.FRAME_BYTES * BUFFER_FRAMES)

        val recorder = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                AudioFormatSpec.SAMPLE_RATE_HZ,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize,
            )
        } catch (security: SecurityException) {
            throw AudioCaptureException(
                AppError.PermissionDenied(Manifest.permission.RECORD_AUDIO, security.message),
            )
        }

        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            throw AudioCaptureException(
                AppError.AudioCapture("AudioRecord could not be initialised — another app may hold the microphone"),
            )
        }

        val effects = enableEffects(recorder.audioSessionId)

        try {
            recorder.startRecording()
            if (recorder.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                throw AudioCaptureException(
                    AppError.AudioCapture("microphone is busy — capture did not start"),
                )
            }
            recording = true

            val frame = ByteArray(AudioFormatSpec.FRAME_BYTES)
            while (currentCoroutineContext().isActive) {
                val read = recorder.read(frame, 0, frame.size)
                when {
                    read > 0 -> {
                        val copy = frame.copyOf(read)
                        emit(
                            AudioFrame(
                                pcm = copy,
                                rms = WavEncoder.rms(copy),
                                timestampMillis = System.currentTimeMillis(),
                            ),
                        )
                    }

                    read == AudioRecord.ERROR_INVALID_OPERATION ||
                        read == AudioRecord.ERROR_BAD_VALUE ||
                        read == AudioRecord.ERROR_DEAD_OBJECT -> {
                        throw AudioCaptureException(
                            AppError.AudioCapture("AudioRecord.read returned $read"),
                        )
                    }
                }
            }
        } finally {
            recording = false
            runCatching { recorder.stop() }
            runCatching { recorder.release() }
            effects.forEach { runCatching { it.release() } }
        }
    }.flowOn(Dispatchers.IO)

    private fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun enableEffects(sessionId: Int): List<android.media.audiofx.AudioEffect> {
        val effects = mutableListOf<android.media.audiofx.AudioEffect>()

        if (AcousticEchoCanceler.isAvailable()) {
            runCatching {
                AcousticEchoCanceler.create(sessionId)?.apply { enabled = true }
            }.getOrNull()?.let(effects::add)
        }
        if (NoiseSuppressor.isAvailable()) {
            runCatching {
                NoiseSuppressor.create(sessionId)?.apply { enabled = true }
            }.getOrNull()?.let(effects::add)
        }
        if (AutomaticGainControl.isAvailable()) {
            runCatching {
                AutomaticGainControl.create(sessionId)?.apply { enabled = true }
            }.getOrNull()?.let(effects::add)
        }

        Logger.d(TAG, "enabled ${effects.size} hardware audio effects")
        return effects
    }

    private companion object {
        const val TAG = "PcmAudioRecorder"
        const val BUFFER_FRAMES = 10
    }
}
