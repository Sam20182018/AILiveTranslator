package com.aitranslator.live.core.audio.live

import com.aitranslator.live.core.common.Logger
import com.aitranslator.live.core.domain.live.LiveSessionConfig
import com.aitranslator.live.core.domain.live.LiveTranslationEngine
import com.aitranslator.live.core.domain.live.LiveTranslationEngineSelector
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Picks the realtime engine only when the user asked for low latency *and* the transport
 * is genuinely available; otherwise the chunked pipeline runs, so Live mode always works
 * regardless of which provider is configured.
 */
@Singleton
class DefaultLiveEngineSelector @Inject constructor(
    private val realtimeEngine: RealtimeLiveTranslationEngine,
    private val chunkedEngine: ChunkedLiveTranslationEngine,
) : LiveTranslationEngineSelector {

    override suspend fun select(config: LiveSessionConfig): LiveTranslationEngine {
        if (config.latencyProfile.preferRealtimeEngine && realtimeEngine.isSupported(config)) {
            Logger.d(TAG, "using realtime engine")
            return realtimeEngine
        }
        Logger.d(TAG, "using chunked engine")
        return chunkedEngine
    }

    private companion object {
        const val TAG = "LiveEngineSelector"
    }
}
