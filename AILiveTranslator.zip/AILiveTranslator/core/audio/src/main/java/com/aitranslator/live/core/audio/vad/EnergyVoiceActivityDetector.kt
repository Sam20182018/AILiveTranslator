package com.aitranslator.live.core.audio.vad

import com.aitranslator.live.core.domain.audio.AudioFormatSpec
import com.aitranslator.live.core.domain.audio.AudioFrame
import com.aitranslator.live.core.domain.audio.VadDecision
import com.aitranslator.live.core.domain.audio.VoiceActivityDetector

/**
 * Adaptive energy-based voice activity detection.
 *
 * This is the single most important cost control in the app: without it every second of
 * silence would be uploaded to a paid speech API. It keeps a slowly-adapting noise floor
 * so it works in a quiet room and on a busy street, requires [minSpeechMillis] of energy
 * before opening a segment (rejects clicks and door slams) and [silenceMillis] of quiet
 * before closing one (so natural pauses do not chop a sentence in half).
 *
 * Not thread-safe by design — one detector instance belongs to one capture session.
 */
class EnergyVoiceActivityDetector(
    private val silenceMillis: Long = 700L,
    private val minSpeechMillis: Long = 250L,
    private val maxSegmentMillis: Long = 6_000L,
    /** Speech must be this many times louder than the adapted noise floor. */
    private val activationFactor: Float = 2.6f,
    /** Absolute floor so a perfectly silent room cannot make the threshold ~0. */
    private val minimumThreshold: Float = 0.012f,
) : VoiceActivityDetector {

    private var noiseFloor = minimumThreshold
    private var inSpeech = false
    private var speechMillis = 0L
    private var silentMillis = 0L
    private var candidateMillis = 0L

    override fun reset() {
        noiseFloor = minimumThreshold
        inSpeech = false
        speechMillis = 0L
        silentMillis = 0L
        candidateMillis = 0L
    }

    override fun accept(frame: AudioFrame): VadDecision {
        val frameMillis = AudioFormatSpec.FRAME_MILLIS.toLong()
        val threshold = maxOf(noiseFloor * activationFactor, minimumThreshold)
        val isLoud = frame.rms > threshold

        if (!isLoud) {
            // Adapt the floor only on quiet frames so speech never raises it.
            noiseFloor = noiseFloor * (1f - NOISE_ADAPT_RATE) + frame.rms * NOISE_ADAPT_RATE
        }

        return if (inSpeech) {
            speechMillis += frameMillis
            if (isLoud) {
                silentMillis = 0L
                if (speechMillis >= maxSegmentMillis) {
                    closeSegment()
                    VadDecision.SPEECH_END
                } else {
                    VadDecision.SPEECH
                }
            } else {
                silentMillis += frameMillis
                if (silentMillis >= silenceMillis) {
                    closeSegment()
                    VadDecision.SPEECH_END
                } else {
                    VadDecision.SPEECH
                }
            }
        } else {
            if (isLoud) {
                candidateMillis += frameMillis
                if (candidateMillis >= minSpeechMillis) {
                    inSpeech = true
                    speechMillis = candidateMillis
                    silentMillis = 0L
                    candidateMillis = 0L
                    VadDecision.SPEECH_START
                } else {
                    VadDecision.SILENCE
                }
            } else {
                candidateMillis = 0L
                VadDecision.SILENCE
            }
        }
    }

    /** Current adapted threshold — exposed for the debug overlay and for tests. */
    fun currentThreshold(): Float = maxOf(noiseFloor * activationFactor, minimumThreshold)

    private fun closeSegment() {
        inSpeech = false
        speechMillis = 0L
        silentMillis = 0L
        candidateMillis = 0L
    }

    private companion object {
        const val NOISE_ADAPT_RATE = 0.05f
    }
}
