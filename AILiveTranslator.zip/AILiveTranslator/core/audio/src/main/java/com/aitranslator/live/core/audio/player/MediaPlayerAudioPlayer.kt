package com.aitranslator.live.core.audio.player

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.common.Logger
import com.aitranslator.live.core.domain.audio.AudioPlayer
import com.aitranslator.live.core.domain.model.SynthesizedAudio
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume

/**
 * Plays cloud-synthesised audio (MP3) and saved history clips.
 *
 * `MediaPlayer` needs a file or URI rather than a byte array, so buffers are written to a
 * private cache file first; those files are deleted as soon as playback finishes unless
 * the caller asked for them to be persisted.
 */
@Singleton
class MediaPlayerAudioPlayer @Inject constructor(
    @ApplicationContext private val context: Context,
) : AudioPlayer {

    private var player: MediaPlayer? = null

    @Volatile
    private var playing = false

    override val isPlaying: Boolean get() = playing

    override suspend fun play(audio: SynthesizedAudio, volume: Float): AppResult<Unit> {
        val cacheFile = File(context.cacheDir, "tts_${System.nanoTime()}.${audio.fileExtension}")
        return try {
            cacheFile.writeBytes(audio.bytes)
            playFile(cacheFile.absolutePath, volume)
        } catch (throwable: Throwable) {
            AppResult.Failure(AppError.AudioPlayback(throwable.message))
        } finally {
            runCatching { cacheFile.delete() }
        }
    }

    override suspend fun playFile(path: String, volume: Float): AppResult<Unit> =
        suspendCancellableCoroutine { continuation ->
            stop()

            val mediaPlayer = MediaPlayer()
            player = mediaPlayer
            var resumed = false

            fun finish(result: AppResult<Unit>) {
                if (resumed) return
                resumed = true
                playing = false
                runCatching { mediaPlayer.release() }
                if (player === mediaPlayer) player = null
                if (continuation.isActive) continuation.resume(result)
            }

            try {
                mediaPlayer.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build(),
                )
                mediaPlayer.setDataSource(path)
                val clamped = volume.coerceIn(0f, 1f)
                mediaPlayer.setVolume(clamped, clamped)

                mediaPlayer.setOnCompletionListener { finish(AppResult.Success(Unit)) }
                mediaPlayer.setOnErrorListener { _, what, extra ->
                    Logger.w(TAG, "MediaPlayer error what=$what extra=$extra")
                    finish(AppResult.Failure(AppError.AudioPlayback("what=$what extra=$extra")))
                    true
                }
                mediaPlayer.setOnPreparedListener {
                    playing = true
                    it.start()
                }
                mediaPlayer.prepareAsync()
            } catch (throwable: Throwable) {
                finish(AppResult.Failure(AppError.AudioPlayback(throwable.message)))
            }

            continuation.invokeOnCancellation { finish(AppResult.Success(Unit)) }
        }

    override fun stop() {
        val current = player ?: return
        runCatching { if (current.isPlaying) current.stop() }
        runCatching { current.release() }
        player = null
        playing = false
    }

    override fun release() = stop()

    private companion object {
        const val TAG = "AudioPlayer"
    }
}
