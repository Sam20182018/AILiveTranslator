package com.aitranslator.live.core.audio.recorder

import com.aitranslator.live.core.audio.WavEncoder
import com.aitranslator.live.core.audio.vad.EnergyVoiceActivityDetector
import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.domain.audio.AudioCaptureException
import com.aitranslator.live.core.domain.audio.AudioFormatSpec
import com.aitranslator.live.core.domain.audio.AudioRecorder
import com.aitranslator.live.core.domain.audio.VadDecision
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.transformWhile
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Inject
import javax.inject.Singleton

/** What a single push-to-talk capture reports back to the caller. */
sealed class CaptureEvent {
    data class Amplitude(val level: Float) : CaptureEvent()

    data object SpeechDetected : CaptureEvent()

    data class Completed(val wav: ByteArray, val durationMillis: Long) : CaptureEvent() {
        override fun equals(other: Any?): Boolean =
            other is Completed && durationMillis == other.durationMillis &&
                wav.contentEquals(other.wav)

        override fun hashCode(): Int = 31 * wav.contentHashCode() + durationMillis.hashCode()
    }

    data class Failed(val error: AppError) : CaptureEvent()
}

/**
 * One-shot recording for Voice and Conversation modes.
 *
 * Stops on whichever comes first: [requestStop] from the UI, a trailing silence long
 * enough to look like the end of a sentence, or [MAX_CAPTURE_MILLIS]. The silence stop is
 * what makes "press once and talk" feel natural instead of "press, talk, press again".
 */
@Singleton
class PushToTalkRecorder @Inject constructor(
    private val audioRecorder: AudioRecorder,
) {

    private val stopRequested = AtomicBoolean(false)

    val isRecording: Boolean get() = audioRecorder.isRecording

    fun requestStop() {
        stopRequested.set(true)
    }

    /**
     * @param autoStopSilenceMillis `null` disables the silence stop (pure push-to-talk).
     */
    @OptIn(ExperimentalCoroutinesApi::class)
    fun capture(
        autoStopSilenceMillis: Long? = DEFAULT_SILENCE_MILLIS,
        maxMillis: Long = MAX_CAPTURE_MILLIS,
    ): Flow<CaptureEvent> = flow {
        stopRequested.set(false)

        val detector = autoStopSilenceMillis?.let {
            EnergyVoiceActivityDetector(silenceMillis = it, maxSegmentMillis = maxMillis)
        }
        val buffer = ByteArrayOutputStream()
        var elapsedMillis = 0L
        var sawSpeech = false
        var framesSinceAmplitude = 0

        emitAll(
            audioRecorder.frames().transformWhile { frame ->
                buffer.write(frame.pcm)
                elapsedMillis += AudioFormatSpec.FRAME_MILLIS.toLong()

                framesSinceAmplitude++
                if (framesSinceAmplitude >= AMPLITUDE_EVERY_N_FRAMES) {
                    framesSinceAmplitude = 0
                    emit(CaptureEvent.Amplitude(frame.rms))
                }

                val decision = detector?.accept(frame)
                if (decision == VadDecision.SPEECH_START && !sawSpeech) {
                    sawSpeech = true
                    emit(CaptureEvent.SpeechDetected)
                }

                val silenceStop = sawSpeech && decision == VadDecision.SPEECH_END
                val shouldStop = stopRequested.get() ||
                    silenceStop ||
                    elapsedMillis >= maxMillis

                if (shouldStop) {
                    emit(
                        CaptureEvent.Completed(
                            wav = WavEncoder.encode(buffer.toByteArray()),
                            durationMillis = elapsedMillis,
                        ),
                    )
                    false
                } else {
                    true
                }
            },
        )
    }.catch { throwable ->
        if (throwable is CancellationException) throw throwable
        val error = (throwable as? AudioCaptureException)?.appError
            ?: AppError.AudioCapture(throwable.message)
        emit(CaptureEvent.Failed(error))
    }.onCompletion {
        stopRequested.set(false)
    }

    companion object {
        const val DEFAULT_SILENCE_MILLIS = 900L
        const val MAX_CAPTURE_MILLIS = 60_000L
        private const val AMPLITUDE_EVERY_N_FRAMES = 3
    }
}
