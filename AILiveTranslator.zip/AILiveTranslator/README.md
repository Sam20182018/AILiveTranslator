# AI Live Translator

An online AI translator for Android: text, voice, continuous live translation, two-person
conversation, plus **honest** WhatsApp and phone-call assist modes.

Kotlin · Jetpack Compose · Material 3 · Clean Architecture + MVVM · Hilt · Coroutines/Flow ·
Retrofit/OkHttp · Room · DataStore · Android Keystore

Supported languages: **Persian · English · Arabic · French · Dutch · German**
(adding a seventh is one enum entry — see [Extending](#extending)).

Supported AI providers: **Google Gemini · Anthropic Claude · OpenAI · Auto**

> Read `ARCHITECTURE.md` for the full design, and §12/§13 of that document for the detailed
> platform analysis behind the WhatsApp and phone-call limitations summarised below.

---

## 1. Build

### Requirements

| | |
|---|---|
| Android Studio | Ladybug (2024.2) or newer |
| JDK | 17 |
| Gradle | 8.11.1 (wrapper included) |
| Android Gradle Plugin | 8.7.3 |
| Kotlin | 2.0.21 |
| compileSdk / targetSdk | 35 |
| minSdk | 26 (Android 8.0) |

### Steps

```bash
git clone <your-repo> AILiveTranslator
cd AILiveTranslator

# Debug APK
./gradlew :app:assembleDebug

# Install on a connected device
./gradlew :app:installDebug

# Unit tests (all modules)
./gradlew test

# Lint
./gradlew :app:lintDebug
```

Or open the project root in Android Studio and press Run. The first sync downloads the
Gradle distribution and all dependencies, so it needs an internet connection.

Signed release build:

```bash
./gradlew :app:assembleRelease   # requires your own signing config
```

No API key of any kind is required to **build**. Keys are entered at runtime.

### Project layout

```
app/                 UI (Compose), ViewModels, navigation, services
core/common/         AppResult, AppError, dispatchers, NetworkMonitor, redacting Logger
core/domain/         models, interfaces, use cases   ← pure, no Android/vendor deps
core/network/        Gemini / Claude / OpenAI clients, STT, TTS, Realtime WebSocket
core/audio/          AudioRecord capture, VAD, WAV, playback, device TTS, live engines
core/data/           Room, DataStore, Keystore crypto, repositories, translation cache
```

---

## 2. Entering your API keys

Everything happens inside the app — nothing is compiled in.

**Settings → AI API settings**

1. Paste the key into the field for the provider you want.
2. Tap **Test connection** — this makes the smallest possible request and tells you
   immediately whether the key works.
3. Tap **Save**.

The field is masked by default; the eye icon reveals what you are typing.

### Where to get each key

| Provider | Console | Key looks like |
|---|---|---|
| Google Gemini | Google AI Studio → *Get API key* | `AIza…` |
| Anthropic Claude | console.anthropic.com → *API Keys* | `sk-ant-…` |
| OpenAI | platform.openai.com → *API keys* | `sk-…` |

### How keys are stored

* A 256-bit AES key is generated once inside the **Android Keystore** and never leaves it.
* Each API key is encrypted with AES/GCM and only the `iv‖ciphertext` blob is written to
  DataStore. Nothing is stored in plaintext, in SharedPreferences, or in a backup
  (`allowBackup=false` plus explicit backup exclusion rules).
* `Logger` redacts anything matching a key pattern, and OkHttp's logging interceptor has
  `Authorization`, `x-api-key` and `x-goog-api-key` on its redaction list — in debug builds
  too. The Gemini key is sent as a header rather than a `?key=` query parameter so it can
  never end up in a URL that gets logged.
* **Delete** removes the encrypted blob and its mask.

---

## 3. Choosing the provider and the model

**Settings → AI provider**: `Auto`, `Gemini`, `Claude`, `OpenAI`.

`Auto` picks the first provider that has a saved, active key, pushing any provider whose
last connection test failed to the back of the queue. Preference order is
OpenAI → Gemini → Claude, because OpenAI also covers speech recognition and speech
synthesis while Claude is translation-only.

**Model** is set per provider on the same screen. Leave it empty to use the built-in
default; type any model id to override it. Model names are never hard-coded at a call site
(`AiModelConfig`), so when a vendor renames a model you can just type the new name.

| Provider | Default translation model | Also used for |
|---|---|---|
| OpenAI | `gpt-4o-mini` | `whisper-1` (speech→text), `tts-1` (text→speech), `gpt-4o-realtime-preview` |
| Gemini | `gemini-1.5-flash` | audio transcription via inline audio |
| Claude | `claude-3-5-haiku-20241022` | translation only |

### Provider capability matrix

| | Translate | Streaming | Speech→text | Text→speech | Realtime duplex |
|---|:--:|:--:|:--:|:--:|:--:|
| OpenAI | ✅ | ✅ | ✅ | ✅ | ✅ |
| Gemini | ✅ | ✅ | ✅ | ❌ | ❌ |
| Claude | ✅ | ✅ | ❌ | ❌ | ❌ |

Claude has no audio endpoints. If you select Claude, translation uses Claude while speech
recognition falls back to OpenAI → Gemini and speech falls back to OpenAI → your device's
TTS engine. The app tells you when it does this instead of failing silently.

---

## 4. Using it

### Text

Home → **Text**. Type or paste, tap **Translate**. Copy, share, replay the audio or clear
from the result card. Text shared into the app from any other app (including WhatsApp)
opens straight into this screen.

### Voice

Home → **Voice** (or the big microphone on the home screen). Tap once, speak, and it stops
by itself when you pause — or tap again to stop immediately. You get the transcript, the
translation, and the spoken translation.

### Live

Home → **Live** → **Start live translation**. The microphone stays open and each utterance
is translated and spoken as you go. Finished lines stack up underneath so nothing scrolls
away before you have read it.

Two engines sit behind this button:

* **Chunked pipeline** (default) — mic → voice-activity detection → speech recognition →
  streaming translation → speech. Works with every provider.
* **Realtime WebSocket** — used automatically when *Settings → Latency* is `low_latency`
  **and** an OpenAI key is saved. Audio streams up while you are still speaking and the
  translated audio streams back down, which is noticeably faster.

The engine actually in use is shown under the button.

### Conversation

Home → **Conversation**. Pick the two languages, then:

* **Manual** (default) — each person taps their own button. Unambiguous.
* **Automatic** — the microphone stays open and the app infers who spoke. When the two
  languages use different scripts (e.g. Persian vs German) the script of the transcript
  decides; when they share a script the turn simply alternates. It is a heuristic, and
  manual mode exists for when it is not good enough.

Every turn appears as a chat bubble with the original above and the translation below, each
with play and copy buttons.

### History

Toolbar → clock icon. Search, replay, copy, share, delete one, delete all. Only recorded
while *Save translation history* is on.

---

## 5. Voices

**Settings → Voice**

* **10 cloud voices** (OpenAI): 5 male — Onyx, Echo, Ash, Ballad, Verse; 5 female — Nova,
  Shimmer, Alloy, Coral, Sage. Consistent quality across all six languages, needs an
  OpenAI key.
* **Device voices**: whatever your phone's TTS engine reports, discovered at runtime and
  tagged male/female where the engine's naming allows it. Free, works offline.
* Filter by gender, **Preview** any voice before selecting it, and set **speed** (0.5–2.0×)
  and **volume**.
* **Voice translation ON/OFF** and **Auto play ON/OFF** live in the main Settings screen.
  With voice off you get text only.

---

## 6. WhatsApp — what works and what Android forbids

Open **WhatsApp** from the home screen. The app shows this list before you start anything.

### ✅ Chat text translation (requires your consent)

An Accessibility Service reads the message text visible on screen in `com.whatsapp` and
translates it. You enable it yourself in **Android Settings → Accessibility**; the button
on the WhatsApp screen takes you there. It is scoped to WhatsApp packages in
`accessibility_service_config.xml`, it uses no audio API at all, and it stores nothing
beyond the normal history setting.

### ⚠️ Speaker Assist (device-dependent)

Put the call on **speakerphone** and start Speaker Assist. The app listens through the
microphone, transcribes, translates and shows subtitles.

Since Android 10 the microphone is exclusive to the app holding audio focus, so on many
devices a background app receives silence during a VoIP call. The app detects that it is
not hearing anything and says so, rather than showing an empty screen forever.

### ❌ Capturing WhatsApp call audio — not possible

`MediaProjection` + `AudioPlaybackCaptureConfiguration` (API 29+) is the only sanctioned
way to capture another app's playback, and it can **never** capture streams whose
`AudioAttributes.usage` is `USAGE_VOICE_COMMUNICATION` — which is what every VoIP call
uses. It also honours each app's capture policy, and WhatsApp does not opt in. There is no
permission, flag or API that changes this for a normal app.

### ❌ Injecting translated audio into a WhatsApp call — not possible

Android has no public API to write audio into another app's microphone input. A virtual
microphone requires a system or OEM audio HAL, not an installable app. What the app can do
is play the translation on your speaker, which the other side hears acoustically while the
call is on speakerphone.

**No root, no exploits, no bypasses are used anywhere in this project.**

---

## 7. Phone calls — what works and what Android forbids

Open **Phone Call** from the home screen.

### ❌ Reading the call audio stream — not possible

`MediaRecorder.AudioSource.VOICE_CALL / VOICE_DOWNLINK / VOICE_UPLINK` require
`android.permission.CAPTURE_AUDIO_OUTPUT`, which is `signature|privileged`. A Play Store
app cannot hold it; on Android 10+ the request fails or returns silence.

### ❌ Call recording — not possible

Closed off in Android 10 and hardened in Android 11. Play policy additionally forbids using
an Accessibility Service to record calls, so there is no compliant workaround.

### ❌ Speaking the translation *into* the call — not possible

`InCallService` / the dialer role let an app control a call (answer, mute, hold, route to
speaker) but give zero access to the audio samples. `CallScreeningService` sees metadata
only. A full-duplex "the other side hears the translation" phone translator is therefore
**not implementable** by a normal Android app, and this project does not claim otherwise.

### ✅ Call Assistant Mode — what is implemented instead

* Optional `READ_PHONE_STATE` lets the app notice an active call and offer to start.
* Speakerphone + microphone → subtitles of what the other party says.
* Your reply is translated and can be played aloud on the speaker, which is the only
  sanctioned way to get translated audio across to them.
* Same explicit consent dialog and capability report as WhatsApp mode.

---

## 8. Permissions

| Permission | Why | Asked when |
|---|---|---|
| `INTERNET`, `ACCESS_NETWORK_STATE` | online translation, connection pill | manifest only |
| `RECORD_AUDIO` | every voice mode | first time you press the microphone |
| `POST_NOTIFICATIONS` (Android 13+) | foreground assist notification | before starting an assist mode |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MICROPHONE` | assist modes keep listening | manifest only |
| `READ_PHONE_STATE` (optional) | notice an active call | only if you open Call Assist |
| `SYSTEM_ALERT_WINDOW` (optional) | floating subtitles | user-granted from the assist screen |
| `BIND_ACCESSIBILITY_SERVICE` | WhatsApp **chat text** translation | you enable it in Android Settings |

Nothing else is requested. There is no `CAPTURE_AUDIO_OUTPUT`, no `PROCESS_OUTGOING_CALLS`,
no contacts, no storage.

---

## 9. Privacy

**Settings → Privacy**

* **Save translation history** — ON by default. Turning it off deletes everything already
  stored, so the switch is not just a promise about the future.
* **Save audio** — **OFF by default**. No audio is ever written to storage unless you turn
  this on. Turning it off deletes every stored clip.
* **Reuse recent translations** — an in-memory cache of the last 200 short phrases, cleared
  when the app closes. It exists to stop you paying twice for "yes" and "thank you".

Recordings only exist while a translation is in flight. Nothing is uploaded except the
audio or text of the thing you asked to translate, sent to the provider you selected.

---

## 10. Keeping the API bill down

Real-time translation can burn tokens quickly. The app does all of the following:

1. **Voice-activity detection** with an adaptive noise floor — silence is never uploaded.
2. **Minimum utterance length** (400 ms) and a **maximum segment cap**, so neither clicks
   nor monologues produce pathological requests.
3. **Repeat suppression** — an identical consecutive transcript is not re-translated.
4. **LRU translation cache** keyed on normalised text plus the language pair.
5. **Streaming responses**, so latency is perceived as low at small token counts.
6. **Latency profile** (`low_latency` / `balanced` / `high_quality`) which tunes the silence
   threshold, the segment cap and whether the realtime engine is used.
7. **Same-language short-circuit** and **empty-input guard** before any request is built.

---

## 11. Error handling

Every failure is mapped to a typed `AppError` and rendered as one plain sentence. The HTTP
status, provider error body and request id go to the debug log only.

| Situation | What you see |
|---|---|
| No connectivity | "No internet connection" (plus a persistent offline banner) |
| 401 / 403 | "The *provider* API key is not valid. Check it in Settings." |
| No key saved | "No API key saved for *provider*. Add one in Settings." |
| 429 | "Rate limit reached. Try again in N seconds." |
| 5xx | "The service is temporarily unavailable." |
| Timeout | "The request timed out." |
| Unknown model | "The selected model is unavailable. Choose another in Settings." |
| Mic busy | "Could not use the microphone. Another app may be using it." |

---

## 12. Tests

```bash
./gradlew test                       # everything
./gradlew :core:network:test         # provider + error mapping (MockWebServer)
./gradlew :core:data:test            # repositories, AUTO selection, cache
./gradlew :core:audio:test           # VAD boundaries, WAV encoding, resampling
./gradlew :core:domain:test          # use-case guards
./gradlew :app:test                  # ViewModel state machine
```

What is covered: provider success/401/429/5xx/SSE-parsing paths against a local
`MockWebServer`, AUTO provider selection and fallback, cache hit/miss and eviction, the
offline short-circuit, VAD segment boundaries on synthetic PCM, WAV header correctness, and
ViewModel state transitions including history writes and auto-play.

**No real API key appears anywhere in the repository or in any test** — tests use
`MockWebServer` and the literal string `test-key`.

---

## 13. Troubleshooting

| Symptom | Cause and fix |
|---|---|
| "No API key saved" | Settings → AI API settings → paste, **Test connection**, **Save**. |
| Test connection fails with a valid key | Check the model id on the same card; an unknown model returns 404. Clear it to fall back to the default. |
| The microphone button does nothing | Grant the microphone permission; Android only asks once, after that use system app settings. |
| Live mode hears nothing | Another app holds the microphone. Close call/recorder apps; check the status chip — it stays on "Listening…" with a flat amplitude. |
| Live mode transcribes its own output | Only happens on devices without hardware echo cancellation. Turn *Auto play* off, or use headphones. |
| Speech comes out in the wrong voice | Cloud voices need an OpenAI key; without one the app falls back to the device engine. Settings → Voice shows which is selected. |
| Device TTS is silent for Persian/Arabic | The device has no voice data for that language. Install it via Android's text-to-speech settings, or pick a cloud voice. |
| WhatsApp chat translation does nothing | The accessibility service is not enabled. Assist screen → *Open accessibility settings*. |
| Speaker Assist shows "No audio is reaching the microphone" | Expected on devices where Android gives the calling app exclusive microphone access. See §6. |
| Rate limited constantly | Lower the latency profile to `balanced` or `high_quality`, keep the translation cache on, and check your provider's usage tier. |
| Build fails on a fresh clone | Confirm JDK 17 (`./gradlew -version`) and let Android Studio finish the first Gradle sync. |

---

## 14. Debugging

```bash
# App logs (credentials are redacted by the Logger before they reach Logcat)
adb logcat -s Http:D Realtime:D ChunkedLive:D RealtimeLive:D PcmAudioRecorder:D \
              SpeechRepository:D TranslationRepository:D A11yTranslator:D SpeakerAssist:I

# Is the accessibility service enabled?
adb shell settings get secure enabled_accessibility_services

# Is the foreground assist service running?
adb shell dumpsys activity services com.aitranslator.live
```

* Debug builds set `Logger.debugEnabled = true` (`BuildConfig.DEBUG_LOG`); release builds
  log nothing beyond warnings and errors.
* `RedactingInterceptor` prints one line per request with the method, URL and duration, with
  key-bearing query parameters replaced by `REDACTED`.
* To inspect raw request bodies while developing, raise `HttpLoggingInterceptor.Level` in
  `NetworkModule` — the redaction list keeps credentials out either way. Do not ship that.
* The Live screen shows which engine (`chunked` / `realtime`) is running, which is the first
  thing to check when latency is not what you expect.

---

## 15. Extending

| Goal | Change |
|---|---|
| Add a language | One entry in `Language`. Selectors, prompts, STT hints, TTS locales and history filters all derive from it. |
| Add an AI provider | Implement `AITranslationProvider`, add a case to `AiProvider`, bind it `@Binds @IntoSet`. Nothing else changes. |
| Change a model | Settings → Model, or the default in `AiModelConfig`. |
| Swap the live engine | Implement `LiveTranslationEngine` and return it from `LiveTranslationEngineSelector`. |
| Add offline mode | Implement `SpeechRecognitionProvider`, `AITranslationProvider` and `TextToSpeechProvider` with on-device engines and bind them. No UI or ViewModel changes — the architecture was built for this. |
| Point at a proxy | Provide a different `ApiHosts` in `NetworkModule`. |

---

## 16. Honest summary

Implemented and working: text, voice, live (two engines), conversation, 10+ voices, three
providers with Auto selection, encrypted key storage, history, privacy controls, cost
controls, full error handling, WhatsApp chat-text translation.

Implemented with a documented limitation: Speaker Assist and Call Assistant Mode — they
work where the device lets a background app use the microphone during a call, and say so
when it does not.

Not implemented because Android does not permit it for a normal app: capturing WhatsApp or
cellular call audio, recording calls, and injecting translated audio into a call. Each of
these is spelled out in the app itself, before the user starts, with the platform mechanism
that blocks it.
