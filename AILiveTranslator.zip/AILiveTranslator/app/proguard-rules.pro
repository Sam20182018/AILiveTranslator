# Kotlin serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keepclassmembers class kotlinx.serialization.json.** { *; }
-keep,includedescriptorclasses class com.aitranslator.live.**$$serializer { *; }
-keepclassmembers class com.aitranslator.live.** { *** Companion; }
-keepclasseswithmembers class com.aitranslator.live.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.aitranslator.live.core.network.**$$serializer { *; }
-keepclassmembers class com.aitranslator.live.core.network.** { *** Companion; }
-keepclasseswithmembers class com.aitranslator.live.core.network.** { kotlinx.serialization.KSerializer serializer(...); }

# Retrofit / OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn retrofit2.**
-keepattributes Signature, Exceptions
-keep,allowobfuscation,allowshrinking interface retrofit2.Call
-keep,allowobfuscation,allowshrinking class retrofit2.Response
-keep,allowobfuscation,allowshrinking class kotlin.coroutines.Continuation

# Room
-keep class * extends androidx.room.RoomDatabase { <init>(); }
-dontwarn androidx.room.paging.**

# Accessibility service is referenced from XML only
-keep class com.aitranslator.live.service.** { *; }
