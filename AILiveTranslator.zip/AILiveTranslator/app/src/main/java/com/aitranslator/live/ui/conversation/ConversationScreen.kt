package com.aitranslator.live.ui.conversation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aitranslator.live.R
import com.aitranslator.live.core.domain.model.ConversationTurnMode
import com.aitranslator.live.core.domain.model.Speaker
import com.aitranslator.live.ui.common.toUserMessage
import com.aitranslator.live.ui.components.ConversationBubble
import com.aitranslator.live.ui.components.LanguageSelectorRow
import com.aitranslator.live.ui.components.PipelineStatusChip
import com.aitranslator.live.ui.components.TranslatorScaffold
import com.aitranslator.live.ui.components.rememberMicrophonePermission

/**
 * Two people, two languages, one phone between them.
 *
 * The screen is symmetric: Person A's controls at the top, Person B's at the bottom, and
 * the history in the middle so both can read it from their side of the table.
 */
@Composable
fun ConversationScreen(
    onBack: () -> Unit,
    viewModel: ConversationViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    val listState = rememberLazyListState()
    val micPermission = rememberMicrophonePermission()

    LaunchedEffect(uiState.turns.size) {
        if (uiState.turns.isNotEmpty()) {
            listState.animateScrollToItem(uiState.turns.lastIndex)
        }
    }

    LaunchedEffect(uiState.error) {
        uiState.error?.let { error ->
            snackbarHostState.showSnackbar(error.toUserMessage(context))
            viewModel.dismissError()
        }
    }

    TranslatorScaffold(
        title = stringResource(R.string.mode_conversation),
        onBack = onBack,
        isOnline = isOnline,
        snackbarHostState = snackbarHostState,
        actions = {
            IconButton(onClick = viewModel::clearConversation) {
                Icon(
                    imageVector = Icons.Filled.DeleteSweep,
                    contentDescription = stringResource(R.string.action_clear),
                )
            }
        },
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp),
        ) {
            LanguageSelectorRow(
                source = settings.conversationLanguageA,
                target = settings.conversationLanguageB,
                onSourceSelected = { viewModel.setLanguages(it, settings.conversationLanguageB) },
                onTargetSelected = { viewModel.setLanguages(settings.conversationLanguageA, it) },
                onSwap = {
                    viewModel.setLanguages(
                        settings.conversationLanguageB,
                        settings.conversationLanguageA,
                    )
                },
                enabled = !uiState.isRecording,
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = uiState.turnMode == ConversationTurnMode.MANUAL,
                    onClick = { viewModel.setTurnMode(ConversationTurnMode.MANUAL) },
                    label = { Text(stringResource(R.string.conversation_manual_mode)) },
                )
                FilterChip(
                    selected = uiState.turnMode == ConversationTurnMode.AUTOMATIC,
                    onClick = { viewModel.setTurnMode(ConversationTurnMode.AUTOMATIC) },
                    label = { Text(stringResource(R.string.conversation_auto_mode)) },
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                PipelineStatusChip(state = uiState.pipelineState)
            }

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                state = listState,
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
            ) {
                items(items = uiState.turns, key = { it.id }) { turn ->
                    ConversationBubble(
                        turn = turn,
                        onSpeak = { text -> viewModel.speak(text, turn.targetLanguage) },
                        onCopy = { text -> clipboard.setText(AnnotatedString(text)) },
                    )
                }
            }

            if (uiState.turns.isEmpty()) {
                Text(
                    text = stringResource(R.string.history_empty),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(vertical = 8.dp),
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            when (uiState.turnMode) {
                ConversationTurnMode.MANUAL -> Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    SpeakerButton(
                        label = stringResource(R.string.conversation_person_a) +
                            " · " + settings.conversationLanguageA.flag,
                        isActive = uiState.activeSpeaker == Speaker.PERSON_A,
                        onClick = {
                            micPermission.runOrRequest {
                                viewModel.toggleSpeaker(Speaker.PERSON_A)
                            }
                        },
                        modifier = Modifier.weight(1f),
                    )
                    SpeakerButton(
                        label = stringResource(R.string.conversation_person_b) +
                            " · " + settings.conversationLanguageB.flag,
                        isActive = uiState.activeSpeaker == Speaker.PERSON_B,
                        onClick = {
                            micPermission.runOrRequest {
                                viewModel.toggleSpeaker(Speaker.PERSON_B)
                            }
                        },
                        modifier = Modifier.weight(1f),
                    )
                }

                ConversationTurnMode.AUTOMATIC -> Button(
                    onClick = { micPermission.runOrRequest(viewModel::toggleAutoSession) },
                    colors = if (uiState.isSessionRunning) {
                        ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = MaterialTheme.colorScheme.onError,
                        )
                    } else {
                        ButtonDefaults.buttonColors()
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        stringResource(
                            if (uiState.isSessionRunning) {
                                R.string.live_stop
                            } else {
                                R.string.live_start
                            },
                        ),
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
private fun SpeakerButton(
    label: String,
    isActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Button(
        onClick = onClick,
        colors = if (isActive) {
            ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.error,
                contentColor = MaterialTheme.colorScheme.onError,
            )
        } else {
            ButtonDefaults.buttonColors()
        },
        modifier = modifier.height(56.dp),
    ) {
        Text(text = label, maxLines = 1)
    }
}
