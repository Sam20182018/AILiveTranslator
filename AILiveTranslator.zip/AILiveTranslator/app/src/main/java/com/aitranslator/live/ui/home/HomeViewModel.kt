package com.aitranslator.live.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aitranslator.live.core.common.NetworkMonitor
import com.aitranslator.live.core.domain.model.AppSettings
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    networkMonitor: NetworkMonitor,
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = AppSettings(),
    )

    val isOnline: StateFlow<Boolean> = networkMonitor.isOnline.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = networkMonitor.isCurrentlyOnline(),
    )

    fun setSourceLanguage(language: Language) {
        viewModelScope.launch {
            settingsRepository.setSourceLanguage(language)
        }
    }

    fun setTargetLanguage(language: Language) {
        viewModelScope.launch {
            settingsRepository.setTargetLanguage(language)
        }
    }

    fun swapLanguages() {
        viewModelScope.launch {
            settingsRepository.swapLanguages()
        }
    }

    private companion object {
        const val STOP_TIMEOUT_MILLIS = 5_000L
    }
}
