package com.aitranslator.live.navigation

/** Every route in the app. String routes keep the graph readable and testable. */
object Destinations {
    const val HOME = "home"
    const val TEXT = "text"
    const val VOICE = "voice"
    const val LIVE = "live"
    const val CONVERSATION = "conversation"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
    const val API_KEYS = "settings/api_keys"
    const val VOICE_SETTINGS = "settings/voice"

    const val ASSIST_FEATURE_ARG = "feature"
    const val ASSIST_ROUTE = "assist/{$ASSIST_FEATURE_ARG}"

    fun assist(feature: String): String = "assist/$feature"
}
