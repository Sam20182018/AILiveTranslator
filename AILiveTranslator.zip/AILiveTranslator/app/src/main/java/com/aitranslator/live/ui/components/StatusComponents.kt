package com.aitranslator.live.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aitranslator.live.R
import com.aitranslator.live.core.domain.model.PipelineState
import com.aitranslator.live.ui.theme.ListeningBlue
import com.aitranslator.live.ui.theme.OfflineRed
import com.aitranslator.live.ui.theme.OnlineGreen
import com.aitranslator.live.ui.theme.SpeakingPurple

/** Small online/offline pill. The app is online-only, so this is always visible. */
@Composable
fun ConnectivityPill(isOnline: Boolean, modifier: Modifier = Modifier) {
    val color = if (isOnline) OnlineGreen else OfflineRed
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(50),
        modifier = modifier,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(color = color, shape = CircleShape),
            )
            Text(
                text = stringResource(
                    if (isOnline) R.string.status_online else R.string.status_offline,
                ),
                style = MaterialTheme.typography.labelLarge,
                color = color,
            )
        }
    }
}

/** Full-width banner shown only while offline, so the user knows why nothing works. */
@Composable
fun OfflineBanner(isOnline: Boolean, modifier: Modifier = Modifier) {
    AnimatedVisibility(visible = !isOnline, modifier = modifier) {
        Surface(
            color = MaterialTheme.colorScheme.errorContainer,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(
                text = stringResource(R.string.error_no_internet),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            )
        }
    }
}

/**
 * The pipeline state, spelled out. Users of live translation need to know whether the app
 * is still listening, thinking or already talking, otherwise they talk over it.
 */
@Composable
fun PipelineStatusChip(state: PipelineState, modifier: Modifier = Modifier) {
    val (label, color, showSpinner) = when (state) {
        is PipelineState.Idle ->
            Triple(stringResource(R.string.status_idle), MaterialTheme.colorScheme.outline, false)

        is PipelineState.Listening ->
            Triple(stringResource(R.string.status_listening), ListeningBlue, false)

        is PipelineState.Processing ->
            Triple(stringResource(R.string.status_processing), ListeningBlue, true)

        is PipelineState.Translating ->
            Triple(
                stringResource(R.string.status_translating),
                MaterialTheme.colorScheme.primary,
                true,
            )

        is PipelineState.Speaking ->
            Triple(stringResource(R.string.status_speaking), SpeakingPurple, false)

        is PipelineState.Stopped ->
            Triple(
                stringResource(R.string.status_stopped),
                MaterialTheme.colorScheme.outline,
                false,
            )

        is PipelineState.Error ->
            Triple(
                stringResource(R.string.error_unknown),
                MaterialTheme.colorScheme.error,
                false,
            )
    }

    StatusChip(label = label, color = color, showSpinner = showSpinner, modifier = modifier)
}

@Composable
private fun StatusChip(
    label: String,
    color: Color,
    showSpinner: Boolean,
    modifier: Modifier = Modifier,
) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(50),
        modifier = modifier,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
        ) {
            if (showSpinner) {
                CircularProgressIndicator(
                    strokeWidth = 2.dp,
                    color = color,
                    modifier = Modifier.size(14.dp),
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(color = color, shape = CircleShape),
                )
            }
            Text(text = label, style = MaterialTheme.typography.labelLarge, color = color)
        }
    }
}
