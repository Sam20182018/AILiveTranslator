package com.aitranslator.live.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aitranslator.live.R
import com.aitranslator.live.core.domain.model.Language

/**
 * Source ⇄ target picker. One tap on the middle button swaps the pair, which is the single
 * most-used control in a two-way conversation.
 */
@Composable
fun LanguageSelectorRow(
    source: Language,
    target: Language,
    onSourceSelected: (Language) -> Unit,
    onTargetSelected: (Language) -> Unit,
    onSwap: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        LanguagePickerButton(
            selected = source,
            onSelected = onSourceSelected,
            enabled = enabled,
            modifier = Modifier.weight(1f),
        )

        IconButton(onClick = onSwap, enabled = enabled) {
            Icon(
                imageVector = Icons.Filled.SwapHoriz,
                contentDescription = stringResource(R.string.action_swap),
            )
        }

        LanguagePickerButton(
            selected = target,
            onSelected = onTargetSelected,
            enabled = enabled,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun LanguagePickerButton(
    selected: Language,
    onSelected: (Language) -> Unit,
    enabled: Boolean,
    modifier: Modifier = Modifier,
) {
    var expanded by remember { mutableStateOf(false) }

    FilledTonalButton(
        onClick = { expanded = true },
        enabled = enabled,
        modifier = modifier,
    ) {
        Text(text = selected.displayLabel, maxLines = 1)
        Icon(
            imageVector = Icons.Filled.ArrowDropDown,
            contentDescription = null,
            modifier = Modifier.padding(start = 4.dp),
        )

        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            Language.entries.forEach { language ->
                DropdownMenuItem(
                    text = { Text("${language.flag}  ${language.nativeName}  ·  ${language.englishName}") },
                    onClick = {
                        expanded = false
                        onSelected(language)
                    },
                    modifier = Modifier.width(260.dp),
                )
            }
        }
    }
}
