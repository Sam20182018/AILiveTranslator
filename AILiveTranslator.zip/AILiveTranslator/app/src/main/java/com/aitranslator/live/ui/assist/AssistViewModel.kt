package com.aitranslator.live.ui.assist

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aitranslator.live.assist.AssistSessionController
import com.aitranslator.live.assist.AssistSessionState
import com.aitranslator.live.core.domain.assist.AssistCapabilities
import com.aitranslator.live.core.domain.model.AppSettings
import com.aitranslator.live.core.domain.model.CapabilityReport
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.TranslationMode
import com.aitranslator.live.core.domain.repository.SettingsRepository
import com.aitranslator.live.service.SpeakerAssistService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AssistViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val sessionController: AssistSessionController,
    private val settingsRepository: SettingsRepository,
) : ViewModel() {

    val sessionState: StateFlow<AssistSessionState> = sessionController.state

    val settings: StateFlow<AppSettings> = settingsRepository.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = AppSettings(),
    )

    fun capabilityReport(feature: String): CapabilityReport =
        AssistCapabilities.forFeature(feature)

    fun startSpeakerAssist(feature: String) {
        val mode = if (feature == AssistCapabilities.WHATSAPP) {
            TranslationMode.WHATSAPP
        } else {
            TranslationMode.PHONE_CALL
        }
        SpeakerAssistService.start(context, mode)
    }

    fun stopSpeakerAssist() {
        SpeakerAssistService.stop(context)
    }

    fun setSourceLanguage(language: Language) {
        viewModelScope.launch { settingsRepository.setSourceLanguage(language) }
    }

    fun setTargetLanguage(language: Language) {
        viewModelScope.launch { settingsRepository.setTargetLanguage(language) }
    }

    fun swapLanguages() {
        viewModelScope.launch { settingsRepository.swapLanguages() }
    }

    fun clearLines() {
        sessionController.clearLines()
    }

    fun dismissError() {
        sessionController.setError(null)
    }

    private companion object {
        const val STOP_TIMEOUT_MILLIS = 5_000L
    }
}
