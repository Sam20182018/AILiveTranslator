package com.aitranslator.live.assist

import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.domain.model.PipelineState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import javax.inject.Inject
import javax.inject.Singleton

data class AssistLine(
    val id: Long,
    val original: String,
    val translation: String,
    val fromChat: Boolean,
)

data class AssistSessionState(
    val isListening: Boolean = false,
    val isAccessibilityConnected: Boolean = false,
    val pipelineState: PipelineState = PipelineState.Idle,
    val partialOriginal: String = "",
    val partialTranslation: String = "",
    val lines: List<AssistLine> = emptyList(),
    val heardAnyAudio: Boolean = false,
    val error: AppError? = null,
)

/**
 * Shared state between the background assist services and whatever screen is open.
 *
 * A singleton rather than a bound service because the services are fire-and-forget and the
 * UI may not exist while they run; keeping the state here means reopening the screen shows
 * what has been captured so far.
 */
@Singleton
class AssistSessionController @Inject constructor() {

    private val _state = MutableStateFlow(AssistSessionState())
    val state: StateFlow<AssistSessionState> = _state.asStateFlow()

    fun setListening(listening: Boolean) {
        _state.update {
            it.copy(
                isListening = listening,
                pipelineState = if (listening) PipelineState.Listening() else PipelineState.Stopped,
                heardAnyAudio = if (listening) false else it.heardAnyAudio,
            )
        }
    }

    fun setAccessibilityConnected(connected: Boolean) {
        _state.update { it.copy(isAccessibilityConnected = connected) }
    }

    fun setPipelineState(state: PipelineState) {
        _state.update { it.copy(pipelineState = state) }
    }

    fun markAudioHeard() {
        _state.update { it.copy(heardAnyAudio = true) }
    }

    fun setPartial(original: String?, translation: String?) {
        _state.update {
            it.copy(
                partialOriginal = original ?: it.partialOriginal,
                partialTranslation = translation ?: it.partialTranslation,
            )
        }
    }

    fun addLine(original: String, translation: String, fromChat: Boolean) {
        _state.update { current ->
            val duplicate = current.lines.firstOrNull()
                ?.let { it.original == original && it.translation == translation } == true
            if (duplicate) {
                current
            } else {
                current.copy(
                    partialOriginal = "",
                    partialTranslation = "",
                    lines = listOf(
                        AssistLine(System.nanoTime(), original, translation, fromChat),
                    ) + current.lines.take(MAX_LINES),
                )
            }
        }
    }

    fun setError(error: AppError?) {
        _state.update { it.copy(error = error) }
    }

    fun clearLines() {
        _state.update { it.copy(lines = emptyList()) }
    }

    private companion object {
        const val MAX_LINES = 100
    }
}
