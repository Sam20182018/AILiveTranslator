package com.aitranslator.live.ui.voice

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aitranslator.live.core.audio.recorder.CaptureEvent
import com.aitranslator.live.core.audio.recorder.PushToTalkRecorder
import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.common.NetworkMonitor
import com.aitranslator.live.core.domain.model.AppSettings
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.PipelineState
import com.aitranslator.live.core.domain.model.TranslationMode
import com.aitranslator.live.core.domain.repository.SettingsRepository
import com.aitranslator.live.core.domain.usecase.SpeakTextUseCase
import com.aitranslator.live.core.domain.usecase.TranslateSpeechUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class VoiceUiState(
    val pipelineState: PipelineState = PipelineState.Idle,
    val amplitude: Float = 0f,
    val transcript: String = "",
    val translation: String = "",
    val error: AppError? = null,
) {
    val isRecording: Boolean get() = pipelineState is PipelineState.Listening
    val isBusy: Boolean
        get() = pipelineState is PipelineState.Processing ||
            pipelineState is PipelineState.Translating
}

/**
 * Push-to-talk translation.
 *
 * Recording stops on a second tap or on a natural pause, whichever comes first, so the
 * common case is a single tap followed by speaking.
 */
@HiltViewModel
class VoiceTranslationViewModel @Inject constructor(
    private val recorder: PushToTalkRecorder,
    private val translateSpeech: TranslateSpeechUseCase,
    private val speakText: SpeakTextUseCase,
    private val settingsRepository: SettingsRepository,
    networkMonitor: NetworkMonitor,
) : ViewModel() {

    private val _uiState = MutableStateFlow(VoiceUiState())
    val uiState: StateFlow<VoiceUiState> = _uiState.asStateFlow()

    val settings: StateFlow<AppSettings> = settingsRepository.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = AppSettings(),
    )

    val isOnline: StateFlow<Boolean> = networkMonitor.isOnline.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = networkMonitor.isCurrentlyOnline(),
    )

    private var captureJob: Job? = null

    fun toggleRecording() {
        if (_uiState.value.isRecording) stopRecording() else startRecording()
    }

    private fun startRecording() {
        captureJob?.cancel()
        _uiState.update {
            it.copy(
                pipelineState = PipelineState.Listening(),
                transcript = "",
                translation = "",
                error = null,
            )
        }

        captureJob = viewModelScope.launch {
            recorder.capture().collect { event ->
                when (event) {
                    is CaptureEvent.Amplitude ->
                        _uiState.update {
                            it.copy(
                                amplitude = event.level,
                                pipelineState = PipelineState.Listening(event.level),
                            )
                        }

                    is CaptureEvent.SpeechDetected -> Unit

                    is CaptureEvent.Completed -> processCapture(event.wav)

                    is CaptureEvent.Failed ->
                        _uiState.update {
                            it.copy(
                                pipelineState = PipelineState.Error(event.error),
                                error = event.error,
                            )
                        }
                }
            }
        }
    }

    fun stopRecording() {
        recorder.requestStop()
    }

    private suspend fun processCapture(wav: ByteArray) {
        _uiState.update { it.copy(pipelineState = PipelineState.Processing, amplitude = 0f) }

        val activeSettings = settingsRepository.current()
        val result = translateSpeech(
            wavAudio = wav,
            sourceLanguage = activeSettings.sourceLanguage,
            targetLanguage = activeSettings.targetLanguage,
            mode = TranslationMode.VOICE,
        )

        when (result) {
            is AppResult.Failure ->
                _uiState.update {
                    it.copy(
                        pipelineState = PipelineState.Error(result.error),
                        error = result.error,
                    )
                }

            is AppResult.Success ->
                _uiState.update {
                    it.copy(
                        pipelineState = PipelineState.Idle,
                        transcript = result.data.transcript,
                        translation = result.data.result.translatedText,
                        error = null,
                    )
                }
        }
    }

    fun replay() {
        viewModelScope.launch {
            val text = _uiState.value.translation
            if (text.isBlank()) return@launch

            _uiState.update { it.copy(pipelineState = PipelineState.Speaking) }
            speakText(text, settingsRepository.current().targetLanguage, force = true)
            _uiState.update { it.copy(pipelineState = PipelineState.Idle) }
        }
    }

    fun setSourceLanguage(language: Language) {
        viewModelScope.launch {
            settingsRepository.setSourceLanguage(language)
        }
    }

    fun setTargetLanguage(language: Language) {
        viewModelScope.launch {
            settingsRepository.setTargetLanguage(language)
        }
    }

    fun swapLanguages() {
        viewModelScope.launch { settingsRepository.swapLanguages() }
    }

    fun dismissError() {
        _uiState.update { it.copy(error = null) }
    }

    override fun onCleared() {
        super.onCleared()
        recorder.requestStop()
        captureJob?.cancel()
    }

    private companion object {
        const val STOP_TIMEOUT_MILLIS = 5_000L
    }
}
