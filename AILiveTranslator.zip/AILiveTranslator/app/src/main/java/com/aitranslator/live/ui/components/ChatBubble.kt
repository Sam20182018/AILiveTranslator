package com.aitranslator.live.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aitranslator.live.R
import com.aitranslator.live.core.domain.model.ConversationTurn
import com.aitranslator.live.core.domain.model.Speaker

/**
 * One conversation turn: what was said, and underneath it what the other person hears.
 *
 * Person A is left-aligned, Person B right-aligned, so a bystander can follow the exchange
 * without reading the language labels.
 */
@Composable
fun ConversationBubble(
    turn: ConversationTurn,
    onSpeak: (String) -> Unit,
    onCopy: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val isPersonA = turn.speaker == Speaker.PERSON_A
    val alignment = if (isPersonA) Alignment.Start else Alignment.End

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = alignment,
    ) {
        val speakerLabel = if (isPersonA) {
            stringResource(R.string.conversation_person_a)
        } else {
            stringResource(R.string.conversation_person_b)
        }

        Text(
            text = "$speakerLabel · ${turn.sourceLanguage.displayLabel}",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
        )

        Surface(
            color = if (isPersonA) {
                MaterialTheme.colorScheme.surfaceVariant
            } else {
                MaterialTheme.colorScheme.secondaryContainer
            },
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (isPersonA) 4.dp else 18.dp,
                bottomEnd = if (isPersonA) 18.dp else 4.dp,
            ),
            modifier = Modifier.widthIn(max = 320.dp),
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = turn.originalText,
                    style = MaterialTheme.typography.bodyLarge
                        .withDirectionOf(turn.sourceLanguage),
                    color = MaterialTheme.colorScheme.onSurface,
                )

                if (turn.isTranslating) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(top = 10.dp),
                    ) {
                        CircularProgressIndicator(
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(14.dp),
                        )
                        Text(
                            text = stringResource(R.string.status_translating),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                } else if (turn.translatedText.isNotBlank()) {
                    Text(
                        text = turn.translatedText,
                        style = MaterialTheme.typography.bodyLarge
                            .withDirectionOf(turn.targetLanguage),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 10.dp),
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(onClick = { onSpeak(turn.translatedText) }) {
                            Icon(
                                imageVector = Icons.Filled.VolumeUp,
                                contentDescription = stringResource(R.string.action_play),
                            )
                        }
                        IconButton(onClick = { onCopy(turn.translatedText) }) {
                            Icon(
                                imageVector = Icons.Filled.ContentCopy,
                                contentDescription = stringResource(R.string.action_copy),
                            )
                        }
                    }
                }

                turn.errorMessage?.let { message ->
                    Text(
                        text = message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
            }
        }
    }
}
