package com.aitranslator.live.ui.common

import android.content.Context
import com.aitranslator.live.R
import com.aitranslator.live.core.common.AppError

/**
 * The only place where an [AppError] becomes text a person reads.
 *
 * Technical detail deliberately never reaches this function's output — it stays in the
 * debug log — so users get an instruction ("check your key in Settings") rather than an
 * HTTP status code.
 */
fun AppError.toUserMessage(context: Context): String = when (this) {
    is AppError.NoInternet -> context.getString(R.string.error_no_internet)

    is AppError.InvalidApiKey ->
        context.getString(R.string.error_invalid_key, provider.replaceFirstChar { it.uppercase() })

    is AppError.NotConfigured ->
        context.getString(R.string.error_not_configured, provider.replaceFirstChar { it.uppercase() })

    is AppError.RateLimited -> retryAfterSeconds?.let {
        context.getString(R.string.error_rate_limited_seconds, it.toInt())
    } ?: context.getString(R.string.error_rate_limited)

    is AppError.ServerError -> context.getString(R.string.error_server)

    is AppError.Timeout -> context.getString(R.string.error_timeout)

    is AppError.UnsupportedLanguage -> context.getString(R.string.error_unsupported_language)

    is AppError.ModelUnavailable -> context.getString(R.string.error_model_unavailable)

    is AppError.AudioCapture -> context.getString(R.string.error_audio_capture)

    is AppError.AudioPlayback -> context.getString(R.string.error_audio_playback)

    is AppError.PermissionDenied ->
        context.getString(R.string.error_permission, permission.substringAfterLast('.'))

    is AppError.CapabilityUnavailable ->
        context.getString(R.string.error_capability, capability)

    is AppError.EmptyInput -> context.getString(R.string.error_empty_input)

    is AppError.Unknown -> context.getString(R.string.error_unknown)
}
