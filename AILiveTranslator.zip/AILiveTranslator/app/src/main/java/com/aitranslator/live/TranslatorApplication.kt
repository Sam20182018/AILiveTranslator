package com.aitranslator.live

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.aitranslator.live.core.common.Logger
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class TranslatorApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // Debug logging is opt-in per build type; release builds stay silent, and the
        // Logger redacts anything that looks like a credential either way.
        Logger.debugEnabled = BuildConfig.DEBUG_LOG

        createAssistNotificationChannel()
    }

    private fun createAssistNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        val manager = getSystemService(NotificationManager::class.java) ?: return
        val channel = NotificationChannel(
            ASSIST_CHANNEL_ID,
            getString(R.string.assist_channel_name),
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = getString(R.string.assist_channel_description)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    companion object {
        const val ASSIST_CHANNEL_ID = "assist_listening"
    }
}
