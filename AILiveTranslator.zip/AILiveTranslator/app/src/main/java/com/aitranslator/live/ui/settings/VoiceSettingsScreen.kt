package com.aitranslator.live.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aitranslator.live.R
import com.aitranslator.live.core.domain.model.TtsEngine
import com.aitranslator.live.core.domain.model.VoiceGender
import com.aitranslator.live.core.domain.model.VoiceProfile
import com.aitranslator.live.ui.common.toUserMessage
import com.aitranslator.live.ui.components.TranslatorScaffold

@Composable
fun VoiceSettingsScreen(
    onBack: () -> Unit,
    viewModel: VoiceSettingsViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.error) {
        uiState.error?.let { error ->
            snackbarHostState.showSnackbar(error.toUserMessage(context))
            viewModel.dismissError()
        }
    }

    TranslatorScaffold(
        title = stringResource(R.string.settings_voice),
        onBack = onBack,
        snackbarHostState = snackbarHostState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
        ) {
            SectionTitle(stringResource(R.string.settings_voice))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = uiState.genderFilter == null,
                    onClick = { viewModel.setGenderFilter(null) },
                    label = { Text("All") },
                )
                FilterChip(
                    selected = uiState.genderFilter == VoiceGender.MALE,
                    onClick = { viewModel.setGenderFilter(VoiceGender.MALE) },
                    label = { Text("Male") },
                )
                FilterChip(
                    selected = uiState.genderFilter == VoiceGender.FEMALE,
                    onClick = { viewModel.setGenderFilter(VoiceGender.FEMALE) },
                    label = { Text("Female") },
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (uiState.isLoading) {
                CircularProgressIndicator(modifier = Modifier.padding(16.dp))
            }

            uiState.filteredVoices.forEach { voice ->
                VoiceRow(
                    voice = voice,
                    isSelected = settings.selectedVoiceId == voice.id,
                    isPreviewing = uiState.previewingVoiceId == voice.id,
                    onSelect = { viewModel.selectVoice(voice) },
                    onPreview = { viewModel.preview(voice) },
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            LabelledSlider(
                label = stringResource(R.string.settings_speech_speed),
                value = settings.speechSpeed,
                valueRange = 0.5f..2.0f,
                onValueChange = viewModel::setSpeed,
            )

            LabelledSlider(
                label = stringResource(R.string.settings_speech_volume),
                value = settings.speechVolume,
                valueRange = 0f..1f,
                onValueChange = viewModel::setVolume,
            )

            Text(
                text = "Cloud voices need an OpenAI key. Device voices work offline but " +
                    "depend on which language packs your phone has installed.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 12.dp),
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun VoiceRow(
    voice: VoiceProfile,
    isSelected: Boolean,
    isPreviewing: Boolean,
    onSelect: () -> Unit,
    onPreview: () -> Unit,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .selectable(selected = isSelected, onClick = onSelect)
            .padding(vertical = 6.dp),
    ) {
        RadioButton(selected = isSelected, onClick = onSelect)

        Column(modifier = Modifier.weight(1f)) {
            Text(text = voice.displayName, style = MaterialTheme.typography.bodyLarge)
            Text(
                text = buildString {
                    append(if (voice.engine == TtsEngine.OPENAI) "Cloud" else "Device")
                    if (voice.description.isNotBlank()) append(" · ${voice.description}")
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        if (isPreviewing) {
            CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
        } else {
            IconButton(onClick = onPreview) {
                Icon(
                    imageVector = Icons.Filled.PlayArrow,
                    contentDescription = stringResource(R.string.action_preview_voice),
                )
            }
        }
    }
}
