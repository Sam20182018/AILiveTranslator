package com.aitranslator.live.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aitranslator.live.R
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.LatencyProfile
import com.aitranslator.live.core.domain.model.ThemeMode
import com.aitranslator.live.ui.components.LanguageSelectorRow
import com.aitranslator.live.ui.components.TranslatorScaffold

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onOpenApiKeys: () -> Unit,
    onOpenVoiceSettings: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel(),
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    TranslatorScaffold(title = stringResource(R.string.settings_title), onBack = onBack) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
        ) {
            SectionTitle(stringResource(R.string.settings_ai_provider))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (listOf(AiProvider.AUTO) + AiProvider.concreteProviders).forEach { provider ->
                    FilterChip(
                        selected = settings.activeProvider == provider,
                        onClick = { viewModel.setProvider(provider) },
                        label = { Text(provider.displayName) },
                    )
                }
            }

            Text(
                text = "Auto picks the first provider that has a working key, preferring the " +
                    "one that can also handle speech.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp),
            )

            NavigationRow(
                title = stringResource(R.string.settings_api_keys),
                subtitle = "Gemini · Claude · OpenAI",
                onClick = onOpenApiKeys,
            )

            NavigationRow(
                title = stringResource(R.string.settings_voice),
                subtitle = "10 cloud voices, device voices, speed and volume",
                onClick = onOpenVoiceSettings,
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            SectionTitle(stringResource(R.string.settings_languages))

            LanguageSelectorRow(
                source = settings.sourceLanguage,
                target = settings.targetLanguage,
                onSourceSelected = viewModel::setSourceLanguage,
                onTargetSelected = viewModel::setTargetLanguage,
                onSwap = viewModel::swapLanguages,
                modifier = Modifier.fillMaxWidth(),
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            SectionTitle(stringResource(R.string.settings_voice_translation))

            SwitchRow(
                title = stringResource(R.string.settings_voice_translation),
                checked = settings.voiceTranslationEnabled,
                onCheckedChange = viewModel::setVoiceTranslationEnabled,
            )
            SwitchRow(
                title = stringResource(R.string.settings_auto_play),
                checked = settings.autoPlayTranslation,
                onCheckedChange = viewModel::setAutoPlay,
            )
            SwitchRow(
                title = stringResource(R.string.settings_show_original),
                checked = settings.showOriginalText,
                onCheckedChange = viewModel::setShowOriginalText,
            )
            SwitchRow(
                title = stringResource(R.string.settings_show_translation),
                checked = settings.showTranslation,
                onCheckedChange = viewModel::setShowTranslation,
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            SectionTitle(stringResource(R.string.settings_privacy))

            SwitchRow(
                title = stringResource(R.string.settings_save_history),
                checked = settings.saveHistory,
                onCheckedChange = viewModel::setSaveHistory,
            )
            SwitchRow(
                title = stringResource(R.string.settings_save_audio),
                subtitle = stringResource(R.string.settings_save_audio_note),
                checked = settings.saveAudio,
                onCheckedChange = viewModel::setSaveAudio,
            )
            SwitchRow(
                title = stringResource(R.string.settings_cache),
                subtitle = stringResource(R.string.settings_cache_note),
                checked = settings.translationCacheEnabled,
                onCheckedChange = viewModel::setCacheEnabled,
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            SectionTitle(stringResource(R.string.settings_performance))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LatencyProfile.entries.forEach { profile ->
                    FilterChip(
                        selected = settings.latencyProfile == profile,
                        onClick = { viewModel.setLatencyProfile(profile) },
                        label = { Text(profile.id.replace('_', ' ')) },
                    )
                }
            }

            Text(
                text = "Low latency uses the streaming realtime session when an OpenAI key " +
                    "is available, and shortens the pause that ends an utterance.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp),
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            SectionTitle(stringResource(R.string.settings_appearance))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = settings.themeMode == mode,
                        onClick = { viewModel.setThemeMode(mode) },
                        label = { Text(mode.id) },
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
internal fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 16.dp, bottom = 8.dp),
    )
}

@Composable
internal fun SwitchRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    subtitle: String? = null,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyLarge)
            subtitle?.let {
                Text(
                    text = it,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun NavigationRow(title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyLarge)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
        )
    }
}

/** Reusable labelled slider used by the voice settings screen. */
@Composable
internal fun LabelledSlider(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(
            text = "$label: ${"%.2f".format(value)}",
            style = MaterialTheme.typography.bodyLarge,
        )
        Slider(value = value, onValueChange = onValueChange, valueRange = valueRange)
    }
}
