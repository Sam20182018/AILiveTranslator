package com.aitranslator.live.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aitranslator.live.R
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.ApiKeyEntry
import com.aitranslator.live.core.domain.model.ProviderCapabilities
import com.aitranslator.live.ui.common.toUserMessage
import com.aitranslator.live.ui.components.TranslatorScaffold

/**
 * Key management.
 *
 * A key is only ever shown masked unless the user explicitly reveals what they are typing,
 * the draft is dropped from memory the moment it is saved, and the stored value is
 * encrypted with an Android Keystore key.
 */
@Composable
fun ApiKeysScreen(
    onBack: () -> Unit,
    viewModel: ApiKeysViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val entries by viewModel.entries.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.error) {
        uiState.error?.let { error ->
            snackbarHostState.showSnackbar(error.toUserMessage(context))
            viewModel.dismissError()
        }
    }

    LaunchedEffect(uiState.message) {
        uiState.message?.let { message ->
            val text = when (message) {
                "saved" -> context.getString(R.string.settings_key_saved)
                "deleted" -> context.getString(R.string.settings_key_deleted)
                else -> message
            }
            snackbarHostState.showSnackbar(text)
            viewModel.consumeMessage()
        }
    }

    TranslatorScaffold(
        title = stringResource(R.string.settings_api_keys),
        onBack = onBack,
        snackbarHostState = snackbarHostState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            Text(
                text = "Keys are encrypted with a key held in the Android Keystore and are " +
                    "never written to logs or backups.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Spacer(modifier = Modifier.height(16.dp))

            AiProvider.concreteProviders.forEach { provider ->
                ProviderCard(
                    provider = provider,
                    entry = entries.firstOrNull { it.provider == provider },
                    editor = uiState.editors[provider] ?: ProviderEditorState(),
                    modelPlaceholder = settings.modelOverrides[provider]
                        ?: viewModel.defaultModel(provider),
                    suggestions = viewModel.modelSuggestions(provider),
                    onKeyChanged = { viewModel.onKeyDraftChanged(provider, it) },
                    onToggleVisibility = { viewModel.toggleKeyVisibility(provider) },
                    onSaveKey = { viewModel.saveKey(provider) },
                    onDeleteKey = { viewModel.deleteKey(provider) },
                    onTest = { viewModel.test(provider) },
                    onActiveChanged = { viewModel.setActive(provider, it) },
                    onModelChanged = { viewModel.onModelDraftChanged(provider, it) },
                    onSaveModel = { viewModel.saveModel(provider) },
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ProviderCard(
    provider: AiProvider,
    entry: ApiKeyEntry?,
    editor: ProviderEditorState,
    modelPlaceholder: String,
    suggestions: List<String>,
    onKeyChanged: (String) -> Unit,
    onToggleVisibility: () -> Unit,
    onSaveKey: () -> Unit,
    onDeleteKey: () -> Unit,
    onTest: () -> Unit,
    onActiveChanged: (Boolean) -> Unit,
    onModelChanged: (String) -> Unit,
    onSaveModel: () -> Unit,
) {
    val capabilities = ProviderCapabilities.of(provider)

    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = provider.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = stringResource(R.string.settings_active),
                    style = MaterialTheme.typography.bodyMedium,
                )
                Switch(
                    checked = entry?.isActive == true,
                    onCheckedChange = onActiveChanged,
                    enabled = entry?.isStored == true,
                )
            }

            Text(
                text = buildString {
                    append("Translation")
                    if (capabilities.speechToText) append(" · Speech-to-text")
                    if (capabilities.textToSpeech) append(" · Text-to-speech")
                    if (capabilities.realtimeDuplex) append(" · Realtime")
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            if (entry?.isStored == true && entry.maskedKey.isNotBlank()) {
                Text(
                    text = "Saved key: ${entry.maskedKey}",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            OutlinedTextField(
                value = editor.draftKey,
                onValueChange = onKeyChanged,
                label = { Text("${provider.displayName} API key") },
                singleLine = true,
                visualTransformation = if (editor.isKeyVisible) {
                    VisualTransformation.None
                } else {
                    PasswordVisualTransformation()
                },
                trailingIcon = {
                    IconButton(onClick = onToggleVisibility) {
                        Icon(
                            imageVector = if (editor.isKeyVisible) {
                                Icons.Filled.VisibilityOff
                            } else {
                                Icons.Filled.Visibility
                            },
                            contentDescription = stringResource(
                                if (editor.isKeyVisible) {
                                    R.string.settings_hide_key
                                } else {
                                    R.string.settings_show_key
                                },
                            ),
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 8.dp),
            ) {
                Button(onClick = onSaveKey, enabled = editor.draftKey.isNotBlank()) {
                    Text(stringResource(R.string.action_save))
                }
                OutlinedButton(onClick = onTest, enabled = !editor.isTesting) {
                    if (editor.isTesting) {
                        CircularProgressIndicator(
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.size(6.dp))
                    }
                    Text(stringResource(R.string.action_test_connection))
                }
                TextButton(onClick = onDeleteKey, enabled = entry?.isStored == true) {
                    Text(stringResource(R.string.action_delete))
                }
            }

            editor.testSucceeded?.let { succeeded ->
                Text(
                    text = if (succeeded) {
                        stringResource(R.string.settings_connection_ok)
                    } else {
                        stringResource(R.string.error_unknown)
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (succeeded) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.error
                    },
                )
            }

            OutlinedTextField(
                value = editor.modelDraft,
                onValueChange = onModelChanged,
                label = { Text(stringResource(R.string.settings_model_hint)) },
                placeholder = { Text(modelPlaceholder) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(top = 8.dp),
            ) {
                suggestions.take(3).forEach { suggestion ->
                    AssistChip(
                        onClick = { onModelChanged(suggestion) },
                        label = { Text(suggestion, style = MaterialTheme.typography.labelLarge) },
                    )
                }
            }

            TextButton(onClick = onSaveModel, modifier = Modifier.padding(top = 4.dp)) {
                Text(stringResource(R.string.action_save))
            }
        }
    }
}
