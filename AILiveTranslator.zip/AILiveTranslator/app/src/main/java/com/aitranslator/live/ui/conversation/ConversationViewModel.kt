package com.aitranslator.live.ui.conversation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aitranslator.live.core.audio.recorder.CaptureEvent
import com.aitranslator.live.core.audio.recorder.PushToTalkRecorder
import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.common.NetworkMonitor
import com.aitranslator.live.core.domain.model.AppSettings
import com.aitranslator.live.core.domain.model.ConversationTurn
import com.aitranslator.live.core.domain.model.ConversationTurnMode
import com.aitranslator.live.core.domain.model.HistoryEntry
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.PipelineState
import com.aitranslator.live.core.domain.model.Speaker
import com.aitranslator.live.core.domain.model.TranslationMode
import com.aitranslator.live.core.domain.model.TranslationRequest
import com.aitranslator.live.core.domain.repository.HistoryRepository
import com.aitranslator.live.core.domain.repository.SettingsRepository
import com.aitranslator.live.core.domain.repository.SpeechRepository
import com.aitranslator.live.core.domain.usecase.SpeakTextUseCase
import com.aitranslator.live.core.domain.usecase.TranslateTextUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

data class ConversationUiState(
    val turns: List<ConversationTurn> = emptyList(),
    val pipelineState: PipelineState = PipelineState.Idle,
    val amplitude: Float = 0f,
    val activeSpeaker: Speaker? = null,
    val turnMode: ConversationTurnMode = ConversationTurnMode.MANUAL,
    val isSessionRunning: Boolean = false,
    val error: AppError? = null,
) {
    val isRecording: Boolean get() = activeSpeaker != null
}

/**
 * Face-to-face mode.
 *
 * Manual is the default because it is unambiguous: each person taps their own button.
 * Automatic keeps the microphone open and infers the speaker — see [detectSpeaker] for
 * exactly how far that inference is trusted.
 */
@HiltViewModel
class ConversationViewModel @Inject constructor(
    private val recorder: PushToTalkRecorder,
    private val speechRepository: SpeechRepository,
    private val translateText: TranslateTextUseCase,
    private val speakText: SpeakTextUseCase,
    private val settingsRepository: SettingsRepository,
    private val historyRepository: HistoryRepository,
    networkMonitor: NetworkMonitor,
) : ViewModel() {

    private val _uiState = MutableStateFlow(ConversationUiState())
    val uiState: StateFlow<ConversationUiState> = _uiState.asStateFlow()

    val settings: StateFlow<AppSettings> = settingsRepository.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = AppSettings(),
    )

    val isOnline: StateFlow<Boolean> = networkMonitor.isOnline.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = networkMonitor.isCurrentlyOnline(),
    )

    private var captureJob: Job? = null
    private var lastSpeaker: Speaker = Speaker.PERSON_B

    init {
        viewModelScope.launch {
            _uiState.update { it.copy(turnMode = settingsRepository.current().conversationTurnMode) }
        }
    }

    fun setTurnMode(mode: ConversationTurnMode) {
        stopEverything()
        _uiState.update { it.copy(turnMode = mode) }
        viewModelScope.launch { settingsRepository.setConversationTurnMode(mode) }
    }

    fun setLanguages(personA: Language, personB: Language) {
        viewModelScope.launch { settingsRepository.setConversationLanguages(personA, personB) }
    }

    /** Manual mode: the given person holds the floor. */
    fun toggleSpeaker(speaker: Speaker) {
        if (_uiState.value.activeSpeaker == speaker) {
            recorder.requestStop()
            return
        }
        if (_uiState.value.activeSpeaker != null) {
            recorder.requestStop()
            return
        }
        startCapture(speaker)
    }

    /** Automatic mode: keep the microphone open and infer who spoke. */
    fun toggleAutoSession() {
        if (_uiState.value.isSessionRunning) {
            stopEverything()
        } else {
            _uiState.update { it.copy(isSessionRunning = true) }
            startCapture(speaker = null)
        }
    }

    /**
     * One job drives the whole capture. Automatic mode loops inside that job rather than
     * re-entering [startCapture], because restarting from inside the collector would cancel
     * the coroutine that is doing the collecting.
     */
    private fun startCapture(speaker: Speaker?) {
        captureJob?.cancel()
        captureJob = viewModelScope.launch {
            if (speaker != null) {
                runOneCapture(speaker)
            } else {
                while (isActive && _uiState.value.isSessionRunning) {
                    runOneCapture(null)
                }
            }
        }
    }

    private suspend fun runOneCapture(speaker: Speaker?) {
        _uiState.update {
            it.copy(
                activeSpeaker = speaker,
                pipelineState = PipelineState.Listening(),
                error = null,
            )
        }

        var captured: ByteArray? = null
        var failed = false

        recorder.capture().collect { event ->
            when (event) {
                is CaptureEvent.Amplitude ->
                    _uiState.update {
                        it.copy(
                            amplitude = event.level,
                            pipelineState = PipelineState.Listening(event.level),
                        )
                    }

                is CaptureEvent.SpeechDetected -> Unit

                is CaptureEvent.Completed -> captured = event.wav

                is CaptureEvent.Failed -> {
                    failed = true
                    _uiState.update {
                        it.copy(
                            activeSpeaker = null,
                            isSessionRunning = false,
                            pipelineState = PipelineState.Error(event.error),
                            error = event.error,
                        )
                    }
                }
            }
        }

        _uiState.update { it.copy(activeSpeaker = null, amplitude = 0f) }

        val wav = captured
        if (!failed && wav != null) {
            processUtterance(wav, speaker)
        }
    }

    private suspend fun processUtterance(wav: ByteArray, forcedSpeaker: Speaker?) {
        val activeSettings = settingsRepository.current()
        val languageA = activeSettings.conversationLanguageA
        val languageB = activeSettings.conversationLanguageB

        _uiState.update { it.copy(pipelineState = PipelineState.Processing) }

        // In automatic mode we do not yet know the language, so the previous speaker's
        // language is used as the recognition hint and the result is re-checked below.
        val hintLanguage = when (forcedSpeaker) {
            Speaker.PERSON_A -> languageA
            Speaker.PERSON_B -> languageB
            null -> if (lastSpeaker == Speaker.PERSON_A) languageB else languageA
        }

        val transcriptResult = speechRepository.transcribe(wav, hintLanguage)
        val transcript = when (transcriptResult) {
            is AppResult.Failure -> {
                _uiState.update {
                    it.copy(
                        pipelineState = PipelineState.Error(transcriptResult.error),
                        error = transcriptResult.error,
                    )
                }
                return
            }

            is AppResult.Success -> transcriptResult.data.trim()
        }

        if (transcript.isEmpty()) {
            _uiState.update { it.copy(pipelineState = PipelineState.Idle) }
            return
        }

        val speaker = forcedSpeaker ?: detectSpeaker(transcript, languageA, languageB)
        lastSpeaker = speaker

        val source = if (speaker == Speaker.PERSON_A) languageA else languageB
        val target = if (speaker == Speaker.PERSON_A) languageB else languageA

        val turnId = UUID.randomUUID().toString()
        val pendingTurn = ConversationTurn(
            id = turnId,
            speaker = speaker,
            sourceLanguage = source,
            targetLanguage = target,
            originalText = transcript,
            translatedText = "",
            timestampMillis = System.currentTimeMillis(),
            isTranslating = true,
        )
        _uiState.update {
            it.copy(turns = it.turns + pendingTurn, pipelineState = PipelineState.Translating)
        }

        val context = _uiState.value.turns
            .takeLast(CONTEXT_TURNS)
            .map { "${it.sourceLanguage.englishName}: ${it.originalText}" }

        val translation = translateText(
            TranslationRequest(
                text = transcript,
                sourceLanguage = source,
                targetLanguage = target,
                mode = TranslationMode.CONVERSATION,
                context = context,
            ),
        )

        when (translation) {
            is AppResult.Failure -> {
                _uiState.update { state ->
                    state.copy(
                        pipelineState = PipelineState.Idle,
                        error = translation.error,
                        turns = state.turns.map { turn ->
                            if (turn.id == turnId) {
                                turn.copy(isTranslating = false, errorMessage = "—")
                            } else {
                                turn
                            }
                        },
                    )
                }
            }

            is AppResult.Success -> {
                val text = translation.data.translatedText
                _uiState.update { state ->
                    state.copy(
                        pipelineState = PipelineState.Idle,
                        turns = state.turns.map { turn ->
                            if (turn.id == turnId) {
                                turn.copy(isTranslating = false, translatedText = text)
                            } else {
                                turn
                            }
                        },
                    )
                }

                historyRepository.add(
                    HistoryEntry(
                        timestampMillis = System.currentTimeMillis(),
                        sourceLanguage = source,
                        targetLanguage = target,
                        originalText = transcript,
                        translatedText = text,
                        mode = TranslationMode.CONVERSATION,
                        provider = translation.data.provider,
                    ),
                )

                if (activeSettings.voiceTranslationEnabled && activeSettings.autoPlayTranslation) {
                    _uiState.update { it.copy(pipelineState = PipelineState.Speaking) }
                    speakText(text, target, force = true)
                    _uiState.update { it.copy(pipelineState = PipelineState.Idle) }
                }
            }
        }
    }

    /**
     * Speaker inference for automatic mode.
     *
     * When the two languages use different scripts (e.g. Persian vs German) the script of
     * the transcript is a reliable signal. When they share a script there is no dependable
     * cue from text alone, so the turn simply alternates — which is what actually happens
     * in a face-to-face conversation. This is intentionally a heuristic, and manual mode
     * exists precisely for when it is not good enough.
     */
    private fun detectSpeaker(
        transcript: String,
        languageA: Language,
        languageB: Language,
    ): Speaker {
        if (languageA.isRtl != languageB.isRtl) {
            val hasRtl = transcript.any { it in ARABIC_BLOCK || it in ARABIC_SUPPLEMENT }
            return if (hasRtl == languageA.isRtl) Speaker.PERSON_A else Speaker.PERSON_B
        }
        return lastSpeaker.other()
    }

    fun speak(text: String, language: Language) {
        viewModelScope.launch { speakText(text, language, force = true) }
    }

    fun clearConversation() {
        _uiState.update { it.copy(turns = emptyList()) }
    }

    fun stopEverything() {
        recorder.requestStop()
        captureJob?.cancel()
        captureJob = null
        _uiState.update {
            it.copy(
                activeSpeaker = null,
                isSessionRunning = false,
                amplitude = 0f,
                pipelineState = PipelineState.Idle,
            )
        }
    }

    fun dismissError() {
        _uiState.update { it.copy(error = null) }
    }

    override fun onCleared() {
        super.onCleared()
        stopEverything()
    }

    private companion object {
        const val STOP_TIMEOUT_MILLIS = 5_000L
        const val CONTEXT_TURNS = 4
        val ARABIC_BLOCK = '\u0600'..'\u06FF'
        val ARABIC_SUPPLEMENT = '\uFB50'..'\uFDFF'
    }
}
