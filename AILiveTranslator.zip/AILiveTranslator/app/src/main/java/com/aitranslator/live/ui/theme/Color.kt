package com.aitranslator.live.ui.theme

import androidx.compose.ui.graphics.Color

val Indigo10 = Color(0xFF11133A)
val Indigo20 = Color(0xFF1D2159)
val Indigo30 = Color(0xFF2C3178)
val Indigo40 = Color(0xFF3F46A0)
val Indigo80 = Color(0xFFBEC2FF)
val Indigo90 = Color(0xFFE0E1FF)

val Teal10 = Color(0xFF00201C)
val Teal20 = Color(0xFF003731)
val Teal30 = Color(0xFF005048)
val Teal40 = Color(0xFF00695F)
val Teal80 = Color(0xFF6FDBCB)
val Teal90 = Color(0xFF8FF8E7)

val Amber40 = Color(0xFF8A5300)
val Amber80 = Color(0xFFFFB868)

val Red10 = Color(0xFF410002)
val Red20 = Color(0xFF690005)
val Red30 = Color(0xFF93000A)
val Red40 = Color(0xFFBA1A1A)
val Red80 = Color(0xFFFFB4AB)
val Red90 = Color(0xFFFFDAD6)

val Neutral10 = Color(0xFF1A1B20)
val Neutral20 = Color(0xFF2F3036)
val Neutral30 = Color(0xFF45464D)
val Neutral50 = Color(0xFF767680)
val Neutral60 = Color(0xFF90909A)
val Neutral80 = Color(0xFFC7C6D0)
val Neutral90 = Color(0xFFE4E1E9)
val Neutral95 = Color(0xFFF2F0F7)
val Neutral99 = Color(0xFFFDFBFF)

/** Semantic colours for the connectivity pill and pipeline state chips. */
val OnlineGreen = Color(0xFF2E7D32)
val OfflineRed = Color(0xFFC62828)
val ListeningBlue = Color(0xFF1565C0)
val SpeakingPurple = Color(0xFF6A1B9A)
