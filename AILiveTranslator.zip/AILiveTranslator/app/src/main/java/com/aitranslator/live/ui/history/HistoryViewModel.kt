package com.aitranslator.live.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.audio.AudioPlayer
import com.aitranslator.live.core.domain.model.HistoryEntry
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.repository.HistoryRepository
import com.aitranslator.live.core.domain.repository.SettingsRepository
import com.aitranslator.live.core.domain.usecase.SpeakTextUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val historyRepository: HistoryRepository,
    private val speakText: SpeakTextUseCase,
    private val audioPlayer: AudioPlayer,
    settingsRepository: SettingsRepository,
) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val entries: StateFlow<List<HistoryEntry>> = _query
        .flatMapLatest { historyRepository.observeHistory(it) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = emptyList(),
        )

    val isHistoryEnabled: StateFlow<Boolean> = settingsRepository.settings
        .map { it.saveHistory }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = true,
        )

    fun onQueryChanged(value: String) {
        _query.value = value
    }

    fun delete(id: Long) {
        viewModelScope.launch { historyRepository.delete(id) }
    }

    fun deleteAll() {
        viewModelScope.launch { historyRepository.deleteAll() }
    }

    /**
     * Replays the saved clip when one exists, otherwise re-synthesises the text. Saved
     * audio is the exception rather than the rule, since audio saving is off by default.
     */
    fun replay(entry: HistoryEntry) {
        viewModelScope.launch {
            val path = entry.audioFilePath
            if (!path.isNullOrBlank()) {
                val played = audioPlayer.playFile(path, volume = 1f)
                if (played is AppResult.Success) return@launch
            }
            speakText(entry.translatedText, entry.targetLanguage, force = true)
        }
    }

    fun speak(text: String, language: Language) {
        viewModelScope.launch { speakText(text, language, force = true) }
    }

    private companion object {
        const val STOP_TIMEOUT_MILLIS = 5_000L
    }
}
