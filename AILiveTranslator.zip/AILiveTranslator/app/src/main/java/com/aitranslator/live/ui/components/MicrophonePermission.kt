package com.aitranslator.live.ui.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat

/**
 * Requests `RECORD_AUDIO` at the moment it is first needed rather than at launch, which is
 * both the platform recommendation and what makes users grant it.
 */
class MicrophonePermissionState internal constructor(
    val hasPermission: Boolean,
    private val request: () -> Unit,
) {
    /** Runs [action] if permission is already granted, otherwise asks for it first. */
    fun runOrRequest(action: () -> Unit) {
        if (hasPermission) action() else request()
    }
}

@Composable
fun rememberMicrophonePermission(
    onGranted: () -> Unit = {},
    onDenied: () -> Unit = {},
): MicrophonePermissionState {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(context.hasMicrophonePermission()) }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { isGranted ->
        granted = isGranted
        if (isGranted) onGranted() else onDenied()
    }

    return MicrophonePermissionState(
        hasPermission = granted,
        request = { launcher.launch(Manifest.permission.RECORD_AUDIO) },
    )
}

fun Context.hasMicrophonePermission(): Boolean =
    ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED
