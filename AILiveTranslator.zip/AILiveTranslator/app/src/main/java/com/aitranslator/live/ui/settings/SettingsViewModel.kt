package com.aitranslator.live.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aitranslator.live.core.domain.model.AiModelConfig
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.AppSettings
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.LatencyProfile
import com.aitranslator.live.core.domain.model.ThemeMode
import com.aitranslator.live.core.domain.repository.HistoryRepository
import com.aitranslator.live.core.domain.repository.SettingsRepository
import com.aitranslator.live.core.domain.repository.TranslationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val translationRepository: TranslationRepository,
    private val historyRepository: HistoryRepository,
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = AppSettings(),
    )

    fun setProvider(provider: AiProvider) {
        viewModelScope.launch { settingsRepository.setActiveProvider(provider) }
    }

    fun setModelOverride(provider: AiProvider, model: String) {
        viewModelScope.launch { settingsRepository.setModelOverride(provider, model) }
    }

    fun defaultModelFor(provider: AiProvider): String =
        AiModelConfig.defaultFor(provider).translationModel

    fun modelSuggestionsFor(provider: AiProvider): List<String> =
        AiModelConfig.suggestionsFor(provider)

    fun setSourceLanguage(language: Language) {
        viewModelScope.launch { settingsRepository.setSourceLanguage(language) }
    }

    fun setTargetLanguage(language: Language) {
        viewModelScope.launch { settingsRepository.setTargetLanguage(language) }
    }

    fun swapLanguages() {
        viewModelScope.launch { settingsRepository.swapLanguages() }
    }

    fun setVoiceTranslationEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setVoiceTranslationEnabled(enabled) }
    }

    fun setAutoPlay(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setAutoPlayTranslation(enabled) }
    }

    fun setShowOriginalText(show: Boolean) {
        viewModelScope.launch { settingsRepository.setShowOriginalText(show) }
    }

    fun setShowTranslation(show: Boolean) {
        viewModelScope.launch { settingsRepository.setShowTranslation(show) }
    }

    fun setSaveHistory(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setSaveHistory(enabled)
            // Turning history off should also remove what is already stored, otherwise the
            // switch would be a promise the app does not keep.
            if (!enabled) historyRepository.deleteAll()
        }
    }

    fun setSaveAudio(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setSaveAudio(enabled)
            if (!enabled) historyRepository.purgeAudio()
        }
    }

    fun setLatencyProfile(profile: LatencyProfile) {
        viewModelScope.launch { settingsRepository.setLatencyProfile(profile) }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { settingsRepository.setThemeMode(mode) }
    }

    fun setCacheEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setTranslationCacheEnabled(enabled)
            if (!enabled) translationRepository.clearCache()
        }
    }

    private companion object {
        const val STOP_TIMEOUT_MILLIS = 5_000L
    }
}
