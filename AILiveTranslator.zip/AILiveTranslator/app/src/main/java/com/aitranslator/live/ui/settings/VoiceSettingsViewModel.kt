package com.aitranslator.live.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.AppSettings
import com.aitranslator.live.core.domain.model.VoiceGender
import com.aitranslator.live.core.domain.model.VoiceProfile
import com.aitranslator.live.core.domain.repository.SettingsRepository
import com.aitranslator.live.core.domain.repository.SpeechRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class VoiceSettingsUiState(
    val voices: List<VoiceProfile> = VoiceProfile.OPENAI_VOICES + VoiceProfile.DEVICE_DEFAULT,
    val genderFilter: VoiceGender? = null,
    val previewingVoiceId: String? = null,
    val isLoading: Boolean = true,
    val error: AppError? = null,
) {
    val filteredVoices: List<VoiceProfile>
        get() = genderFilter?.let { gender -> voices.filter { it.gender == gender } } ?: voices
}

@HiltViewModel
class VoiceSettingsViewModel @Inject constructor(
    private val speechRepository: SpeechRepository,
    private val settingsRepository: SettingsRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(VoiceSettingsUiState())
    val uiState: StateFlow<VoiceSettingsUiState> = _uiState.asStateFlow()

    val settings: StateFlow<AppSettings> = settingsRepository.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = AppSettings(),
    )

    init {
        refreshVoices()
    }

    /**
     * The cloud catalogue is static, but the device catalogue depends on which TTS engine
     * and language packs are installed, so it is queried at runtime.
     */
    fun refreshVoices() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val catalogue = speechRepository.voiceCatalogue()
            _uiState.update {
                it.copy(
                    voices = catalogue.ifEmpty {
                        VoiceProfile.OPENAI_VOICES + VoiceProfile.DEVICE_DEFAULT
                    },
                    isLoading = false,
                )
            }
        }
    }

    fun setGenderFilter(gender: VoiceGender?) {
        _uiState.update { it.copy(genderFilter = gender) }
    }

    fun selectVoice(voice: VoiceProfile) {
        viewModelScope.launch {
            settingsRepository.setVoice(voice.id)
            settingsRepository.setPreferredVoiceGender(voice.gender)
        }
    }

    fun preview(voice: VoiceProfile) {
        viewModelScope.launch {
            _uiState.update { it.copy(previewingVoiceId = voice.id) }
            val language = settingsRepository.current().targetLanguage
            val result = speechRepository.previewVoice(voice, language)
            _uiState.update {
                it.copy(
                    previewingVoiceId = null,
                    error = (result as? AppResult.Failure)?.error,
                )
            }
        }
    }

    fun setSpeed(speed: Float) {
        viewModelScope.launch { settingsRepository.setSpeechSpeed(speed) }
    }

    fun setVolume(volume: Float) {
        viewModelScope.launch { settingsRepository.setSpeechVolume(volume) }
    }

    fun dismissError() {
        _uiState.update { it.copy(error = null) }
    }

    private companion object {
        const val STOP_TIMEOUT_MILLIS = 5_000L
    }
}
