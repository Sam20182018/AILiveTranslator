package com.aitranslator.live.ui.text

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.common.NetworkMonitor
import com.aitranslator.live.core.domain.model.AppSettings
import com.aitranslator.live.core.domain.model.HistoryEntry
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.TranslationMode
import com.aitranslator.live.core.domain.model.TranslationRequest
import com.aitranslator.live.core.domain.repository.HistoryRepository
import com.aitranslator.live.core.domain.repository.SettingsRepository
import com.aitranslator.live.core.domain.usecase.SpeakTextUseCase
import com.aitranslator.live.core.domain.usecase.TranslateTextUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class TextTranslationUiState(
    val input: String = "",
    val translation: String = "",
    val isTranslating: Boolean = false,
    val isSpeaking: Boolean = false,
    val error: AppError? = null,
    val fromCache: Boolean = false,
)

@HiltViewModel
class TextTranslationViewModel @Inject constructor(
    private val translateText: TranslateTextUseCase,
    private val speakText: SpeakTextUseCase,
    private val settingsRepository: SettingsRepository,
    private val historyRepository: HistoryRepository,
    networkMonitor: NetworkMonitor,
) : ViewModel() {

    private val _uiState = MutableStateFlow(TextTranslationUiState())
    val uiState: StateFlow<TextTranslationUiState> = _uiState.asStateFlow()

    val settings: StateFlow<AppSettings> = settingsRepository.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = AppSettings(),
    )

    val isOnline: StateFlow<Boolean> = networkMonitor.isOnline.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = networkMonitor.isCurrentlyOnline(),
    )

    private var translationJob: Job? = null

    fun onInputChanged(text: String) {
        _uiState.update { it.copy(input = text, error = null) }
    }

    fun setPrefilledText(text: String) {
        if (_uiState.value.input.isBlank()) {
            _uiState.update { it.copy(input = text) }
        }
    }

    fun clear() {
        translationJob?.cancel()
        _uiState.value = TextTranslationUiState()
    }

    fun setSourceLanguage(language: Language) {
        viewModelScope.launch {
            settingsRepository.setSourceLanguage(language)
        }
    }

    fun setTargetLanguage(language: Language) {
        viewModelScope.launch {
            settingsRepository.setTargetLanguage(language)
        }
    }

    fun swapLanguages() {
        viewModelScope.launch {
            settingsRepository.swapLanguages()

            // Swapping with a finished translation on screen is almost always "now translate
            // this result back", so the output becomes the new input.
            val current = _uiState.value
            if (current.translation.isNotBlank()) {
                _uiState.update {
                    it.copy(input = current.translation, translation = current.input)
                }
            }
        }
    }

    fun translate() {
        val current = _uiState.value
        if (current.input.isBlank()) {
            _uiState.update { it.copy(error = AppError.EmptyInput()) }
            return
        }

        translationJob?.cancel()
        translationJob = viewModelScope.launch {
            _uiState.update { it.copy(isTranslating = true, error = null) }

            val activeSettings = settingsRepository.current()
            val request = TranslationRequest(
                text = current.input,
                sourceLanguage = activeSettings.sourceLanguage,
                targetLanguage = activeSettings.targetLanguage,
                mode = TranslationMode.TEXT,
            )

            when (val result = translateText(request)) {
                is AppResult.Failure ->
                    _uiState.update { it.copy(isTranslating = false, error = result.error) }

                is AppResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isTranslating = false,
                            translation = result.data.translatedText,
                            fromCache = result.data.fromCache,
                            error = null,
                        )
                    }

                    historyRepository.add(
                        HistoryEntry(
                            timestampMillis = System.currentTimeMillis(),
                            sourceLanguage = request.sourceLanguage,
                            targetLanguage = request.targetLanguage,
                            originalText = request.text,
                            translatedText = result.data.translatedText,
                            mode = TranslationMode.TEXT,
                            provider = result.data.provider,
                        ),
                    )

                    if (activeSettings.autoPlayTranslation && activeSettings.voiceTranslationEnabled) {
                        speak(result.data.translatedText, activeSettings.targetLanguage)
                    }
                }
            }
        }
    }

    fun speak(text: String, language: Language) {
        viewModelScope.launch {
            _uiState.update { it.copy(isSpeaking = true) }
            val result = speakText(text, language, force = true)
            _uiState.update {
                it.copy(isSpeaking = false, error = (result as? AppResult.Failure)?.error)
            }
        }
    }

    fun stopSpeaking() {
        viewModelScope.launch {
            speakText.stop()
            _uiState.update { it.copy(isSpeaking = false) }
        }
    }

    fun dismissError() {
        _uiState.update { it.copy(error = null) }
    }

    private companion object {
        const val STOP_TIMEOUT_MILLIS = 5_000L
    }
}
