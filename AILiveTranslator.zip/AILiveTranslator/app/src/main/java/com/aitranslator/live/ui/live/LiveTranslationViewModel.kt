package com.aitranslator.live.ui.live

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.NetworkMonitor
import com.aitranslator.live.core.domain.live.LiveSessionConfig
import com.aitranslator.live.core.domain.live.LiveTranslationEngineSelector
import com.aitranslator.live.core.domain.model.AppSettings
import com.aitranslator.live.core.domain.model.HistoryEntry
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.LiveEvent
import com.aitranslator.live.core.domain.model.PipelineState
import com.aitranslator.live.core.domain.model.TranslationMode
import com.aitranslator.live.core.domain.repository.HistoryRepository
import com.aitranslator.live.core.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/** One completed live utterance, newest first in the UI. */
data class LiveLine(
    val id: Long,
    val original: String,
    val translation: String,
)

data class LiveUiState(
    val isRunning: Boolean = false,
    val pipelineState: PipelineState = PipelineState.Idle,
    val amplitude: Float = 0f,
    val partialTranscript: String = "",
    val partialTranslation: String = "",
    val lines: List<LiveLine> = emptyList(),
    val engineId: String = "",
    val error: AppError? = null,
)

@HiltViewModel
class LiveTranslationViewModel @Inject constructor(
    private val engineSelector: LiveTranslationEngineSelector,
    private val settingsRepository: SettingsRepository,
    private val historyRepository: HistoryRepository,
    networkMonitor: NetworkMonitor,
) : ViewModel() {

    private val _uiState = MutableStateFlow(LiveUiState())
    val uiState: StateFlow<LiveUiState> = _uiState.asStateFlow()

    val settings: StateFlow<AppSettings> = settingsRepository.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = AppSettings(),
    )

    val isOnline: StateFlow<Boolean> = networkMonitor.isOnline.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = networkMonitor.isCurrentlyOnline(),
    )

    private var sessionJob: Job? = null

    fun toggleSession() {
        if (_uiState.value.isRunning) stop() else start()
    }

    fun start() {
        if (_uiState.value.isRunning) return

        sessionJob?.cancel()
        sessionJob = viewModelScope.launch {
            val activeSettings = settingsRepository.current()
            val config = LiveSessionConfig(
                sourceLanguage = activeSettings.sourceLanguage,
                targetLanguage = activeSettings.targetLanguage,
                mode = TranslationMode.LIVE,
                latencyProfile = activeSettings.latencyProfile,
                autoSpeak = activeSettings.voiceTranslationEnabled &&
                    activeSettings.autoPlayTranslation,
            )

            val engine = engineSelector.select(config)

            _uiState.update {
                it.copy(
                    isRunning = true,
                    engineId = engine.id,
                    error = null,
                    partialTranscript = "",
                    partialTranslation = "",
                )
            }

            engine.run(config).collect { event -> handle(event, config) }
        }
    }

    fun stop() {
        sessionJob?.cancel()
        sessionJob = null
        _uiState.update {
            it.copy(
                isRunning = false,
                pipelineState = PipelineState.Stopped,
                amplitude = 0f,
                partialTranscript = "",
                partialTranslation = "",
            )
        }
    }

    private suspend fun handle(event: LiveEvent, config: LiveSessionConfig) {
        when (event) {
            is LiveEvent.StateChanged -> {
                val amplitude = (event.state as? PipelineState.Listening)?.amplitude ?: 0f
                _uiState.update {
                    it.copy(pipelineState = event.state, amplitude = amplitude)
                }
            }

            is LiveEvent.PartialTranscript ->
                _uiState.update { it.copy(partialTranscript = event.text) }

            is LiveEvent.FinalTranscript ->
                _uiState.update { it.copy(partialTranscript = event.text) }

            is LiveEvent.PartialTranslation ->
                _uiState.update { it.copy(partialTranslation = event.text) }

            is LiveEvent.FinalTranslation -> {
                val result = event.result
                _uiState.update { state ->
                    state.copy(
                        partialTranscript = "",
                        partialTranslation = "",
                        lines = listOf(
                            LiveLine(
                                id = System.nanoTime(),
                                original = result.originalText.ifBlank { state.partialTranscript },
                                translation = result.translatedText,
                            ),
                        ) + state.lines.take(MAX_LINES),
                    )
                }

                historyRepository.add(
                    HistoryEntry(
                        timestampMillis = System.currentTimeMillis(),
                        sourceLanguage = config.sourceLanguage,
                        targetLanguage = config.targetLanguage,
                        originalText = result.originalText,
                        translatedText = result.translatedText,
                        mode = TranslationMode.LIVE,
                        provider = result.provider,
                    ),
                )
            }

            is LiveEvent.Failed ->
                _uiState.update { it.copy(error = event.error) }
        }
    }

    fun setSourceLanguage(language: Language) {
        viewModelScope.launch { settingsRepository.setSourceLanguage(language) }
    }

    fun setTargetLanguage(language: Language) {
        viewModelScope.launch { settingsRepository.setTargetLanguage(language) }
    }

    fun swapLanguages() {
        viewModelScope.launch { settingsRepository.swapLanguages() }
    }

    fun clearLines() {
        _uiState.update { it.copy(lines = emptyList()) }
    }

    fun dismissError() {
        _uiState.update { it.copy(error = null) }
    }

    override fun onCleared() {
        super.onCleared()
        sessionJob?.cancel()
    }

    private companion object {
        const val STOP_TIMEOUT_MILLIS = 5_000L
        const val MAX_LINES = 50
    }
}
