package com.aitranslator.live.ui.voice

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aitranslator.live.R
import com.aitranslator.live.ui.common.toUserMessage
import com.aitranslator.live.ui.components.LanguageSelectorRow
import com.aitranslator.live.ui.components.MicButton
import com.aitranslator.live.ui.components.PipelineStatusChip
import com.aitranslator.live.ui.components.TranslationCard
import com.aitranslator.live.ui.components.TranslatorScaffold
import com.aitranslator.live.ui.components.rememberMicrophonePermission

@Composable
fun VoiceTranslationScreen(
    onBack: () -> Unit,
    viewModel: VoiceTranslationViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    val micPermission = rememberMicrophonePermission(onGranted = viewModel::toggleRecording)

    LaunchedEffect(uiState.error) {
        uiState.error?.let { error ->
            snackbarHostState.showSnackbar(error.toUserMessage(context))
            viewModel.dismissError()
        }
    }

    TranslatorScaffold(
        title = stringResource(R.string.mode_voice),
        onBack = onBack,
        isOnline = isOnline,
        snackbarHostState = snackbarHostState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            LanguageSelectorRow(
                source = settings.sourceLanguage,
                target = settings.targetLanguage,
                onSourceSelected = viewModel::setSourceLanguage,
                onTargetSelected = viewModel::setTargetLanguage,
                onSwap = viewModel::swapLanguages,
                enabled = !uiState.isRecording && !uiState.isBusy,
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(modifier = Modifier.height(24.dp))

            PipelineStatusChip(state = uiState.pipelineState)

            Spacer(modifier = Modifier.height(24.dp))

            MicButton(
                isRecording = uiState.isRecording,
                amplitude = uiState.amplitude,
                enabled = !uiState.isBusy,
                onClick = { micPermission.runOrRequest(viewModel::toggleRecording) },
                size = 112,
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = stringResource(R.string.voice_tap_hint),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Spacer(modifier = Modifier.height(24.dp))

            if (settings.showOriginalText && uiState.transcript.isNotBlank()) {
                TranslationCard(
                    language = settings.sourceLanguage,
                    text = uiState.transcript,
                    onCopy = { clipboard.setText(AnnotatedString(uiState.transcript)) },
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            if (settings.showTranslation && uiState.translation.isNotBlank()) {
                TranslationCard(
                    language = settings.targetLanguage,
                    text = uiState.translation,
                    isPrimary = true,
                    onCopy = { clipboard.setText(AnnotatedString(uiState.translation)) },
                    onSpeak = viewModel::replay,
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
