package com.aitranslator.live.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.aitranslator.live.MainActivity
import com.aitranslator.live.R
import com.aitranslator.live.TranslatorApplication
import com.aitranslator.live.assist.AssistSessionController
import com.aitranslator.live.core.common.Logger
import com.aitranslator.live.core.domain.live.LiveSessionConfig
import com.aitranslator.live.core.domain.live.LiveTranslationEngineSelector
import com.aitranslator.live.core.domain.model.LiveEvent
import com.aitranslator.live.core.domain.model.PipelineState
import com.aitranslator.live.core.domain.model.TranslationMode
import com.aitranslator.live.core.domain.repository.SettingsRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * "Speaker Assist" — the only legitimate way to translate a call this app can offer.
 *
 * The user puts the call on speakerphone; this service captures what the microphone picks
 * up acoustically, runs the normal VAD → speech recognition → translation pipeline, and
 * publishes subtitles. It does **not** read the call's audio stream (Android forbids that
 * for non-system apps) and it does **not** inject audio into the call.
 *
 * On many devices Android grants the calling app exclusive microphone access, so this may
 * receive silence. That case is detected and reported rather than hidden — see
 * [AssistSessionController.heardAnyAudio] and the message shown by the assist screen.
 */
@AndroidEntryPoint
class SpeakerAssistService : Service() {

    @Inject
    lateinit var engineSelector: LiveTranslationEngineSelector

    @Inject
    lateinit var settingsRepository: SettingsRepository

    @Inject
    lateinit var sessionController: AssistSessionController

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var sessionJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSession()
                return START_NOT_STICKY
            }

            else -> startSession(
                mode = TranslationMode.fromId(intent?.getStringExtra(EXTRA_MODE)),
            )
        }
        return START_STICKY
    }

    private fun startSession(mode: TranslationMode) {
        if (sessionJob?.isActive == true) return

        startForegroundCompat()
        sessionController.setListening(true)

        sessionJob = serviceScope.launch {
            val settings = settingsRepository.current()
            val config = LiveSessionConfig(
                sourceLanguage = settings.sourceLanguage,
                targetLanguage = settings.targetLanguage,
                mode = mode,
                latencyProfile = settings.latencyProfile,
                // Playing the translation aloud while the microphone is listening to a
                // speakerphone would feed the app its own output, so it stays text-only.
                autoSpeak = false,
            )

            val engine = engineSelector.select(config)
            Logger.i(TAG, "speaker assist started with engine=${engine.id} mode=${mode.id}")

            engine.run(config).collect { event ->
                when (event) {
                    is LiveEvent.StateChanged -> {
                        sessionController.setPipelineState(event.state)
                        val amplitude = (event.state as? PipelineState.Listening)?.amplitude ?: 0f
                        if (amplitude > AUDIO_PRESENCE_THRESHOLD) {
                            sessionController.markAudioHeard()
                        }
                    }

                    is LiveEvent.PartialTranscript ->
                        sessionController.setPartial(original = event.text, translation = null)

                    is LiveEvent.FinalTranscript -> {
                        sessionController.markAudioHeard()
                        sessionController.setPartial(original = event.text, translation = null)
                    }

                    is LiveEvent.PartialTranslation ->
                        sessionController.setPartial(original = null, translation = event.text)

                    is LiveEvent.FinalTranslation ->
                        sessionController.addLine(
                            original = event.result.originalText,
                            translation = event.result.translatedText,
                            fromChat = false,
                        )

                    is LiveEvent.Failed -> sessionController.setError(event.error)
                }
            }
        }
    }

    private fun stopSession() {
        sessionJob?.cancel()
        sessionJob = null
        sessionController.setListening(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE,
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, SpeakerAssistService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        return NotificationCompat.Builder(this, TranslatorApplication.ASSIST_CHANNEL_ID)
            .setContentTitle(getString(R.string.assist_notification_title))
            .setContentText(getString(R.string.assist_notification_text))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, getString(R.string.assist_notification_stop), stopIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        sessionJob?.cancel()
        serviceScope.cancel()
        sessionController.setListening(false)
        super.onDestroy()
    }

    companion object {
        private const val TAG = "SpeakerAssist"
        private const val NOTIFICATION_ID = 4711
        private const val AUDIO_PRESENCE_THRESHOLD = 0.02f

        const val ACTION_STOP = "com.aitranslator.live.action.STOP_ASSIST"
        const val EXTRA_MODE = "mode"

        fun start(context: Context, mode: TranslationMode) {
            val intent = Intent(context, SpeakerAssistService::class.java)
                .putExtra(EXTRA_MODE, mode.id)
            context.startForegroundService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, SpeakerAssistService::class.java)
                .setAction(ACTION_STOP)
            context.startService(intent)
        }
    }
}
