package com.aitranslator.live.ui.live

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aitranslator.live.R
import com.aitranslator.live.ui.common.toUserMessage
import com.aitranslator.live.ui.components.LanguageSelectorRow
import com.aitranslator.live.ui.components.PipelineStatusChip
import com.aitranslator.live.ui.components.TranslationCard
import com.aitranslator.live.ui.components.TranslatorScaffold
import com.aitranslator.live.ui.components.rememberMicrophonePermission

/**
 * Continuous translation. The live pane at the top shows what is happening right now; the
 * list below keeps the finished utterances so nothing scrolls away before it is read.
 */
@Composable
fun LiveTranslationScreen(
    onBack: () -> Unit,
    viewModel: LiveTranslationViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    val micPermission = rememberMicrophonePermission(onGranted = viewModel::start)

    LaunchedEffect(uiState.error) {
        uiState.error?.let { error ->
            snackbarHostState.showSnackbar(error.toUserMessage(context))
            viewModel.dismissError()
        }
    }

    TranslatorScaffold(
        title = stringResource(R.string.mode_live),
        onBack = onBack,
        isOnline = isOnline,
        snackbarHostState = snackbarHostState,
        actions = {
            IconButton(onClick = viewModel::clearLines) {
                Icon(
                    imageVector = Icons.Filled.DeleteSweep,
                    contentDescription = stringResource(R.string.action_clear),
                )
            }
        },
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
        ) {
            LanguageSelectorRow(
                source = settings.sourceLanguage,
                target = settings.targetLanguage,
                onSourceSelected = viewModel::setSourceLanguage,
                onTargetSelected = viewModel::setTargetLanguage,
                onSwap = viewModel::swapLanguages,
                enabled = !uiState.isRunning,
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(modifier = Modifier.height(12.dp))

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                PipelineStatusChip(state = uiState.pipelineState)

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { micPermission.runOrRequest(viewModel::toggleSession) },
                    colors = if (uiState.isRunning) {
                        ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = MaterialTheme.colorScheme.onError,
                        )
                    } else {
                        ButtonDefaults.buttonColors()
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        stringResource(
                            if (uiState.isRunning) R.string.live_stop else R.string.live_start,
                        ),
                    )
                }

                if (uiState.isRunning && uiState.engineId.isNotBlank()) {
                    Text(
                        text = "engine: ${uiState.engineId}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (uiState.partialTranscript.isNotBlank() ||
                uiState.partialTranslation.isNotBlank()
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        if (settings.showOriginalText && uiState.partialTranscript.isNotBlank()) {
                            Text(
                                text = uiState.partialTranscript,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                            )
                        }
                        if (settings.showTranslation && uiState.partialTranslation.isNotBlank()) {
                            Text(
                                text = uiState.partialTranslation,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(top = 8.dp),
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(items = uiState.lines, key = { it.id }) { line ->
                    Column {
                        if (settings.showOriginalText && line.original.isNotBlank()) {
                            TranslationCard(
                                language = settings.sourceLanguage,
                                text = line.original,
                                onCopy = { clipboard.setText(AnnotatedString(line.original)) },
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                        }
                        if (settings.showTranslation) {
                            TranslationCard(
                                language = settings.targetLanguage,
                                text = line.translation,
                                isPrimary = true,
                                onCopy = { clipboard.setText(AnnotatedString(line.translation)) },
                            )
                        }
                    }
                }
            }
        }
    }
}
