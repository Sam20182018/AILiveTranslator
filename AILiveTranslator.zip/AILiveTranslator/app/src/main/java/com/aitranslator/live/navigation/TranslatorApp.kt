package com.aitranslator.live.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.aitranslator.live.core.domain.assist.AssistCapabilities
import com.aitranslator.live.ui.assist.AssistScreen
import com.aitranslator.live.ui.conversation.ConversationScreen
import com.aitranslator.live.ui.history.HistoryScreen
import com.aitranslator.live.ui.home.HomeScreen
import com.aitranslator.live.ui.live.LiveTranslationScreen
import com.aitranslator.live.ui.settings.ApiKeysScreen
import com.aitranslator.live.ui.settings.SettingsScreen
import com.aitranslator.live.ui.settings.VoiceSettingsScreen
import com.aitranslator.live.ui.text.TextTranslationScreen
import com.aitranslator.live.ui.voice.VoiceTranslationScreen

@Composable
fun TranslatorApp(initialSharedText: String? = null) {
    val navController = rememberNavController()

    // Text shared into the app skips the home screen entirely — the user already told us
    // what they want to do.
    val startDestination = if (initialSharedText.isNullOrBlank()) {
        Destinations.HOME
    } else {
        Destinations.TEXT
    }

    NavHost(navController = navController, startDestination = startDestination) {

        composable(Destinations.HOME) {
            HomeScreen(
                onOpenMode = { route -> navController.navigate(route) },
                onOpenSettings = { navController.navigate(Destinations.SETTINGS) },
                onOpenHistory = { navController.navigate(Destinations.HISTORY) },
            )
        }

        composable(Destinations.TEXT) {
            TextTranslationScreen(
                initialText = initialSharedText,
                onBack = { navController.popBackStack() },
            )
        }

        composable(Destinations.VOICE) {
            VoiceTranslationScreen(onBack = { navController.popBackStack() })
        }

        composable(Destinations.LIVE) {
            LiveTranslationScreen(onBack = { navController.popBackStack() })
        }

        composable(Destinations.CONVERSATION) {
            ConversationScreen(onBack = { navController.popBackStack() })
        }

        composable(Destinations.HISTORY) {
            HistoryScreen(onBack = { navController.popBackStack() })
        }

        composable(Destinations.SETTINGS) {
            SettingsScreen(
                onBack = { navController.popBackStack() },
                onOpenApiKeys = { navController.navigate(Destinations.API_KEYS) },
                onOpenVoiceSettings = { navController.navigate(Destinations.VOICE_SETTINGS) },
            )
        }

        composable(Destinations.API_KEYS) {
            ApiKeysScreen(onBack = { navController.popBackStack() })
        }

        composable(Destinations.VOICE_SETTINGS) {
            VoiceSettingsScreen(onBack = { navController.popBackStack() })
        }

        composable(
            route = Destinations.ASSIST_ROUTE,
            arguments = listOf(
                navArgument(Destinations.ASSIST_FEATURE_ARG) { type = NavType.StringType },
            ),
        ) { backStackEntry ->
            val feature = backStackEntry.arguments
                ?.getString(Destinations.ASSIST_FEATURE_ARG)
                ?: AssistCapabilities.WHATSAPP

            AssistScreen(feature = feature, onBack = { navController.popBackStack() })
        }
    }
}
