package com.aitranslator.live.ui.text

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aitranslator.live.R
import com.aitranslator.live.ui.common.toUserMessage
import com.aitranslator.live.ui.components.LanguageSelectorRow
import com.aitranslator.live.ui.components.TranslationCard
import com.aitranslator.live.ui.components.TranslatorScaffold

@Composable
fun TextTranslationScreen(
    onBack: () -> Unit,
    initialText: String? = null,
    viewModel: TextTranslationViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(initialText) {
        if (!initialText.isNullOrBlank()) viewModel.setPrefilledText(initialText)
    }

    LaunchedEffect(uiState.error) {
        uiState.error?.let { error ->
            snackbarHostState.showSnackbar(error.toUserMessage(context))
            viewModel.dismissError()
        }
    }

    TranslatorScaffold(
        title = stringResource(R.string.mode_text),
        onBack = onBack,
        isOnline = isOnline,
        snackbarHostState = snackbarHostState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            LanguageSelectorRow(
                source = settings.sourceLanguage,
                target = settings.targetLanguage,
                onSourceSelected = viewModel::setSourceLanguage,
                onTargetSelected = viewModel::setTargetLanguage,
                onSwap = viewModel::swapLanguages,
                enabled = !uiState.isTranslating,
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = uiState.input,
                onValueChange = viewModel::onInputChanged,
                label = { Text(stringResource(R.string.text_input_hint)) },
                trailingIcon = {
                    if (uiState.input.isNotEmpty()) {
                        IconButton(onClick = viewModel::clear) {
                            Icon(
                                imageVector = Icons.Filled.Clear,
                                contentDescription = stringResource(R.string.action_clear),
                            )
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 140.dp),
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = viewModel::translate,
                    enabled = !uiState.isTranslating && uiState.input.isNotBlank(),
                    modifier = Modifier.weight(1f),
                ) {
                    if (uiState.isTranslating) {
                        CircularProgressIndicator(
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                    }
                    Text(stringResource(R.string.action_translate))
                }

                OutlinedButton(onClick = viewModel::clear) {
                    Text(stringResource(R.string.action_clear))
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            if (settings.showOriginalText && uiState.translation.isNotBlank()) {
                TranslationCard(
                    language = settings.sourceLanguage,
                    text = uiState.input,
                    onCopy = { clipboard.setText(AnnotatedString(uiState.input)) },
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            if (settings.showTranslation && uiState.translation.isNotBlank()) {
                TranslationCard(
                    language = settings.targetLanguage,
                    text = uiState.translation,
                    isPrimary = true,
                    onCopy = { clipboard.setText(AnnotatedString(uiState.translation)) },
                    onShare = {
                        val share = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, uiState.translation)
                        }
                        context.startActivity(Intent.createChooser(share, null))
                    },
                    onSpeak = {
                        viewModel.speak(uiState.translation, settings.targetLanguage)
                    },
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
