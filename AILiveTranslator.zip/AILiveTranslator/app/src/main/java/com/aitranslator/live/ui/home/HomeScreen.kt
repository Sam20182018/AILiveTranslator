package com.aitranslator.live.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.KeyboardVoice
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Textsms
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aitranslator.live.R
import com.aitranslator.live.core.domain.assist.AssistCapabilities
import com.aitranslator.live.navigation.Destinations
import com.aitranslator.live.ui.components.ConnectivityPill
import com.aitranslator.live.ui.components.LanguageSelectorRow
import com.aitranslator.live.ui.components.MicButton
import com.aitranslator.live.ui.components.TranslatorScaffold

private data class ModeEntry(
    val labelRes: Int,
    val icon: ImageVector,
    val route: String,
)

/**
 * The landing screen is deliberately one screen deep: pick the two languages, press the
 * microphone, done. Every other mode is one tap from here.
 */
@Composable
fun HomeScreen(
    onOpenMode: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenHistory: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel(),
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()

    val modes = listOf(
        ModeEntry(R.string.mode_text, Icons.Filled.Textsms, Destinations.TEXT),
        ModeEntry(R.string.mode_voice, Icons.Filled.KeyboardVoice, Destinations.VOICE),
        ModeEntry(R.string.mode_live, Icons.Filled.GraphicEq, Destinations.LIVE),
        ModeEntry(
            R.string.mode_conversation,
            Icons.AutoMirrored.Filled.Chat,
            Destinations.CONVERSATION,
        ),
        ModeEntry(
            R.string.mode_whatsapp,
            Icons.Filled.Translate,
            Destinations.assist(AssistCapabilities.WHATSAPP),
        ),
        ModeEntry(
            R.string.mode_phone_call,
            Icons.Filled.Call,
            Destinations.assist(AssistCapabilities.PHONE_CALL),
        ),
    )

    TranslatorScaffold(
        title = stringResource(R.string.home_title),
        isOnline = isOnline,
        actions = {
            IconButton(onClick = onOpenHistory) {
                Icon(
                    imageVector = Icons.Filled.History,
                    contentDescription = stringResource(R.string.action_history),
                )
            }
            IconButton(onClick = onOpenSettings) {
                Icon(
                    imageVector = Icons.Filled.Settings,
                    contentDescription = stringResource(R.string.action_settings),
                )
            }
        },
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            ConnectivityPill(
                isOnline = isOnline,
                modifier = Modifier
                    .align(Alignment.End)
                    .padding(top = 8.dp),
            )

            Spacer(modifier = Modifier.height(8.dp))

            LanguageSelectorRow(
                source = settings.sourceLanguage,
                target = settings.targetLanguage,
                onSourceSelected = viewModel::setSourceLanguage,
                onTargetSelected = viewModel::setTargetLanguage,
                onSwap = viewModel::swapLanguages,
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(modifier = Modifier.height(32.dp))

            MicButton(
                isRecording = false,
                amplitude = 0f,
                onClick = { onOpenMode(Destinations.VOICE) },
                size = 112,
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = stringResource(R.string.voice_tap_hint),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = stringResource(R.string.home_subtitle),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier
                    .align(Alignment.Start)
                    .padding(bottom = 12.dp),
            )

            modes.chunked(2).forEach { rowModes ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    rowModes.forEach { mode ->
                        ModeCard(
                            label = stringResource(mode.labelRes),
                            icon = mode.icon,
                            onClick = { onOpenMode(mode.route) },
                            modifier = Modifier.weight(1f),
                        )
                    }
                    if (rowModes.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ModeCard(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        onClick = onClick,
        modifier = modifier.height(96.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = label, style = MaterialTheme.typography.labelLarge)
        }
    }
}
