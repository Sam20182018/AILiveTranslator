package com.aitranslator.live.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.domain.model.AiModelConfig
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.ApiKeyEntry
import com.aitranslator.live.core.domain.model.AppSettings
import com.aitranslator.live.core.domain.repository.ApiKeyRepository
import com.aitranslator.live.core.domain.repository.SettingsRepository
import com.aitranslator.live.core.domain.usecase.TestProviderConnectionUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Per-provider transient UI state. Draft keys live here and are never persisted as-is. */
data class ProviderEditorState(
    val draftKey: String = "",
    val isKeyVisible: Boolean = false,
    val isTesting: Boolean = false,
    val testSucceeded: Boolean? = null,
    val modelDraft: String = "",
)

data class ApiKeysUiState(
    val editors: Map<AiProvider, ProviderEditorState> = AiProvider.concreteProviders
        .associateWith { ProviderEditorState() },
    val message: String? = null,
    val error: AppError? = null,
)

@HiltViewModel
class ApiKeysViewModel @Inject constructor(
    private val apiKeyRepository: ApiKeyRepository,
    private val settingsRepository: SettingsRepository,
    private val testConnection: TestProviderConnectionUseCase,
) : ViewModel() {

    private val _uiState = MutableStateFlow(ApiKeysUiState())
    val uiState: StateFlow<ApiKeysUiState> = _uiState.asStateFlow()

    val entries: StateFlow<List<ApiKeyEntry>> = apiKeyRepository.entries.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = emptyList(),
    )

    val settings: StateFlow<AppSettings> = settingsRepository.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = AppSettings(),
    )

    fun onKeyDraftChanged(provider: AiProvider, value: String) {
        updateEditor(provider) { it.copy(draftKey = value, testSucceeded = null) }
    }

    fun toggleKeyVisibility(provider: AiProvider) {
        updateEditor(provider) { it.copy(isKeyVisible = !it.isKeyVisible) }
    }

    fun onModelDraftChanged(provider: AiProvider, value: String) {
        updateEditor(provider) { it.copy(modelDraft = value) }
    }

    fun saveKey(provider: AiProvider) {
        val draft = _uiState.value.editors[provider]?.draftKey.orEmpty()
        if (draft.isBlank()) {
            _uiState.update { it.copy(error = AppError.EmptyInput()) }
            return
        }

        viewModelScope.launch {
            when (val result = apiKeyRepository.saveKey(provider, draft)) {
                is AppResult.Failure -> _uiState.update { it.copy(error = result.error) }
                is AppResult.Success -> {
                    // The draft is dropped immediately: the plaintext key must not survive
                    // in a UI state object that outlives the save.
                    updateEditor(provider) { it.copy(draftKey = "", isKeyVisible = false) }
                    _uiState.update { it.copy(message = SAVED) }
                }
            }
        }
    }

    fun saveModel(provider: AiProvider) {
        val draft = _uiState.value.editors[provider]?.modelDraft.orEmpty()
        viewModelScope.launch {
            settingsRepository.setModelOverride(provider, draft.ifBlank { null })
            _uiState.update { it.copy(message = SAVED) }
        }
    }

    fun deleteKey(provider: AiProvider) {
        viewModelScope.launch {
            apiKeyRepository.deleteKey(provider)
            updateEditor(provider) { ProviderEditorState() }
            _uiState.update { it.copy(message = DELETED) }
        }
    }

    fun setActive(provider: AiProvider, active: Boolean) {
        viewModelScope.launch { apiKeyRepository.setActive(provider, active) }
    }

    /** Tests the typed draft when there is one, otherwise the key already stored. */
    fun test(provider: AiProvider) {
        val editor = _uiState.value.editors[provider] ?: ProviderEditorState()
        updateEditor(provider) { it.copy(isTesting = true, testSucceeded = null) }

        viewModelScope.launch {
            val model = editor.modelDraft.ifBlank {
                settingsRepository.current().modelFor(provider)
            }
            val result = testConnection(
                provider = provider,
                candidateKey = editor.draftKey.ifBlank { null },
                model = model,
            )

            updateEditor(provider) {
                it.copy(isTesting = false, testSucceeded = result.isSuccess)
            }
            if (result is AppResult.Failure) {
                _uiState.update { it.copy(error = result.error) }
            }
        }
    }

    fun defaultModel(provider: AiProvider): String =
        AiModelConfig.defaultFor(provider).translationModel

    fun modelSuggestions(provider: AiProvider): List<String> =
        AiModelConfig.suggestionsFor(provider)

    fun consumeMessage() {
        _uiState.update { it.copy(message = null) }
    }

    fun dismissError() {
        _uiState.update { it.copy(error = null) }
    }

    private fun updateEditor(
        provider: AiProvider,
        transform: (ProviderEditorState) -> ProviderEditorState,
    ) {
        _uiState.update { state ->
            val current = state.editors[provider] ?: ProviderEditorState()
            state.copy(editors = state.editors + (provider to transform(current)))
        }
    }

    private companion object {
        const val STOP_TIMEOUT_MILLIS = 5_000L
        const val SAVED = "saved"
        const val DELETED = "deleted"
    }
}
