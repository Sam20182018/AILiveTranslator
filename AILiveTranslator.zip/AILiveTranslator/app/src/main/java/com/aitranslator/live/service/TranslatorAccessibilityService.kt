package com.aitranslator.live.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.aitranslator.live.assist.AssistSessionController
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.common.Logger
import com.aitranslator.live.core.domain.model.TranslationMode
import com.aitranslator.live.core.domain.model.TranslationRequest
import com.aitranslator.live.core.domain.repository.SettingsRepository
import com.aitranslator.live.core.domain.usecase.TranslateTextUseCase
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import javax.inject.Inject

/**
 * Translates the WhatsApp **chat text** that is currently visible on screen.
 *
 * This is the part of "WhatsApp translation" that Android genuinely permits. It reads text
 * from the accessibility node tree of `com.whatsapp` only (enforced in
 * `accessibility_service_config.xml`), translates messages it has not seen before, and
 * publishes them to the assist screen.
 *
 * It deliberately does **not**:
 * * touch call audio — Android does not expose another app's VOICE_COMMUNICATION stream;
 * * record anything — no audio API is used here at all;
 * * store message text — translations go to the in-memory session state and, only if the
 *   user enabled history, through the normal history repository.
 */
@AndroidEntryPoint
class TranslatorAccessibilityService : AccessibilityService() {

    @Inject
    lateinit var translateText: TranslateTextUseCase

    @Inject
    lateinit var settingsRepository: SettingsRepository

    @Inject
    lateinit var sessionController: AssistSessionController

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val translationMutex = Mutex()
    private val recentlySeen = LinkedHashSet<String>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        sessionController.setAccessibilityConnected(true)
        Logger.i(TAG, "accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.packageName?.toString()?.startsWith(WHATSAPP_PACKAGE_PREFIX) != true) return

        val root = rootInActiveWindow ?: return
        val candidates = mutableListOf<String>()
        collectText(root, candidates, depth = 0)

        val fresh = candidates
            .map { it.trim() }
            .filter { it.length in MIN_TEXT_LENGTH..MAX_TEXT_LENGTH }
            .filterNot { it in recentlySeen }
            .takeLast(MAX_MESSAGES_PER_EVENT)

        if (fresh.isEmpty()) return

        fresh.forEach { text ->
            recentlySeen += text
            if (recentlySeen.size > SEEN_CACHE_SIZE) {
                recentlySeen.iterator().apply { next(); remove() }
            }
        }

        serviceScope.launch { translateAll(fresh) }
    }

    private suspend fun translateAll(messages: List<String>) = translationMutex.withLock {
        val settings = settingsRepository.current()

        messages.forEach { message ->
            val result = translateText(
                TranslationRequest(
                    text = message,
                    sourceLanguage = settings.sourceLanguage,
                    targetLanguage = settings.targetLanguage,
                    mode = TranslationMode.WHATSAPP,
                ),
            )

            when (result) {
                is AppResult.Failure -> sessionController.setError(result.error)
                is AppResult.Success -> sessionController.addLine(
                    original = message,
                    translation = result.data.translatedText,
                    fromChat = true,
                )
            }
        }
    }

    /** Depth-limited walk: chat screens are shallow and unbounded recursion is expensive. */
    private fun collectText(
        node: AccessibilityNodeInfo?,
        output: MutableList<String>,
        depth: Int,
    ) {
        if (node == null || depth > MAX_DEPTH || output.size >= MAX_NODES) return

        node.text?.toString()?.takeIf { it.isNotBlank() }?.let(output::add)

        for (index in 0 until node.childCount) {
            collectText(node.getChild(index), output, depth + 1)
        }
    }

    override fun onInterrupt() {
        // Required by the platform; nothing to interrupt because no long-running UI work
        // is performed here.
    }

    override fun onDestroy() {
        sessionController.setAccessibilityConnected(false)
        serviceScope.cancel()
        super.onDestroy()
    }

    private companion object {
        const val TAG = "A11yTranslator"
        const val WHATSAPP_PACKAGE_PREFIX = "com.whatsapp"
        const val MIN_TEXT_LENGTH = 2
        const val MAX_TEXT_LENGTH = 500
        const val MAX_MESSAGES_PER_EVENT = 2
        const val MAX_NODES = 120
        const val MAX_DEPTH = 12
        const val SEEN_CACHE_SIZE = 200
    }
}
