package com.aitranslator.live.ui.assist

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aitranslator.live.R
import com.aitranslator.live.core.domain.assist.AssistCapabilities
import com.aitranslator.live.core.domain.model.Capability
import com.aitranslator.live.core.domain.model.CapabilityStatus
import com.aitranslator.live.ui.common.toUserMessage
import com.aitranslator.live.ui.components.LanguageSelectorRow
import com.aitranslator.live.ui.components.PipelineStatusChip
import com.aitranslator.live.ui.components.TranslatorScaffold
import com.aitranslator.live.ui.components.rememberMicrophonePermission

/**
 * WhatsApp / Phone Call assist.
 *
 * The capability report is shown *before* the controls on purpose: the user should read
 * what Android does and does not permit before pressing anything, rather than discovering
 * a limitation as a silent failure mid-call.
 */
@Composable
fun AssistScreen(
    feature: String,
    onBack: () -> Unit,
    viewModel: AssistViewModel = hiltViewModel(),
) {
    val sessionState by viewModel.sessionState.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val micPermission = rememberMicrophonePermission()
    var showConsent by remember { mutableStateOf(false) }

    val report = remember(feature) { viewModel.capabilityReport(feature) }
    val isWhatsApp = feature == AssistCapabilities.WHATSAPP

    LaunchedEffect(sessionState.error) {
        sessionState.error?.let { error ->
            snackbarHostState.showSnackbar(error.toUserMessage(context))
            viewModel.dismissError()
        }
    }

    if (showConsent) {
        AlertDialog(
            onDismissRequest = { showConsent = false },
            title = { Text(stringResource(R.string.assist_consent_title)) },
            text = { Text(stringResource(R.string.assist_consent_body)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showConsent = false
                        micPermission.runOrRequest { viewModel.startSpeakerAssist(feature) }
                    },
                ) {
                    Text(stringResource(R.string.assist_consent_agree))
                }
            },
            dismissButton = {
                TextButton(onClick = { showConsent = false }) {
                    Text(stringResource(R.string.action_back))
                }
            },
        )
    }

    TranslatorScaffold(
        title = stringResource(
            if (isWhatsApp) R.string.assist_whatsapp_title else R.string.assist_phone_title,
        ),
        onBack = onBack,
        snackbarHostState = snackbarHostState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            LanguageSelectorRow(
                source = settings.sourceLanguage,
                target = settings.targetLanguage,
                onSourceSelected = viewModel::setSourceLanguage,
                onTargetSelected = viewModel::setTargetLanguage,
                onSwap = viewModel::swapLanguages,
                enabled = !sessionState.isListening,
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(modifier = Modifier.height(16.dp))

            PipelineStatusChip(state = sessionState.pipelineState)

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Button(
                    onClick = {
                        if (sessionState.isListening) {
                            viewModel.stopSpeakerAssist()
                        } else {
                            showConsent = true
                        }
                    },
                    colors = if (sessionState.isListening) {
                        ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = MaterialTheme.colorScheme.onError,
                        )
                    } else {
                        ButtonDefaults.buttonColors()
                    },
                    modifier = Modifier.weight(1f),
                ) {
                    Text(
                        stringResource(
                            if (sessionState.isListening) {
                                R.string.assist_stop_speaker
                            } else {
                                R.string.assist_start_speaker
                            },
                        ),
                    )
                }
            }

            if (isWhatsApp) {
                OutlinedButton(
                    onClick = {
                        context.startActivity(
                            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                ) {
                    Text(stringResource(R.string.assist_open_accessibility))
                }

                Text(
                    text = if (sessionState.isAccessibilityConnected) {
                        "Chat text translation is active."
                    } else {
                        "Chat text translation is off. Enable the service to translate " +
                            "WhatsApp messages that are visible on screen."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            if (sessionState.isListening && !sessionState.heardAnyAudio) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer,
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                ) {
                    Text(
                        text = stringResource(R.string.assist_no_audio),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(12.dp),
                    )
                }
            }

            if (sessionState.partialOriginal.isNotBlank() ||
                sessionState.partialTranslation.isNotBlank()
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = sessionState.partialOriginal,
                            style = MaterialTheme.typography.bodyLarge,
                        )
                        Text(
                            text = sessionState.partialTranslation,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 6.dp),
                        )
                    }
                }
            }

            sessionState.lines.take(MAX_VISIBLE_LINES).forEach { line ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp),
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (line.fromChat) "Chat message" else "Heard",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(text = line.original, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            text = line.translation,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 6.dp),
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = stringResource(R.string.assist_what_works),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
            )

            report.capabilities
                .filter { it.status != CapabilityStatus.BLOCKED_BY_PLATFORM }
                .forEach { CapabilityRow(it) }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = stringResource(R.string.assist_what_cannot),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.error,
            )

            report.capabilities
                .filter { it.status == CapabilityStatus.BLOCKED_BY_PLATFORM }
                .forEach { CapabilityRow(it) }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun CapabilityRow(capability: Capability) {
    val (icon, tint) = when (capability.status) {
        CapabilityStatus.AVAILABLE ->
            Icons.Filled.CheckCircle to MaterialTheme.colorScheme.primary

        CapabilityStatus.DEVICE_DEPENDENT ->
            Icons.Filled.Warning to MaterialTheme.colorScheme.tertiary

        CapabilityStatus.REQUIRES_SETUP ->
            Icons.Filled.Info to MaterialTheme.colorScheme.secondary

        CapabilityStatus.BLOCKED_BY_PLATFORM ->
            Icons.Filled.Block to MaterialTheme.colorScheme.error
    }

    Row(modifier = Modifier.padding(vertical = 8.dp)) {
        Icon(imageVector = icon, contentDescription = null, tint = tint)
        Spacer(modifier = Modifier.padding(horizontal = 6.dp))
        Column {
            Text(text = capability.title, style = MaterialTheme.typography.bodyLarge)
            Text(
                text = capability.explanation,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            capability.alternative?.let { alternative ->
                Text(
                    text = "Instead: $alternative",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
    }
}

private const val MAX_VISIBLE_LINES = 20
