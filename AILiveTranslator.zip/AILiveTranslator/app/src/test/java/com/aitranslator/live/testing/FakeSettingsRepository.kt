package com.aitranslator.live.testing

import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.AppSettings
import com.aitranslator.live.core.domain.model.ConversationTurnMode
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.LatencyProfile
import com.aitranslator.live.core.domain.model.ThemeMode
import com.aitranslator.live.core.domain.model.VoiceGender
import com.aitranslator.live.core.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/** In-memory settings, shared by the data-layer tests. */
class FakeSettingsRepository(initial: AppSettings = AppSettings()) : SettingsRepository {

    private val state = MutableStateFlow(initial)

    override val settings: Flow<AppSettings> = state.asStateFlow()

    override suspend fun current(): AppSettings = state.value

    override suspend fun setActiveProvider(provider: AiProvider) {
        state.value = state.value.copy(activeProvider = provider)
    }

    override suspend fun setModelOverride(provider: AiProvider, model: String?) {
        val overrides = state.value.modelOverrides.toMutableMap()
        if (model.isNullOrBlank()) overrides.remove(provider) else overrides[provider] = model
        state.value = state.value.copy(modelOverrides = overrides)
    }

    override suspend fun setSourceLanguage(language: Language) {
        state.value = state.value.copy(sourceLanguage = language)
    }

    override suspend fun setTargetLanguage(language: Language) {
        state.value = state.value.copy(targetLanguage = language)
    }

    override suspend fun swapLanguages() {
        val current = state.value
        state.value = current.copy(
            sourceLanguage = current.targetLanguage,
            targetLanguage = current.sourceLanguage,
        )
    }

    override suspend fun setConversationLanguages(personA: Language, personB: Language) {
        state.value = state.value.copy(
            conversationLanguageA = personA,
            conversationLanguageB = personB,
        )
    }

    override suspend fun setConversationTurnMode(mode: ConversationTurnMode) {
        state.value = state.value.copy(conversationTurnMode = mode)
    }

    override suspend fun setVoice(voiceId: String) {
        state.value = state.value.copy(selectedVoiceId = voiceId)
    }

    override suspend fun setPreferredVoiceGender(gender: VoiceGender) {
        state.value = state.value.copy(preferredVoiceGender = gender)
    }

    override suspend fun setVoiceTranslationEnabled(enabled: Boolean) {
        state.value = state.value.copy(voiceTranslationEnabled = enabled)
    }

    override suspend fun setAutoPlayTranslation(enabled: Boolean) {
        state.value = state.value.copy(autoPlayTranslation = enabled)
    }

    override suspend fun setSpeechSpeed(speed: Float) {
        state.value = state.value.copy(speechSpeed = speed)
    }

    override suspend fun setSpeechVolume(volume: Float) {
        state.value = state.value.copy(speechVolume = volume)
    }

    override suspend fun setShowOriginalText(show: Boolean) {
        state.value = state.value.copy(showOriginalText = show)
    }

    override suspend fun setShowTranslation(show: Boolean) {
        state.value = state.value.copy(showTranslation = show)
    }

    override suspend fun setSaveHistory(enabled: Boolean) {
        state.value = state.value.copy(saveHistory = enabled)
    }

    override suspend fun setSaveAudio(enabled: Boolean) {
        state.value = state.value.copy(saveAudio = enabled)
    }

    override suspend fun setLatencyProfile(profile: LatencyProfile) {
        state.value = state.value.copy(latencyProfile = profile)
    }

    override suspend fun setThemeMode(mode: ThemeMode) {
        state.value = state.value.copy(themeMode = mode)
    }

    override suspend fun setTranslationCacheEnabled(enabled: Boolean) {
        state.value = state.value.copy(translationCacheEnabled = enabled)
    }
}
