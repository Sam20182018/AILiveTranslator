package com.aitranslator.live.ui.text

import com.aitranslator.live.core.common.AppError
import com.aitranslator.live.core.common.AppResult
import com.aitranslator.live.core.common.NetworkMonitor
import com.aitranslator.live.core.domain.model.AiProvider
import com.aitranslator.live.core.domain.model.AppSettings
import com.aitranslator.live.core.domain.model.HistoryEntry
import com.aitranslator.live.core.domain.model.Language
import com.aitranslator.live.core.domain.model.TranslationChunk
import com.aitranslator.live.core.domain.model.TranslationRequest
import com.aitranslator.live.core.domain.model.TranslationResult
import com.aitranslator.live.core.domain.model.VoiceProfile
import com.aitranslator.live.core.domain.repository.HistoryRepository
import com.aitranslator.live.core.domain.repository.SpeechRepository
import com.aitranslator.live.core.domain.repository.TranslationRepository
import com.aitranslator.live.core.domain.usecase.SpeakTextUseCase
import com.aitranslator.live.core.domain.usecase.TranslateTextUseCase
import com.aitranslator.live.testing.FakeSettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class TextTranslationViewModelTest {

    private val dispatcher = UnconfinedTestDispatcher()

    private class FakeTranslationRepository(
        private val outcome: AppResult<TranslationResult>,
    ) : TranslationRepository {
        var calls = 0

        override suspend fun translate(request: TranslationRequest): AppResult<TranslationResult> {
            calls++
            return outcome
        }

        override fun translateStreaming(request: TranslationRequest): Flow<TranslationChunk> =
            emptyFlow()

        override suspend fun resolveProvider(): AppResult<AiProvider> =
            AppResult.Success(AiProvider.OPENAI)

        override suspend fun testConnection(
            provider: AiProvider,
            key: String?,
            model: String?,
        ): AppResult<Unit> = AppResult.Success(Unit)

        override fun clearCache() = Unit
    }

    private class FakeHistoryRepository : HistoryRepository {
        val added = mutableListOf<HistoryEntry>()

        override fun observeHistory(query: String): Flow<List<HistoryEntry>> = flowOf(added)

        override suspend fun add(entry: HistoryEntry): Long {
            added += entry
            return added.size.toLong()
        }

        override suspend fun delete(id: Long) = Unit
        override suspend fun deleteAll() = Unit
        override suspend fun purgeAudio() = Unit
    }

    private class FakeSpeechRepository : SpeechRepository {
        var spokenText: String? = null

        override suspend fun transcribe(
            wavAudio: ByteArray,
            language: Language,
        ): AppResult<String> = AppResult.Success("")

        override suspend fun speak(
            text: String,
            language: Language,
            persistAudio: Boolean,
        ): AppResult<String?> {
            spokenText = text
            return AppResult.Success(null)
        }

        override suspend fun stopSpeaking() = Unit
        override suspend fun voiceCatalogue(): List<VoiceProfile> = VoiceProfile.OPENAI_VOICES
        override suspend fun selectedVoice(): VoiceProfile = VoiceProfile.DEVICE_DEFAULT
        override suspend fun previewVoice(
            voice: VoiceProfile,
            language: Language,
        ): AppResult<Unit> = AppResult.Success(Unit)
    }

    private class StubNetworkMonitor(private val online: Boolean = true) : NetworkMonitor {
        override val isOnline: Flow<Boolean> = MutableStateFlow(online)
        override fun isCurrentlyOnline(): Boolean = online
    }

    private lateinit var settingsRepository: FakeSettingsRepository
    private lateinit var historyRepository: FakeHistoryRepository
    private lateinit var speechRepository: FakeSpeechRepository

    private val successResult = TranslationResult(
        originalText = "سلام",
        translatedText = "Hello",
        sourceLanguage = Language.PERSIAN,
        targetLanguage = Language.ENGLISH,
        provider = AiProvider.OPENAI,
        model = "gpt-4o-mini",
        latencyMillis = 12,
    )

    @Before
    fun setUp() {
        Dispatchers.setMain(dispatcher)
        settingsRepository = FakeSettingsRepository(
            AppSettings(autoPlayTranslation = false, voiceTranslationEnabled = false),
        )
        historyRepository = FakeHistoryRepository()
        speechRepository = FakeSpeechRepository()
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    private fun viewModel(
        outcome: AppResult<TranslationResult> = AppResult.Success(successResult),
        online: Boolean = true,
    ): TextTranslationViewModel {
        val translationRepository = FakeTranslationRepository(outcome)
        val monitor = StubNetworkMonitor(online)
        return TextTranslationViewModel(
            translateText = TranslateTextUseCase(translationRepository, monitor),
            speakText = SpeakTextUseCase(speechRepository, settingsRepository),
            settingsRepository = settingsRepository,
            historyRepository = historyRepository,
            networkMonitor = monitor,
        )
    }

    @Test
    fun `a successful translation lands in state and in history`() = runTest {
        val viewModel = viewModel()

        viewModel.onInputChanged("سلام")
        viewModel.translate()

        val state = viewModel.uiState.value
        assertEquals("Hello", state.translation)
        assertFalse(state.isTranslating)
        assertEquals(1, historyRepository.added.size)
        assertEquals("Hello", historyRepository.added.first().translatedText)
    }

    @Test
    fun `empty input is rejected without touching history`() = runTest {
        val viewModel = viewModel()

        viewModel.translate()

        assertTrue(viewModel.uiState.value.error is AppError.EmptyInput)
        assertEquals(0, historyRepository.added.size)
    }

    @Test
    fun `a failure is surfaced as a typed error and clears the loading flag`() = runTest {
        val viewModel = viewModel(
            outcome = AppResult.Failure(AppError.InvalidApiKey("openai")),
        )

        viewModel.onInputChanged("سلام")
        viewModel.translate()

        val state = viewModel.uiState.value
        assertTrue(state.error is AppError.InvalidApiKey)
        assertFalse(state.isTranslating)
        assertEquals("", state.translation)
    }

    @Test
    fun `offline never reaches the provider`() = runTest {
        val viewModel = viewModel(online = false)

        viewModel.onInputChanged("سلام")
        viewModel.translate()

        assertTrue(viewModel.uiState.value.error is AppError.NoInternet)
    }

    @Test
    fun `swapping languages moves the result back into the input`() = runTest {
        val viewModel = viewModel()

        viewModel.onInputChanged("سلام")
        viewModel.translate()
        viewModel.swapLanguages()

        assertEquals("Hello", viewModel.uiState.value.input)
        assertEquals(Language.ENGLISH, settingsRepository.current().sourceLanguage)
    }

    @Test
    fun `auto play speaks the translation when both switches are on`() = runTest {
        settingsRepository = FakeSettingsRepository(
            AppSettings(autoPlayTranslation = true, voiceTranslationEnabled = true),
        )
        val viewModel = viewModel()

        viewModel.onInputChanged("سلام")
        viewModel.translate()

        assertEquals("Hello", speechRepository.spokenText)
    }

    @Test
    fun `clear resets the whole screen state`() = runTest {
        val viewModel = viewModel()

        viewModel.onInputChanged("سلام")
        viewModel.translate()
        viewModel.clear()

        val state = viewModel.uiState.value
        assertEquals("", state.input)
        assertEquals("", state.translation)
        assertTrue(state.error == null)
    }
}
