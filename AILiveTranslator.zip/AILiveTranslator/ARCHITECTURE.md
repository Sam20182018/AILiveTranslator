# AI Live Translator — Architecture & Technical Plan

> Version 1.0 · Target: Android · Kotlin + Jetpack Compose + Material 3 · MVVM + Clean Architecture

---

## 0. Executive summary

`AI Live Translator` is an **online** AI translator for Android supporting 6 languages
(Persian, English, Arabic, French, Dutch, German) across five interaction modes:

| Mode | What it does | Feasibility |
|---|---|---|
| Text | Type → AI translate → read/copy/share/speak | ✅ Fully implemented |
| Voice | Push‑to‑talk → cloud STT → AI translate → TTS playback | ✅ Fully implemented |
| Live | Continuous mic → VAD segmentation → streaming translate → auto TTS | ✅ Fully implemented (2 engines: chunked pipeline + OpenAI Realtime WebSocket) |
| Conversation | Two‑party face‑to‑face, auto turn detection or manual push‑to‑talk | ✅ Fully implemented |
| WhatsApp | Translate WhatsApp **chat text** via AccessibilityService + **Speaker Assist** for calls | ⚠️ Partially possible — see §12 |
| Phone Call | **Call Assistant Mode** (speakerphone + mic) + call state awareness | ⚠️ Partially possible — see §13 |

The two last rows are the honest part of this document. Android does **not** allow a
normal app to read the audio stream of a cellular call or of another app's VoIP call,
and it does not allow injecting audio into the uplink. §12/§13 explain exactly why,
cite the platform mechanism that blocks it, and specify the best *legal* alternative
that this project actually implements.

---

## 1. Technology stack

| Concern | Choice | Why |
|---|---|---|
| Language | Kotlin 2.0.21 | Coroutines/Flow, K2 compiler |
| UI | Jetpack Compose + Material 3 | Declarative, dynamic color, dark/light |
| Architecture | Clean Architecture + MVVM | Testable layers, swappable providers |
| Async | Coroutines + Flow/StateFlow | Streaming translation, pipeline back‑pressure |
| DI | Hilt (Dagger) | Multi‑module, compile‑time safe |
| Networking | Retrofit 2.11 + OkHttp 4.12 + kotlinx.serialization | JSON + SSE + WebSocket in one client |
| Realtime | OkHttp `WebSocket` → OpenAI Realtime API | Lowest latency path for Live mode |
| Persistence | Room 2.6 (history) + DataStore Proto‑less (settings) | Structured queries + typed prefs |
| Security | Android Keystore (AES/GCM) → encrypted blobs in DataStore | API keys never stored in plaintext |
| Audio in | `AudioRecord` (16 kHz mono PCM16) | Raw frames needed for VAD + chunk upload |
| Audio out | `MediaPlayer` (cloud MP3) + `android.speech.tts.TextToSpeech` (device) | Two TTS engines |
| Build | AGP 8.7.3, Gradle 8.11.1, KSP | Current stable toolchain |
| minSdk | **26 (Android 8.0)** | `AudioRecord` + `AudioAttributes` + `Keystore` AES/GCM + `TextToSpeech.Voice` all stable from 26; covers ~98 % of devices |
| compileSdk / targetSdk | 35 | Required for Play Store, gives `FOREGROUND_SERVICE_MICROPHONE` semantics |

---

## 2. Module graph

```
                 ┌──────────┐
                 │   :app   │  Compose UI, ViewModels, navigation, services
                 └────┬─────┘
        ┌─────────────┼──────────────┬───────────────┐
        ▼             ▼              ▼               ▼
 ┌────────────┐ ┌───────────┐ ┌────────────┐ ┌─────────────┐
 │ :core:data │ │:core:audio│ │:core:      │ │             │
 │            │ │           │ │    network │ │             │
 └─────┬──────┘ └─────┬─────┘ └─────┬──────┘ │             │
       └──────────────┴─────────────┘        │             │
                      ▼                      ▼             │
               ┌─────────────┐         ┌────────────┐      │
               │:core:domain │────────▶│:core:common│◀─────┘
               └─────────────┘         └────────────┘
```

Rules:

* `:core:domain` is **pure Kotlin models + interfaces**. It knows nothing about Retrofit,
  Room, Android UI, or any vendor.
* `:core:network`, `:core:audio`, `:core:data` each *implement* domain interfaces and are
  bound by Hilt in `:app`. Any of them can be replaced without touching the others.
* `:app` never talks to Retrofit or Room directly — only to use cases / repositories.

Physical layout:

```
AILiveTranslator/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle/libs.versions.toml          ← single source of truth for versions
├── app/
│   └── src/main/java/com/aitranslator/live/
│       ├── TranslatorApplication.kt
│       ├── MainActivity.kt
│       ├── navigation/
│       ├── service/                   ← accessibility + foreground assist services
│       └── ui/
│           ├── theme/  components/
│           ├── home/  text/  voice/  live/  conversation/
│           ├── history/  settings/  whatsapp/  phonecall/
├── core/common/                       ← AppResult, AppError, dispatchers, NetworkMonitor
├── core/domain/                       ← model/ provider/ audio/ repository/ usecase/
├── core/network/                      ← api/ dto/ provider/ stt/ tts/ realtime/
├── core/audio/                        ← recorder/ vad/ player/ tts/ pipeline/
└── core/data/                         ← db/ datastore/ security/ repository/ cache/
```

---

## 3. Data models (`:core:domain`)

```kotlin
enum class Language(code, bcp47, englishName, nativeName, flag, isRtl)
    PERSIAN("fa","fa-IR","Persian","فارسی","🇮🇷",true)
    ENGLISH, ARABIC, FRENCH, DUTCH, GERMAN
```

Adding a 7th language = **one enum entry**. Everything else (selectors, prompts, STT
hints, TTS locale lookup, history filters) derives from the enum, so no other file changes.

Other core models:

| Model | Purpose |
|---|---|
| `AiProvider` | `GEMINI · CLAUDE · OPENAI · AUTO` |
| `AiModelConfig` | per‑provider model id + maxTokens + temperature (**never hard‑coded**, stored in settings with a default constant) |
| `TranslationRequest / TranslationResult` | text, source, target, provider used, latency, cached flag |
| `TranslationMode` | TEXT · VOICE · LIVE · CONVERSATION · WHATSAPP · PHONE_CALL |
| `VoiceProfile` | id, label, `VoiceGender`, `TtsEngine` (ANDROID / OPENAI), engine voice id |
| `HistoryEntry` | timestamp, langs, original, translation, mode, provider, optional audio path |
| `AppSettings` | provider, models, langs, voice, speed, volume, toggles, latency profile, theme |
| `PipelineState` | `Idle · Listening · Processing · Translating · Speaking · Error · Stopped` |
| `AppError` | typed: `NoInternet · InvalidApiKey · RateLimited · ServerError · Timeout · UnsupportedLanguage · ModelUnavailable · AudioCapture · NotConfigured · Unknown` |

`AppResult<T>` = `Success(T) | Failure(AppError)` — no exception leaks across layers.

---

## 4. Provider abstraction

```kotlin
interface AITranslationProvider {
    val provider: AiProvider
    suspend fun translate(request: TranslationRequest, key: String, model: String): AppResult<TranslationResult>
    fun translateStream(request: TranslationRequest, key: String, model: String): Flow<String>  // incremental deltas
    suspend fun testConnection(key: String, model: String): AppResult<Unit>
    val supportsStreaming: Boolean
}

interface SpeechRecognitionProvider {          // audio → text
    suspend fun transcribe(pcmWav: ByteArray, language: Language, key: String, model: String): AppResult<String>
}

interface TextToSpeechProvider {               // text → audio
    suspend fun synthesize(text: String, language: Language, voice: VoiceProfile, speed: Float): AppResult<SynthesizedAudio>
    fun availableVoices(): List<VoiceProfile>
}

interface AIProviderRegistry {                 // picks the concrete provider
    fun translationProvider(preferred: AiProvider): AppResult<AITranslationProvider>
}
```

Implementations:

| Interface | Implementations |
|---|---|
| `AITranslationProvider` | `GeminiTranslationProvider`, `ClaudeTranslationProvider`, `OpenAiTranslationProvider` |
| `SpeechRecognitionProvider` | `OpenAiSpeechRecognitionProvider` (Whisper/`gpt-4o-transcribe`), `GeminiSpeechRecognitionProvider` (inline audio) |
| `TextToSpeechProvider` | `OpenAiTtsProvider` (10 cloud voices), `AndroidTextToSpeechProvider` (device voices), `CompositeTextToSpeechProvider` (router) |

**Anthropic Claude has no audio input or TTS endpoint**, so it is a translation‑only
provider. When the active provider is Claude, STT/TTS transparently route to the first
configured audio‑capable service (OpenAI → Gemini for STT; OpenAI → device TTS for speech).
This fallback is shown in the UI, not hidden.

**AUTO mode** ranking: (1) provider marked active with a valid key, (2) health score from
the last N calls (failures decay the score), (3) static preference order
OpenAI → Gemini → Claude for audio work, Gemini → OpenAI → Claude for cheap bulk text.

### REST surface actually used

| Provider | Translate | Stream | STT | TTS |
|---|---|---|---|---|
| OpenAI | `POST /v1/chat/completions` | SSE `stream:true` | `POST /v1/audio/transcriptions` (multipart) | `POST /v1/audio/speech` |
| Gemini | `POST /v1beta/models/{m}:generateContent` | `:streamGenerateContent?alt=sse` | `generateContent` with `inline_data` audio | — |
| Claude | `POST /v1/messages` (`anthropic-version: 2023-06-01`) | SSE `stream:true` | — | — |
| OpenAI Realtime | `wss://api.openai.com/v1/realtime?model=…` | bidirectional | server VAD + transcription | audio deltas |

---

## 5. Audio layer

```
AudioRecord(16 kHz, MONO, PCM_16BIT, VOICE_RECOGNITION)
   └─▶ 20 ms frames ──▶ EnergyVoiceActivityDetector
                            │  adaptive noise floor, hangover, min‑speech guard
                            ▼
                     SpeechSegment (ByteArray PCM) ──▶ WavEncoder ──▶ 16‑bit WAV
```

`EnergyVoiceActivityDetector` keeps a rolling noise floor, requires RMS > floor × k for
`minSpeechMs` (default 250 ms) to open a segment and `silenceMs` (default 700 ms, tunable
by latency profile) to close it. This is the single most important cost control: silence
is never uploaded.

Playback: cloud MP3 → `MediaPlayer`; device TTS → `TextToSpeech.speak` with an
`UtteranceProgressListener` bridged into a `Flow` so the pipeline knows when speech ends
(needed so the mic does not transcribe our own TTS output in Live mode — a half‑duplex
gate).

### Voice catalogue (≥ 10 profiles, requirement §9)

| Gender | Cloud (OpenAI) | Fallback |
|---|---|---|
| Male | `onyx`, `echo`, `ash`, `ballad`, `verse` | device voices tagged male |
| Female | `nova`, `shimmer`, `alloy`, `coral`, `sage` | device voices tagged female |

Device voices discovered via `TextToSpeech.getVoices()` are appended dynamically and
gender‑tagged from the voice name/features. Preview, speed (0.5–2.0×), volume, and
auto‑play are all in `AppSettings`.

---

## 6. Live translation pipeline

Two interchangeable engines behind one `LiveTranslationEngine` interface:

**A. `ChunkedLivePipeline`** — works with every provider.

```
Mic ▶ VAD ▶ segment ▶ WAV ▶ STT ▶ transcript ▶ translateStream ▶ partial text ▶ TTS ▶ playback
                                                        └─▶ UI updates on every delta
```

**B. `OpenAiRealtimeEngine`** — WebSocket, used when OpenAI is active and latency profile
is `LOW_LATENCY`. Streams 24 kHz PCM16 up, receives incremental transcript *and*
translated audio down, so the user hears the translation while still speaking. Server‑side
VAD replaces the local one.

Both emit the same `Flow<LiveEvent>` (`PartialTranscript`, `FinalTranscript`,
`PartialTranslation`, `FinalTranslation`, `StateChanged`, `Error`), so the UI is engine‑agnostic.

### Cost optimisation (requirement §23)

1. VAD gate — silence is never sent.
2. Min‑segment length + max‑segment cap (5 s) to avoid pathological uploads.
3. Repeat suppression — identical consecutive transcripts are dropped.
4. LRU `TranslationCache` (in‑memory, 200 entries, keyed by `src|dst|normalizedText`).
5. Streaming responses so the user perceives speed at low token counts.
6. `LatencyProfile` = `LOW_LATENCY | BALANCED | HIGH_QUALITY` changes silence threshold,
   max tokens, temperature, and whether the Realtime engine is used.

---

## 7. State management

```
Idle ──start──▶ Listening ──speech end──▶ Processing ──▶ Translating ──▶ Speaking ──▶ Listening
  ▲                                                                                      │
  └──────────────────────────── stop / error ────────────────────────────────────────────┘
```

Each screen exposes a single immutable `UiState` data class via `StateFlow`, updated only
inside the ViewModel. One‑shot events (toast, share sheet, permission request) go through
a `Channel`‑backed `Flow` so they are not replayed on rotation.

---

## 8. Security of API keys (requirement §13)

* A 256‑bit AES key is generated once inside **Android Keystore**
  (`setUserAuthenticationRequired(false)`, `GCM/NoPadding`, `setRandomizedEncryptionRequired(true)`).
  The raw key material never leaves the TEE/StrongBox.
* Each API key is encrypted → `iv || ciphertext` → Base64 → stored in DataStore.
* Nothing decrypts the key except `SecureApiKeyStore` at request time.
* `Logger` masks any string that looks like a key (`sk-…`, `AIza…`) and API keys are never
  passed to `Log.*`. OkHttp's `HttpLoggingInterceptor` is `BODY` only in `debug` and has a
  redacting `Interceptor` in front of it for `Authorization`, `x-api-key`, and `?key=`.
* UI shows `••••••••1234` with an explicit show/hide toggle.
* No key is ever written to any test, fixture, or committed file.

---

## 9. Persistence

* **Room** `translation_history` (id, timestampMs, sourceLang, targetLang, original,
  translation, mode, provider, audioPath?) with FTS‑less `LIKE` search (small dataset),
  `Flow`‑based DAO, `DELETE` single / all.
* Writing is gated on `AppSettings.saveHistory`; audio is only persisted when
  `saveAudio == true` (**default false**, per requirement §20). Turning either setting off
  purges existing data.
* **DataStore Preferences** for all settings + encrypted key blobs.

---

## 10. Error handling

`ErrorMapper` converts HTTP status + provider error body → `AppError`:

| Signal | `AppError` | User message (localized) |
|---|---|---|
| `UnknownHostException` / monitor offline | `NoInternet` | "No internet connection" |
| 401 / 403 | `InvalidApiKey` | "API key is invalid — check Settings" |
| 429 | `RateLimited(retryAfter)` | "Rate limit reached, try again in N s" |
| 5xx | `ServerError` | "Service temporarily unavailable" |
| `SocketTimeoutException` | `Timeout` | "Request timed out" |
| 404 / `model_not_found` | `ModelUnavailable` | "Selected model is unavailable" |

Technical detail (status, provider body, request id) goes to `Logger.d` in debug builds only.

---

## 11. Permissions

| Permission | Why | When requested |
|---|---|---|
| `RECORD_AUDIO` | every voice mode | first time the mic button is pressed |
| `INTERNET` / `ACCESS_NETWORK_STATE` | online translation + status pill | manifest only |
| `POST_NOTIFICATIONS` (33+) | foreground assist service | before starting an assist mode |
| `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_MICROPHONE` | assist modes keep listening | manifest only |
| `READ_PHONE_STATE` (optional) | pause pipeline during a real call | only if Call Assist is opened |
| `SYSTEM_ALERT_WINDOW` (optional) | floating subtitle bubble | user‑granted from the WhatsApp screen |
| `BIND_ACCESSIBILITY_SERVICE` | WhatsApp **text** translation | user enables in system settings |

No `CAPTURE_AUDIO_OUTPUT`, no `PROCESS_OUTGOING_CALLS`, no root, no accessibility abuse
for anything the user has not explicitly enabled.

---

## 12. WhatsApp — what is and is not possible

### What Android blocks

1. **Capturing WhatsApp call audio.** `MediaProjection` + `AudioPlaybackCaptureConfiguration`
   (API 29+) is the only sanctioned way to capture another app's playback, and the platform
   *never* allows capture of streams whose `AudioAttributes.usage` is
   `USAGE_VOICE_COMMUNICATION` — which is exactly what VoIP calls use. It also honours each
   app's `setAllowedCapturePolicy`; WhatsApp does not opt in. There is no flag, permission,
   or API that changes this for a normal app.
2. **Injecting audio into a WhatsApp call.** Android has no public API to write into
   another app's microphone input. `AudioTrack` plays to an output device; it cannot become
   someone else's input. Virtual‑microphone routing requires a system/OEM HAL.
3. **Reading WhatsApp's internal database** — sandboxed; requires root. Out of scope by design.

### What is legitimately possible — and is implemented

* **`WhatsAppTextTranslator` (AccessibilityService).** With the user's explicit consent the
  service observes `TYPE_WINDOW_CONTENT_CHANGED` events from `com.whatsapp`, reads visible
  message text from the node tree, translates it, and shows it in an overlay bubble or in
  the app's Conversation view. This is the standard, policy‑compliant mechanism used by
  accessibility/translation tools. It handles **text messages**, not call audio.
* **`SpeakerAssistService` (foreground service).** For a WhatsApp *call*, the user puts the
  call on **speakerphone**; the app captures the acoustic signal with the device mic
  (`VOICE_RECOGNITION` source), runs the normal VAD → STT → translate → display pipeline and
  shows subtitles. Translated speech is played to the **user**, not into the call.
  Limitations are stated in the UI before it starts:
  * whether another app can hold the mic during a VoIP call is device/OEM dependent —
    since Android 10 mic access is exclusive to the app with audio focus, so on many devices
    this yields silence and the app says so instead of pretending to work;
  * echo/quality is poor compared to a direct stream;
  * recording other people may require their consent depending on jurisdiction — an explicit
    consent dialog is shown.
* **Share‑sheet translation.** WhatsApp text shared into the app is translated instantly.

### Module design

`whatsapp` lives behind `WhatsAppAssistController` with a `CapabilityReport`
(`ChatTextTranslation = AVAILABLE`, `CallAudioCapture = BLOCKED_BY_PLATFORM`,
`CallAudioInjection = BLOCKED_BY_PLATFORM`, `SpeakerAssist = DEVICE_DEPENDENT`). If Android
or WhatsApp ever exposes a sanctioned API, only this controller changes.

---

## 13. Phone calls — what is and is not possible

### What Android blocks

1. **`MediaRecorder.AudioSource.VOICE_CALL / VOICE_DOWNLINK / VOICE_UPLINK`** require the
   signature/privileged permission `android.permission.CAPTURE_AUDIO_OUTPUT`. A Play‑Store
   app cannot hold it. On Android 10+ requests fail or return silence.
2. **Call recording** was closed off in Android 10 and hardened again in Android 11 —
   accessibility services are explicitly forbidden by Play policy from being used to record calls.
3. **Injecting translated speech into the uplink** — no public API. `InCallService` /
   `ROLE_DIALER` lets an app *control* calls (answer, mute, hold, route to speaker) but gives
   **zero access to the audio samples**. `CallScreeningService` sees metadata only.

So a full‑duplex "the other side hears the translation" phone translator is **not
implementable** by a normal Android app. This project does not claim otherwise.

### `CallAssistantMode` — what is implemented

* `PhoneStateObserver` (`READ_PHONE_STATE`, optional) detects an active call and offers
  one‑tap start of Call Assist.
* Speakerphone routing hint + `SpeakerAssistService`: mic capture → VAD → STT → translate →
  **on‑screen subtitles** for the remote party's speech, and **your** speech translated and
  shown/spoken so you can read it aloud to them.
* A "read‑aloud" button plays your translated sentence through the **speaker**, which the
  other party hears acoustically — the only sanctioned way to get translated audio across.
* Pre‑call phrasebook: prepared translated sentences for one‑tap playback.
* Same explicit capability report + consent dialog as WhatsApp mode.

---

## 14. Testing strategy

| Layer | Tests |
|---|---|
| Providers | `MockWebServer` — success, 401, 429, 500, timeout, malformed body, SSE parsing |
| Repositories | fake providers + fake key store; AUTO selection; cache hit/miss; history gating |
| Use cases | same‑language short‑circuit, empty input, offline path |
| ViewModels | `Turbine`‑style state assertions on `StateFlow` with `TestDispatcher` |
| VAD | synthetic PCM (silence / tone / noise) segment boundaries |
| Security | encrypt→decrypt round trip (Robolectric/instrumented), never‑plaintext assertion |
| Integration | in‑memory Room + full translate‑and‑save flow |

No real API key appears anywhere in the repository or tests; tests use `MockWebServer` and
the string `test-key`.

---

## 15. Build order

1. Version catalog + module skeleton
2. `:core:common` + `:core:domain` (models, interfaces, use cases)
3. `:core:network` (DTOs → APIs → providers → registry → errors → realtime)
4. `:core:audio` (recorder → VAD → WAV → players → TTS → pipeline)
5. `:core:data` (Keystore → DataStore → Room → repositories → cache)
6. `:app` (theme → components → screens → ViewModels → navigation → services)
7. Tests + README

## 16. Extensibility checklist

| Want to… | Change |
|---|---|
| Add a language | one `Language` enum entry |
| Add an AI provider | implement `AITranslationProvider`, add to `AiProvider` enum, bind in Hilt module |
| Change a model name | Settings → Model, or the default constant in `AiModelDefaults` |
| Add offline STT/translation/TTS | implement the same three interfaces with on‑device engines and bind them; no UI or ViewModel changes |
| Swap the live engine | implement `LiveTranslationEngine` |
